import os.path as osp
import sys

try:
    import lomap # try installed version
except ImportError:
    lomap_dir = osp.join(osp.dirname(osp.abspath(__file__)), 'lomap')
    sys.path.append(lomap_dir)
    try:
        import lomap
    except ImportError as e:
        print('lomap is not installed or available as a git submodule.\n'
              'You may need to run `git submodule update --init --recursive`.')
        raise e
