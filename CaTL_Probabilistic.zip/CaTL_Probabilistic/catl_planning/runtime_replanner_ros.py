#Imports for ROS
import rospy
import numpy as np
from geometry_msgs.msg import PoseStamped, Pose
from std_msgs.msg import Int32, Int32MultiArray, MultiArrayDimension
from nav_msgs.msg import Path

#Import Gurobi
from gurobipy import Model as GRBModel
from gurobipy import GRB, LinExpr

#Import IITCHS PLANNING
from catl_planning.route_planning import route_planning
from catl_planning.route_planning import route_online_replanning
from catl_planning.route_planning import ReplanSubTeam2FullTeam
from catl_planning.visualization import show_environment
from catl_planning.traj_planner import run_planner
from catl_planning.traj_planner import run_replanner
from catl_planning.pure_pursuit import sim_dynamics
from catl_planning.kml_gen import gen_kml_file
from catl_planning.kml_gen import gen_replan_kml_file
from catl_planning.kml_gen import txt_output as txt_file_gen
from catl_planning.history_builder import regCapHist
#Lomap is an external library at the moment
from lomap import Ts

from catl_planning.CatlSol2Twtl import CatlSol2Twtl_main
from catl_planning.CatlTraj2TwtlTree import TWTLTraj2Tree

from twtl_traj_service.msg import TWTLWaypoint, TWTLTrajectory,TWTLTaus

import numpy as np
import argparse
import pickle
import pandas as pd
import csv
import time
import copy
import importlib
import cProfile
import gurobipy as gp

# import decomposition functions
from catl_planning.decomposition_functions import decompose



def sim_to_world_convert(simy, simx):

    x_off = -0.4
    y_off = -0.1
    scaley = -0.059
    scalex = 0.058

    simx = np.array(simx)
    simy = np.array(simy)

    worldx = (simx * scalex) + x_off
    worldy = (simy * scaley) + y_off

    return(worldx,worldy)

class empty_struct:
    pass

#Used to convert from subteam formulas to other subteam formulas
def CombineSubTrajs2TeamTraj(SubteamTrajs,formula):
    ###NOT IMPLEMENTED YET###
    for x in formula_decomp.keys():
        subteam = formula_decomp[x]['agents']
        print(subteam)

    print('not complete')
    TeamTrajs = 0
    return TeamTrajs

def generate_world_mapping(ts):
    region_bounds = []
    for state in ts.g.node:
        state_int = np.int(state[1:len(state)])
        bounds = ts.g.node[state]['shape']
        num_points = len(bounds)
        x_max = -100000
        x_min = 100000
        y_max = -100000
        y_min = 100000
        for pts in bounds:
            if pts[0] < x_min:
                x_min = pts[0]
            if pts[0] > x_max:
                x_max = pts[0]
            if pts[idx][1] < y_min:
                y_min = pts[1]
            if pts[idx][1] > y_max:
                y_max = pts[1]
        region_bounds.append([state_int,x_min,x_max,y_min,y_max])
    return region_bounds

def convert_srv_msg_2_traj(message):
    traj_msg = message.waypoints
    tau_msg = message.taus
    
    traj_array = []
    taus_array = []

    for traj_vals in traj_msg:
        traj_entry = [traj_vals.x,traj_vals.y,traj_vals.state,traj_vals.cost]
        traj_array.append(traj_entry)
    
    for tau_vals in tau_msg:
        taus_array.append(tau_vals.tau)
    
    return np.asarray(traj_array),np.asarray(taus_array)


def ConvertTraj2AgentArray(agent_state_traj_array):
    
    #Here we convert the agent_state_Traj_array into something kevin's history converter can read.
    states_array = []
    for p in range(0,len(agent_state_traj_array)):
        state_traj = []
        for q in len(agent_state_traj_array[p].data):
            state_traj.append(agent_state_traj_array[p].data[q])
        states_array.append(state_traj)
    return states_array

def ConvertTraj2CapArray(agent_state_traj_array,regions,caps,agents):
    #Here we convert the agent_state_Traj_array into something kevin's history converter can read.
    states_array = []
    for p in range(0,len(agent_state_traj_array)):
        state_traj = []
        for q in len(agent_state_traj_array[p].data):
            state_traj.append(agent_state_traj_array[p].data[q])
        states_array.append(state_traj)
    
        caps_array = regCapHist(states_array,regions,caps,agents)
    
    return caps_array

class Replanner_main():
    def __init__(self,agent_idx_to_name=[]):
        rospy.init_node("Replanner_Main_node")
        self.agent_idx_to_name = ['r1','r2','r3'] #agent_idx_to_name
        self.sub_array = []
        self.state_sub_array = []
        self.traj_sub_array = []
        self.agent_poses = []
        self.agent_state_traj_array = []
        self.agent_traj_array = []
        self.agent_index_gone =[]

        
        self.index_pub = rospy.Publisher('/replan_index',Int32, queue_size=10)
        self.replanning_index = Int32()
        self.replanning_index.data = 0

        self.hier_pub = rospy.Publisher('/whole_team_triggered',Int32, queue_size=10)
        self.hier_trig = Int32()
        self.hier_trig.data = 0


        self.replan_monitor_message = Int32MultiArray() #[time_of_dropout, region where dropout, capability_of_dropout, number dropped out,(for # dropped out, the index of the lost agents), delayed?(binary {0,1}), time to look back for delay]
        #self.replan_monitor_message.data = []
        self.replan_monitor_message.layout.dim.append(MultiArrayDimension())
        self.replan_monitor_message.layout.data_offset = 0
        self.replan_monitor_message.layout.dim[0].size = 7
        
        self.replan_message_sub = rospy.Subscriber('/replan_message',Int32MultiArray, self.replan_message_callback(self))
         
        self.trigger_replan = Int32() #0 is no replan, -1 is whole team replan, >0 is subteam replan of that index (1 index used)
        self.trigger_replanner_sub = rospy.Subscriber('/replan_trigger',Int32, self.trigger_update_callback(self))
        self.traj_array_complete = []
        self.current_traj_array = []
        self.current_tau_array = []
        
        for idx in range(0,len(self.agent_idx_to_name)):
            agent_name = agent_idx_to_name[idx]

            self.agent_poses.append(PoseStamped())
            self.agent_state_traj_array.append(Int32MultiArray())
            self.agent_traj_array.append(TWTLTrajectory())
            self.traj_array_complete.append(0)
            self.current_traj_array.append([])
            self.current_tau_array.append([])

            self.sub_array.append(rospy.Subscriber('/{}/pose'.format(agent_name),PoseStamped, self.waypoint_callback(self,idx)))
            #self.state_sub_array.append(rospy.Subscriber('/{}/state_trajectory'.format(agent_name),Int32MultiArray, self.states_traj_callback(self,idx)))
            self.traj_sub_array.append(rospy.Subscriber('/{}/trajectory'.format(agent_name),TWTLTrajectory, self.traj_callback(self,idx)))
        self.rate = rospy.Rate(20)

    def waypoint_callback(self,data,idx):
        self.agent_poses[idx] = data
    
    #def states_traj_callback(self,data,idx):
    #    self.agent_state_traj_array[idx] = data

    def traj_callback(self,data,idx):
        self.agent_traj_array[idx] = data
        temp_traj,temp_tau = convert_srv_msg_2_traj(data)
    
        self.current_traj_array[idx] = temp_traj
        self.current_tau_array[idx] = temp_tau
    
    def replan_message_callback(self,data):
        self.replan_monitor_message.data = data
        
    def trigger_update_callback(self,data):
        self.trigger_replan.data = data
    
    def Paths2SubteamPlans(self,subteam_idx):
        sub_agents = [self.m.agents[int(y)] for y in formula_decomp[subteam_idx]['agents']]
        for i in sub_agents:
            traj_points = []
            for pts in self.agent_traj_array[i]:
                traj_points.append([pts.pose.position.x,pts.pose.position.y])

    def convert_pose_traj_to_state_traj_array(self):
        new_state_array = []
        for trajs in self.current_traj_array:
            new_state_sub_array = []
            for point in trajs:
                region_idx = self._in_which_region(point[:3])
                new_state_sub_array.append(region_idx)
            new_state_array.append(new_state_sub_array)
        
        return new_state_array
    
    def _in_which_region(self,point):
        #self.region_bounds =>[[state_int,x_min,x_max,y_min,y_max]] 
        region_index = []
        for region in self.region_bounds:
            if point[1] < region[2] and point[1] > x_min and point[2] < y_max and point[2] > y_min:
                region_index.append(point[0])
        if len(region_index) == 1:
            region_int = region_index[0]
        else: 
            region_int = region_index
        
        return region_int

    def main_run(self,G_models, r_datas, m, ts, subteam_plans,formula_decomp): 
        self.gur_mod_array = G_models
        self.r_datas = r_datas
        self.ts = ts
        self.m = m
        self.formula_decomp = formula_decomp
        self.subteam_plans = subteam_plans
        self.trigger_replan.data = 1
        self.heir_not_triggered = 1
        self.replan_monitor_message.data = [-1,-1,-1,1,-1,0,0]
        self.dropped_agents = []
        self.capabilities = set.union(*[cap for _, cap in self.m.agents])
        self.capabilities = {c: 1<<k for k, c in enumerate(self.capabilities)}
        self.live_agents = m.agents
        #print(subteam_plans)
        
        self.region_bounds = generate_world_mapping(ts)
        
        self.reM_time = self.replan_monitor_message.data[0]
        self.reM_region = self.replan_monitor_message.data[1] 
        self.reM_cap = self.replan_monitor_message.data[2]
        self.reM_number = self.replan_monitor_message.data[3]
        self.reM_agents = self.replan_monitor_message.data[4:3+int(self.reM_number)]
        self.reM_delay = self.replan_monitor_message.data[4+int(self.reM_number)]
        self.reM_delay_timeback = self.replan_monitor_message.data[5+int(self.reM_number)]
        failed_flag = False
        #Replanning Message Vars:
        self.reM_time = -1
        self.reM_region = -1 
        self.reM_cap = -1
        self.reM_number = 0
        self.reM_agents = []
        #for i in range(4,(4+self.reM_number))
        #    self.reM_agents.append()
         #   self.live_agents


        while not rospy.is_shutdown():
            if not self.trigger_replan.data == 0: 
                self.replanning_index.data += 1 
                if self.trigger_replan.data > 0 and self.heir_not_triggered:
                    #Subteam Replan 
                    for a in self.reM_agents:
                        if a not in self.dropped_agents:
                            self.dropped_agents.append(a)
                    print('replan_message',self.replan_monitor_message.data[4])
                    if self.replan_monitor_message.data[4] == 1:
                        #This is a delay case
                        print('Delay Case - Not yet implemented')
                    else:
                        #This is pure dropout
                        #Get the subteam_agents_here
                        subteam = [m.agents[int(y)] for y in formula_decomp[self.trigger_replan.data]['agents']]

                        print(self.trigger_replan.data)
                        current_gurobi_model = self.gur_mod_array[self.trigger_replan.data]
                        replan_data = self.r_datas[int(self.trigger_replan.data)]
                        #build the replan message format
                        self.replan_request = empty_struct()
                        self.replan_request.replan_req = True
                        self.replan_request.replan_time = self.replan_monitor_message.data[0]
                        self.replan_request.replan_region = 'q'+str(self.replan_monitor_message.data[1])
                        self.replan_request.replan_cap = self.replan_monitor_message.data[2]
                        self.replan_request.replan_num = self.replan_monitor_message.data[3]
                        self.replan_request.replan_grave = m.replan_grave
                        self.replan_request.index = self.replanning_index.data
                        print(replan_data.agents)
                        #replan based on message from monitor
                        self.gur_mod_array[int(self.trigger_replan.data)],failed_flag = route_online_replanning(current_gurobi_model,self.m,replan_data,self.replan_request)

                        if failed_flag:
                            #TO DO: Post Science - Consider reconfiguring subteams to add an agent to a failing team.
                            #Past is old team, dead flows to grave, new member flows in. New member's old team considers member dead on their end.
                            
                            #Alert Monitor to team structure change
                            self.hier_trig.data = 1
                            self.hier_pub.publish(self.hier_trig)
                            self.heir_not_triggered = 0
                            
                            #Call a full replan here because subteam replanning has failed:
                            regions = [u for u,d in ts.g.nodes(data=True)]
                            caps = [cap for cap in self.capabilities]
                            self.agent_state_traj_array = self.convert_pose_traj_to_state_traj_array()
                            past_states = ConvertTraj2CapArray(self.agent_state_traj_array,regions,caps,self.m.agents)
                            print("Kicking Up to Full Team Plan")
                            self.gur_mod_array,self.r_datas,failed_flag = ReplanSubTeam2FullTeam(inputs,ts, agents, formula, past_states, dead_agent_idxs, bound=None,file_name='rebuilt_team',robust=False,regularize=False,alpha=0.5,upperBound=False)
                            
                            if failed_flag:
                                print('Critical Failure - Spec No Longer Satisfied - Revert to Failure Mode')
                            
                            else:
                                #Need to update trajectories and TWTL trees
                                #Test for combining sub_team trajs into one setup 
                                print('Made it to team trajectory rebuild!')
                                FullTeamRebuild = np.empty((len(m.agents),int(m.max_len)),dtype=object) #[Agents][Max_Times]
                                for x in formula_decomp.keys():
                                    subteam = list(formula_decomp[x]['agents'])
                                    agent_idx_local = 0
                                    for agent_idx_global in subteam:
                                        the_agent_plan = the_subteam_plans[x][int(agent_idx_local)]
                                        this_plan_len = len(the_agent_plan)
                                        if this_plan_len<m.max_len:
                                            #Need to lengthen path to match longest path length
                                            final_state_to_append = the_agent_plan[this_plan_len-1]
                                            FullTeamRebuild[int(agent_idx_global)][0:this_plan_len] = the_agent_plan
                                            for i in range(this_plan_len-1,m.max_len):
                                                FullTeamRebuild[int(agent_idx_global)][i] = final_state_to_append
                                        #add the traj to the array    
                                        agent_idx_local += 1 
                                #THIS CODE NEEDS TO BE UPDATED HERE:

                                old_plan = FullTeamRebuild
                                ########################################
                                #Need to determine where new data is held and what the replan request actually is 
                                #Replan request might have changed since we are re-rereplanning - not sure how that interaction happens (I think their positions are just set to constant?)
                                #We might get replanning issues becuase of non-determine in new sol but hopefully this is solved above?
                                #Need to build out replan request as well!

                                new_data = pd.read_csv("rebuilt_team.sol",sep='\n')
                                the_new_plan = run_replanner(m,ts,new_data,the_old_plan,replan_request)
                                pickle.dump(the_new_plan,open(m.save_filename+".pkl","w"))

                                #Need to repackage data for trajectories 
                                #Get TWTL Specs for region level trajectory
                                ###THIS COULD BE PARALLELIZED - IT IS NOT DEPENDANT ON OTHER TEAMS###
                                twtl_specs,region_trajs = CatlSol2Twtl_main(data,ts,m.save_filename,planning_step_time=m.planning_step_time)

                                #Save the specs and region lvl trajectories
                                pickle.dump(twtl_specs, open(m.save_filename+"_TWTL_specs"+str(x)+".pkl", "w"))
                                pickle.dump(region_trajs, open(m.save_filename+"_regionlvl_trajs"+str(x)+".pkl", "w"))

                                team_trees,team_taus = TWTLTraj2Tree(twtl_specs,the_plan,region_trajs,ts)
                                print('dumped TWTL for team '+str(x))
                                pickle.dump(team_trees, open(m.save_filename+"_TWTL_TeamTrees"+str(x)+".pkl", "w"))
                                pickle.dump(team_taus, open(m.save_filename+"_TWTL_TeamTaus"+str(x)+".pkl", "w"))



                        else:
                            #Need to update trajectories and TWTL trees

                            ##THIS CODE NEEDS UPDATING FROM OTHER CASE
                            new_data = pd.read_csv(m.save_filename+"replan.sol",sep='\n')
                            the_new_plan = run_replanner(m,ts,new_data,the_old_plan,replan_request)
                            pickle.dump(the_new_plan,open(m.save_filename+".pkl","w"))

                            #Get TWTL Specs for region level trajectory
                            ###THIS COULD BE PARALLELIZED - IT IS NOT DEPENDANT ON OTHER TEAMS###
                            twtl_specs,region_trajs = CatlSol2Twtl_main(data,ts,m.save_filename,planning_step_time=m.planning_step_time)

                            #Save the specs and region lvl trajectories
                            pickle.dump(twtl_specs, open(m.save_filename+"_TWTL_specs"+str(x)+".pkl", "w"))
                            pickle.dump(region_trajs, open(m.save_filename+"_regionlvl_trajs"+str(x)+".pkl", "w"))

                            team_trees,team_taus = TWTLTraj2Tree(twtl_specs,the_plan,region_trajs,ts)
                            print('dumped TWTL for team '+str(x))
                            pickle.dump(team_trees, open(m.save_filename+"_TWTL_TeamTrees"+str(x)+".pkl", "w"))
                            pickle.dump(team_taus, open(m.save_filename+"_TWTL_TeamTaus"+str(x)+".pkl", "w"))

                            #Update this to reflect save locations for individual sub-teams


                elif self.trigger_replan.data < 0 and self.heir_not_triggered:
                    #Full team replan from decomposed teams 
                    if self.replan_monitor_message[4] == 1:
                        #This is a delay case
                        print('Delay Case - Not yet implemented')

                    else:
                        #This is pure dropout
                        
                        #Need to edit agent set to reflect dropout:
                        
                        new_agents = self.m.agents
                        
                        #Reconstruct the formula decomp with new agents
                        #FOR SCIENCE WE JUST USE FULL SPEC



                        #current_gurobi_model = self.gurobi_models_array[int(self.trigger_replan)]
                        #replan_data = r_datas[int(self.trigger_replan)]
                        #build the replan message format
                        self.replan_request = empty_struct()
                        self.replan_request.replan_req = True
                        self.replan_request.replan_time = self.replan_monitor_message[0]
                        self.replan_request.replan_region = 'q'+str(self.replan_monitor_message[1])
                        self.replan_request.replan_cap = self.replan_monitor_message[2]
                        self.replan_request.replan_num = self.replan_monitor_message[3]
                        self.replan_request.replan_grave = m.replan_grave
                        self.replan_request.index = self.replanning_index.data
                        #replan based on message from monitor
                        self.gurobi_models_array[int(self.trigger_replan)],self.r_datas[int(self.trigger_replan)] = route_online_replanning(current_gurobi_model,self.m,replan_data,replan_request)


                        #Update this to reflect save locations for individual sub-teams
                        new_data = pd.read_csv(m.save_filename+"replan.sol",sep='\n')
                        the_new_plan = run_replanner(m,ts,new_data,the_old_plan,replan_request)
                        pickle.dump(the_new_plan,open(m.save_filename+".pkl","w"))

                elif self.trigger_replan.data < 0 and not self.heir_not_triggered:
                    #Full team replan from already recomposed team
                    print('full replan from full team - not implemented here')
                else: 
                    #Nothing has changed in team satisfaction
                    self.index_pub.publish(self.replanning_index)
                
                
                
                
                self.index_pub.publish(self.replanning_index)
                '''
                replan_request = empty_struct()
                replan_request.replan_req = m.replan_req
                replan_request.replan_time = m.replan_time
                replan_request.replan_region = m.replan_region
                replan_request.replan_grave = m.replan_grave
                replan_request.replan_num = m.replan_num
                replan_request.replan_cap = m.replan_cap
                replan_request.index = 0
                '''
            else:
                print('Waiting for failure')
if __name__== "__main__":
    test_srt = Replanner_main()
    test_srt.main_run()