# -*- coding: utf-8 -*-
'''
#LL Copyright
#This material is based upon work supported by the Under Secretary of Defense for Research and Engineering under Air Force Contract No. FA8702-15-D-0001. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the Under Secretary of Defense for Research and Engineering.
#© 2019 Massachusetts Institute of Technology.
#The software firmware is provided to you on an As-Is basis
#Delivered to the U.S. Government with Unlimited Rights, as defined in DFARS Part 252.227-7013 or 7014 (Feb 2014). Notwithstanding any copyright notice, U.S. Government rights in this work are defined by DFARS 252.227-7013 or DFARS 252.227-7014 as detailed above. Use of this work other than as specifically authorized by the U.S. Government may violate any copyrights that exist in this work.
#LL Copyright
'''
import numpy as np
import pandas as pd
from lomap import Ts
import networkx as nx
import pickle
import sys
from rrt_planning import RRT_Get_Path

from shapely.geometry import Point
from shapely.geometry.polygon import Polygon


#FOR VIDEO - Uncomment two lines below
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.animation import FFMpegWriter
import matplotlib.pyplot as plt


from visualization import show_environment_agents
from visualization import show_transition_agents
from visualization import show_world
import time as timer

###############################################################################
#Parse Data from sol file
###############################################################################
def read_sol_data(data,ts):
    #This is the data file to parse - designed for gurobi.sol files
    #data = pd.read_csv("isrr2019.sol",sep='\n')
    var_data = data.as_matrix()
    states = []
    edges = []

    # obstacleList[0] - Ground obstacles
    # obstacleList[1] - Mid-air obstacles
    # obstacleList[2] - top-Air obstacles

    #temp_edge_weights = nx.get_edge_attributes(ts.g,'weight')
    
    #record last time 
    end_time = 0
    
    #record_max_weight
    max_weight = 0
    
    #This loop extracts the states and edges from the solution and puts them into a numpy array
    for i in range(1,len(var_data)):

        if var_data[i,0][0] is 'z' and var_data[i,0][2] is 'q':
            #States
            if var_data[i,0].count('q')==1:
                vars = var_data[i,0].split("_")
                time_state = vars[3].split(" ")
                time = time_state[0]
                num = time_state[1]
                state = vars[1].replace("q","")
                cap = vars[2]
                if int(time) > end_time:
                    end_time = int(time)
                if int(num) > 0:
                    states.append([int(state),int(time),int(cap),int(num)])
            #Edges
            if var_data[i,0].count('q')==2:
                vars = var_data[i,0].split("_")
                time_state = vars[4].split(" ")
                time = time_state[0]
                num = time_state[1]
                state1 = vars[1].replace("q","")
                state2 = vars[2].replace("q","")
                cap = vars[3]
                if not 'grave' in ts.g.node['q'+str(state1)]['prop'] and not 'grave' in ts.g.node['q'+str(state2)]['prop']:
                    weight = ts.g.edge['q'+str(state1)]['q'+str(state2)]['weight']
                    if weight > max_weight:
                        max_weight = weight
                if int(time) > end_time:
                    end_time = int(time)
                #weight = temp_edge_weights[('q'+str(state1),'q'+str(state2))]
                if int(num) > 0:
                    edges.append([int(state1),int(state2),int(time),weight,int(cap),int(num)])
    
    # populate an array with p_vars
    # entries are label, predicate, time, state, count
    p_vars = [x[0] for x in var_data if x[0][0:2]=='p_']
    preds = []
    map(lambda x: preds.append([x.split('_')[1],x.split('_')[2],x.split('_')[3],x.split('_')[4].split(' ')[0],x.split('_')[4].split(' ')[1]]), p_vars)
    np.asarray(preds)
    
    #Make them numpy arrays
    states = np.asarray(states)
    #print(states)
    edges = np.asarray(edges)
    print('time_params',end_time,max_weight)
    return states,edges,(end_time+max_weight),preds
    
    
###############################################################################
#Check if point is in past trajectory obstacle
###############################################################################    
def collision_check(point,current_time,radius,past_paths=None):
    in_obs = False
    if past_paths != None:
        past_obs = []
        for i in range(0,len(past_paths)):
            #print(past_paths)
            past_obs.append((past_paths[i][(current_time)]+[radius*2]))
        for j in range(len(past_obs)):
            d = np.power((np.power(past_obs[j][0]-point[0],2)+np.power(past_obs[j][1]-point[1],2)),0.5)
            if d < 2*radius:
                in_obs = True
    return in_obs


###############################################################################
#Find bounds for planning between regions
###############################################################################
def split_bounds_for_rrt(region1,region2,bounds,overlaps):
    new_bounds = []
    for region,set in bounds:
        if region != region1 and region!= region2 and region not in overlaps[region1] and region not in overlaps[region2]:
            new_bounds.append((set))
    return(new_bounds)

###############################################################################
#Find bounds for planning between regions with box world
###############################################################################
def split_box_bounds_for_rrt(region1,region2,box_bounds,overlaps):
    new_box_bounds = []
    for region,set in box_bounds:
        if region != region1 and region!= region2 and region not in overlaps[region1] and region not in overlaps[region2]:
            new_box_bounds.append(set)
    return new_box_bounds

###############################################################################
#Find bounds of single region
###############################################################################
def single_region_bounds_for_rrt(region,bounds,overlaps):
    new_bounds = []
    for regions,set in bounds:
        if regions != region and regions not in overlaps[region]:
            new_bounds.append((set))
    return(new_bounds)


###############################################################################
#Find bounds of single region in box world
###############################################################################
def single_region_box_bounds_for_rrt(region,box_bounds,overlaps):
    new_box_bounds = []
    for regions,set in box_bounds:
        if regions != region and regions not in overlaps[region]:
            new_box_bounds.append((set))
    return(new_box_bounds)


###############################################################################
#Find a random point in a given region given past trajectories
###############################################################################
def random_point_in_region(region,radius=1,past_paths=None,current_time=None,other_obstacles=[],over_inc=None,plot_region_bounds=None):
    
    if plot_region_bounds == None:
        bounds = [0+radius+.1, 160-radius-.1, 0+radius+.1, 60-radius-.1]
    else:
        bounds = [plot_region_bounds[0]+radius+.1, plot_region_bounds[1]-radius-.1, plot_region_bounds[2]+radius+.1, plot_region_bounds[3]-radius-.1]
    if len(other_obstacles) > 0:
        non_region_obstacles = other_obstacles
    else:
        non_region_obstacles = [[0,0,0],[0,0,0]]
    past_obs = []
    if over_inc == None:
        if past_paths != None and current_time != None:
            for i in range(0,len(past_paths)):
                past_obs.append((past_paths[i][current_time]+[radius]))
            non_region_obstacles = np.concatenate((non_region_obstacles,past_obs))
    else:
        if past_paths != None and current_time != None:
            for i in range(0,len(past_paths)):
                for y in range(0,over_inc):
                    if current_time-y > 0:
                        #print current_time
                        #print y
                        past_obs.append((past_paths[i][(current_time-y)]+[radius]))
                    past_obs.append((past_paths[i][(current_time+y)]+[radius]))
            non_region_obstacles = np.concatenate((non_region_obstacles,past_obs))
    no_point = True
    count = 0
    while no_point == True:
        if count > 1000:
            #print('Point Stuck in Unforseen Obstacle - Please Try Again')
            break
        else:
            randx = np.multiply((np.multiply(np.random.rand(),2)-1),(region[2])) + region[0]
            randy = np.multiply((np.multiply(np.random.rand(),2)-1),(region[2])) + region[1]
            in_obs = False
            for ox,oy,size in non_region_obstacles:
                d = np.power((np.power(ox-randx,2)+np.power(oy-randy,2)),0.5)
                if d < size+radius+1:
                    in_obs = True
            if in_obs == False:

                if randx < bounds[0] or randx > bounds[1] or randy < bounds[2] or randy > bounds[3]:
                    no_point = True
                else:
                    no_point = False
            count = count+1


    rand_point = [randx,randy]
    #print(non_region_obstacles,rand_point)
    return(rand_point)




###############################################################################
#Generate Individual Region Trajectories
###############################################################################
def assign_caps_to_trajs(states,edges,preds,sim_time,replan_agent=None,grave_state=None,start_time=0,replan_agent_idx=None,replanning_time=None):
    #grave_state needs to be just an int
    
    end_time = sim_time
    caps = np.unique(states[states[:,1]==0,2])
    agent_caps = []
    num_caps = np.zeros(len(caps))
    cap_idx = np.zeros(len(caps))
    counts = 0
    init_states = states[states[:,1]==0]

    time_stamps = np.asarray(states[:,1])

    #Count agents and capabilities
    for i in caps:
        choice_vals = np.where(states[states[:,1]==0,2]==i)
        num_caps[counts]=np.sum(init_states[choice_vals,3])
        for j in range(0,num_caps[counts].astype(int)):
            agent_caps.append(i)
        counts = counts+1

    num_agents = np.sum(num_caps).astype(int)
    agent_positions = np.empty((end_time,num_agents),dtype=object)
    transit_times = np.zeros((end_time,num_agents))

    #initialize trajectory
    for i in caps:
        num_of_type = 0
        choice_vals = np.where(states[states[:,1]==0,2]==i)
        for j in choice_vals[0]:
            past_num = num_of_type
            num_of_type = num_of_type + init_states[j,3]
            region_of_type = init_states[j,0]
            cap_idxs = np.where(agent_caps == i)
            for k in range(past_num,num_of_type):
                agent_positions[0,cap_idxs[0][k]] = (region_of_type.astype(int))

    edge_timer = np.zeros(num_agents)
    
    for t in range(start_time,sim_time):

        current_edge = edges[edges[:,2]==t]
        already_assigned = np.zeros(num_agents)
        #Update Edge Timing
        transit_times[t] = edge_timer
        edge_timer = edge_timer-1
        edge_timer[edge_timer<0] = 0
        #Prevent moving agents from being assigned
        already_assigned[edge_timer>0] = 1

        #Prevent Dropped out agents to be assigned
        if not replan_agent_idx == None and t >= replanning_time:
            for dx in range(0,len(replan_agent_idx)):
                already_assigned[replan_agent_idx[dx]] = 1
                agent_positions[t,replan_agent_idx[dx]] = grave_state

        #insert line where if edge_timer > 0 with -1 then assigned
        for i in caps:
            num_of_type = 0
            choice_vals = np.where(current_edge[:,4]==i)
            for j in choice_vals[0]:
                eval_edge = current_edge[j,:]
                not_assigned = np.where(already_assigned== 0)
                current_cap = np.where(agent_caps==eval_edge[4])
                not_assigned = np.intersect1d(not_assigned,current_cap)
                free_agents = np.where(agent_positions[t,not_assigned] == eval_edge[0])
                available = not_assigned[free_agents[0]]
                available = np.asarray(available)

                if available.size < eval_edge[5]:
                    print('error time:',t)
                    print('available: ',available.size,' asking for: ',eval_edge[5])
                    exit('Requested Agents Not Available')
                for itr in range(0,eval_edge[5]):
                    if eval_edge[0] == eval_edge[1]:
                        #Agents stay in the same place
                        already_assigned[available[itr]] = 1
                        edge_timer[available[itr]] = 1
                        agent_positions[t+1][available[itr]] = eval_edge[0]
                    else:
                        #Agents enter edge
                        already_assigned[available[itr]] = 1
                        edge_timer[available[itr]] = eval_edge[3]
                        for idx in range(0,eval_edge[3]):
                            #On last iteration, make agent at position
                            if (t+idx+1)==sim_time:
                                time_idx = sim_time-1
                            else:
                                time_idx = t+idx+1

                            if idx >= eval_edge[3]-1:
                                agent_positions[time_idx][available[itr]] = eval_edge[1]
                            else:
                                agent_positions[time_idx][available[itr]] = [eval_edge[0],eval_edge[1],eval_edge[3]]

    #Catch agents that stay at states for multiple time steps
    for t in range(0,sim_time):
        for n in range(0,num_agents):
            if transit_times[t,n] == 0:
                if agent_positions[t,n] == None:
                    agent_positions[t,n] = agent_positions[t-1,n]

    return agent_positions,caps,num_agents,transit_times,agent_caps


###############################################################################
#Determine Which Agents to Drop Out From Request
###############################################################################
def which_agent_down(the_plan,ts,agent_caps,where,quant,cap,time,step_time,world_max):
    #need to determine dropout agents given cap,qant,time,where
    #dropout_agents is [#,#,#] with # as agent index
    dropout_agents = []
    for a in range(0,len(agent_caps)):
        if agent_caps[a] in cap:
            for test_points in the_plan[a][time:time+step_time]: 
                #print(test_points)              
                point = Point(test_points[0],world_max[1]-test_points[1])
                polygon = Polygon(ts.g.node[where]['shape'])
                #print(ts.g.node[where]['shape'])
                #print(polygon.contains(point))
                if polygon.contains(point):
                    if len(dropout_agents) < quant:
                        dropout_agents.append(a)
                        break  
    return dropout_agents


###############################################################################
#Generate Region Bound Definitions
#We also determine overlapping regions here
###############################################################################
def define_region_bounds(ts,state):
    
    region_bounds = []
    box_bounds_obstacleList = []
    overlapping_regions = []
    for state in ts.g.node:
        overlapping_regions.append([])
        #print(state)
        state_int = np.int(state[1:len(state)])
        bounds = ts.g.node[state]['shape']
        num_points = len(bounds)
        x_max = -10000
        x_min = 10000
        y_max = -10000
        y_min = 10000
        for idx in range(0,num_points):

            if bounds[idx][0] < x_min:
                x_min = bounds[idx][0]
            if bounds[idx][0] > x_max:
                x_max = bounds[idx][0]
            if bounds[idx][1] < y_min:
                y_min = bounds[idx][1]
            if bounds[idx][1] > y_max:
                y_max = bounds[idx][1]
        dia_x = np.divide((x_max - x_min),2)
        dia_y = np.divide((y_max - y_min),2)
        cent_x = np.average([x_min,x_max])
        cent_y = np.average([y_min,y_max])

        diameter = np.min([dia_x,dia_y])
        region_bounds.append([state_int,[cent_x,cent_y,diameter]])
        box_bounds_obstacleList.append([state_int,[x_min,x_max,y_min,y_max]])

    for region1 in box_bounds_obstacleList:
        for region2 in box_bounds_obstacleList:
            if not region1[0] == region2[0]:
                x1_min = region1[1][0]
                x1_max = region1[1][1]
                y1_min = region1[1][2]
                y1_max = region1[1][3] 
                x2_min = region2[1][0]
                x2_max = region2[1][1] 
                y2_min = region2[1][2]
                y2_max = region2[1][3]
                if not ((x1_min >= x2_max) or (x1_max <= x2_min) or (y1_max <= y2_min) or (y1_min >= y2_max)):
                    overlapping_regions[region1[0]].append(region2[0])
    return region_bounds,box_bounds_obstacleList,overlapping_regions


###############################################################################
#Generate Trajectories from a .sol file
###############################################################################
def run_planner(m,ts,data,other_past_paths=[]):
    start = timer.time()
    
    #get all the environment variables from m
    plot_region_bounds = m.plot_region_bounds
    obstaclesList = m.local_obstacles
    max_attempts = m.max_attempts
    max_rrt_time = m.max_rrt_time
    agent_radius = m.agent_radius
    planning_step_time = m.planning_step_time
    cap_height_map = m.cap_height_map
    record_sol = m.record_sol
    show_sol = m.show_sol
    grave_state = m.grave_state
    
    
    for u, v in ts.g.edges():
        assert ts.g.has_edge(v, u)

    #Take the data and parse it into state and edge transitions
    states,edges,end_time,preds = read_sol_data(data,ts)
    sim_time = end_time

    print('time_vals',sim_time, planning_step_time)

    ###############################################################################
    #Generate individual region level trajectories
    ###############################################################################
    agent_positions,caps,num_agents,transit_times,agent_caps = assign_caps_to_trajs(states,edges,preds,sim_time)
    
    
    ###############################################################################
    #Generate Region Bound Definitions
    ###############################################################################
    region_bounds,box_bounds_obstacleList,overlapping_regions = define_region_bounds(ts,states)
   

    ###############################################################################
    #Obstacles and capability differentiation
    ###############################################################################
    #Include any unforseen or hard coded obstacles or force agents to be on different planes of operation
    #cap_height_map = np.array([1,0,0,0,0,0,0,2,2,2])
   
    #obstaclesList  = [[
    #    [0,0,0],
    #    [0,0,0]
    #],
    #[
    #    [0,0,0],
    #    [0,0,0]
    #],
    #[
    #    [0,0,0],
    #    [0,0,0]
    #]
    #]
    
    ###############################################################################
    #Generate low level trajectories
    ###############################################################################
    #I do this sequentally so it is less book keeping. It shouldnt really matter
    #since the paths are computed sequentally in rrt anyway.

    #agent_radius = [6,4,4,4,4,4,4,2,2,2]
    #agent_radius = np.multiply(np.ones(10),2)

    #planning_step_time = 10
    found_the_plan = False
    restart_main_loop =False
    #Main Loop Begins Here:
    while found_the_plan == False:
        restart_main_loop = False
        the_plan = np.empty((num_agents,int(np.multiply(planning_step_time,sim_time))),dtype=object)
        past_paths = []
        count_idx = 0
        past_a = []

        for a in np.random.permutation(range(0,num_agents)):
            if restart_main_loop == True:
                found_the_plan = False
                print('found: ',a)
                break
            #print(a)
        ################################################################################
        #Determine which past paths to consider given agent capabilities (flying or not)
        ################################################################################
            past_path_idxs = np.where(cap_height_map == cap_height_map[a])
            to_avoid = np.intersect1d(past_path_idxs,past_a)
            
            cap_past_paths = []
            #if other_past_paths == []: 
            #    if len(to_avoid) != 0:
            #        for num in range(0,len(to_avoid)):
            #            index = np.where(past_a == to_avoid[num])
            #            cap_past_paths.append(past_paths[index[0][0]])
            #    else:
            #        cap_past_paths = None
            
            
            
        ####################### MAY NEED TO REMOVE THIS ################################
        #THIS MAKES ALL AGENTS INTO LARGE OBSTACLES FOR EXPERIMENT#
            #else: 
            #    cap_past_paths.append(past_paths)
            #print('other_shape: ',np.shape(other_past_paths),'orig_shape ',np.shape(past_paths))
            for paths in other_past_paths: 
                cap_past_paths.append(paths)
            for paths in past_paths:
                cap_past_paths.append(paths)
            obstacles = obstaclesList[cap_height_map[a]]    
            #print(np.shape(cap_past_paths))
        ################################################################################
        #Cycle through actions for agent
        ################################################################################

            for t in range(0,sim_time):
                if restart_main_loop == True:
                    found_the_plan = False
                    break
                start_point = None
                time_idx = int(np.multiply(planning_step_time,t))
                if np.size(the_plan[a,time_idx]) < 2:
                    action = agent_positions[t,a]
                    #if a == 6:
                    #    print(agent_positions[:,6],action,t,time_idx)
                    if time_idx-1 >= 0:
                        if np.size(the_plan[a,time_idx-1])>1:
                            start_point = the_plan[a,time_idx-1]
                        else:
                            start_point = None
                    else:
                        start_point = None


                    ##Find Random Start Positions:
        ###############################################################################
        #Determine start positions
        ###############################################################################

                    if np.size(action) == 1 and not (grave_state in [action]):
                        if np.size(start_point) > 1:
                            collision = False
                            for inc in range(0,planning_step_time):
                                if (collision_check(start_point,time_idx+inc,agent_radius[a],cap_past_paths)):
                                        collision = True
                            if collision:
                                for region,set in region_bounds:
                                    if region == action:
                                        if count_idx>0:
                                            other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            other_box_regions = single_region_box_bounds_for_rrt(action,box_bounds_obstacleList,overlapping_regions)
                                            rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time=time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                        else:
                                            other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            other_box_regions = single_region_box_bounds_for_rrt(action,box_bounds_obstacleList,overlapping_regions)
                                            rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)

                                if cap_past_paths!=None:
                                    timed_past_paths = []
                                    for w in range(0,len(cap_past_paths)):
                                        timed_past_paths.append(cap_past_paths[w][(time_idx):])
                                else:
                                    timed_past_paths = None

                                other_regions = np.concatenate((other_regions,obstacles))
                                no_short_path = True
                                collision_idx = 0
                                while no_short_path == True:
                                    candidate_path = RRT_Get_Path(regions_to_avoid=other_regions,start=start_point,goal=rand_point,past_paths=timed_past_paths,start_region=None,goal_region=None,agentnum=a,agent_radius=agent_radius,expandDis=1,bounds=plot_region_bounds,max_rrt_time=max_rrt_time,box_bounds_obs_regions=other_box_regions)

                                    len_cand_path = len(candidate_path)
                                    if len_cand_path > planning_step_time or len_cand_path == 0:
                                        collision_idx +=1
                                        if collision_idx >4:
                                            restart_main_loop = True
                                            found_the_plan = False
                                            break
                                        for region,set in region_bounds:
                                            if region == action:
                                                if count_idx>0:
                                                    other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                                    other_regions = np.concatenate((obstacles,other_regions))
                                                    rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time=time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                                else:
                                                    other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                                    other_regions = np.concatenate((obstacles,other_regions))
                                                    rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)

                                    elif len_cand_path == planning_step_time:
                                        no_short_path = False
                                        the_plan[a,time_idx:time_idx+planning_step_time] = candidate_path
                                    else:
                                        diff_len = planning_step_time-len_cand_path
                                        the_plan[a,time_idx:time_idx+len_cand_path]=candidate_path
                                        for dif_inc in range(0,diff_len):
                                            the_plan[a,time_idx+len_cand_path+dif_inc] = candidate_path[len_cand_path-1]
                                        no_short_path = False

                            else:
                                for inc in range(0,planning_step_time):
                                    the_plan[a,time_idx+inc] = start_point
                                #Check if this point is in any new past paths
                        else:
                            for region,set in region_bounds:
                                if region == action:
                                    if count_idx>0:
                                        other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time=time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                    else:
                                        other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                        #print other_regions
                                        #print obstacles
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                            for inc in range(0,planning_step_time):
                                the_plan[a,time_idx+inc] = rand_point
        #If agent needs to transistion, this determines start and end points
                    elif np.size(action) == 3 and not (grave_state in [action]):
                        #transition
                        if time_idx-1>=0:
                            if np.size(the_plan[a,time_idx-1])>1:
                                start_point = np.asarray(the_plan[a,time_idx-1])
                                start_region = None
                                for region,set in region_bounds:
                                    if region == action[1]:
                                        other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                        if count_idx > 0:
                                            other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths =cap_past_paths,current_time =time_idx+((action[2]-1)*planning_step_time),other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                            else:
                                start_point = None
                                for region,set in region_bounds:
                                    if region == action[0]:
                                        other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        start_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                    if region == action[1]:
                                        other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                        if count_idx > 0:
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = time_idx+((action[2]-1)*planning_step_time),other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                        else:
                            start_point = None
                            for region,set in region_bounds:
                                if region == action[0]:
                                    other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                    other_regions = np.concatenate((obstacles,other_regions))
                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = 0,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                if region == action[1]:
                                    other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                    other_regions = np.concatenate((obstacles,other_regions))
                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = 0,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                        regions_to_avoid = split_bounds_for_rrt(action[0],action[1],region_bounds,overlapping_regions)
                        box_regions_to_avoid = split_box_bounds_for_rrt(action[0],action[1],box_bounds_obstacleList,overlapping_regions)
                        #print 'obstacles: ',obstacles
                        #print 'regions_to_avoid: ',regions_to_avoid
                        #print 'action: ', action
                        if len(regions_to_avoid):
                            regions_to_avoid = np.concatenate((obstacles,regions_to_avoid))

                        if cap_past_paths!=None:
                            timed_past_paths = []
                            for w in range(0,len(cap_past_paths)):
                                timed_past_paths.append(cap_past_paths[w][(time_idx):])
                        else:
                            timed_past_paths = None


        ################################################################################
        #Compute RRT path
        ################################################################################

                        no_viable_path = True
                        loop_idx = 0
                        while no_viable_path==True:
                            loop_idx += 1
                            if loop_idx > max_attempts:
                                restart_main_loop = True
                                found_the_plan = False
                                break
                            if count_idx > 0:
                                #regions_to_avoid=regions_to_avoid
                                candidate_path = RRT_Get_Path(regions_to_avoid=regions_to_avoid,start=start_point,goal=goal_point,past_paths=timed_past_paths,start_region=None,goal_region=None,agentnum=a,agent_radius=agent_radius,expandDis=1,bounds=plot_region_bounds,max_rrt_time=max_rrt_time,box_bounds_obs_regions=box_regions_to_avoid)
                            else:
                                candidate_path = RRT_Get_Path(regions_to_avoid=regions_to_avoid,start=start_point,goal=goal_point,start_region=None,goal_region=None,agentnum=a,agent_radius=agent_radius,expandDis=1,bounds=plot_region_bounds,max_rrt_time=max_rrt_time,box_bounds_obs_regions=box_regions_to_avoid)
                            len_cand_path = len(candidate_path)
                            plan_time_bound = np.multiply(action[2]-1,planning_step_time)
                            if len_cand_path == 0:
                                if time_idx-1>=0:
                                    if np.size(the_plan[a,time_idx-1])>1:
                                        start_point = np.asarray(the_plan[a,time_idx-1])
                                        start_region = None
                                        for region,set in region_bounds:
                                            if region == action[1]:
                                                other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                                other_regions = np.concatenate((obstacles,other_regions))
                                                goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                                if count_idx > 0:
                                                    other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                                    other_regions = np.concatenate((obstacles,other_regions))
                                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths =cap_past_paths,current_time =t+((action[2]-1)*planning_step_time),other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                    else:
                                        start_point = None
                                        for region,set in region_bounds:
                                            if region == action[0]:
                                                other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                                other_regions = np.concatenate((obstacles,other_regions))
                                                start_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                            if region == action[1]:
                                                other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                                other_regions = np.concatenate((obstacles,other_regions))
                                                goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                                if count_idx > 0:
                                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = t+((action[2]-1)*planning_step_time),other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                else:
                                    start_point = None
                                    for region,set in region_bounds:
                                        if region == action[0]:
                                            other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                        if region == action[1]:
                                            other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)

                            elif len_cand_path <= plan_time_bound:
                                #put in loop to make extra hold points, and then slap that on the path and add it to the_plan
                                temp_hold = []
                                extra_hold = plan_time_bound - len_cand_path
                                hold_point = candidate_path[len_cand_path-1]
                                for extra in range(0,extra_hold):
                                    temp_hold.append(hold_point)
                                if np.size(temp_hold) > 1:
                                    candidate_path = np.concatenate((candidate_path,temp_hold))
                                else:
                                    candidate_path = candidate_path
                                for step in range(0,plan_time_bound):
                                    the_plan[a,time_idx+step] = candidate_path[step]

                                no_viable_path = False
                            else:
                                print(len_cand_path,plan_time_bound)
                                no_viable_path = True

                    elif (grave_state in [action]):
                        print("its dead")
                        for iters in range(t*planning_step_time,sim_time*planning_step_time):
                            the_plan[a,iters] = np.asarray([-100, -100])
                        break
                    else:
                        print('Unexpected Trajectory Sequence - Edges should be [start,end,time]')
            #print(restart_main_loop,found_the_plan)
            if restart_main_loop == True:
                found_the_plan = False
                break
            else:
                found_the_plan = True
            count_idx += 1
            past_a.append(a)
                    #if a == 6:
                    #    print(the_plan[a],action,t,time_idx)
            past_formatted = []
            #print(the_plan[a])
            for k in range(0,np.multiply(planning_step_time,sim_time)):
                past_formatted.append([the_plan[a][k][0],the_plan[a][k][1]])

            past_paths.append(past_formatted)


    the_plan = np.array(the_plan)

    # Draw final path


        #plt.plot([x for (x, y) in smoothedPath], [
        #    y for (x, y) in smoothedPath], '-b')
        #plt.plot(start[i][0], start[i][1], "or")
        #plt.plot(goal[i][0], goal[i][1], "xr")
    #plt.xlim(plot_bounds[0],plot_bounds[1])
    #plt.ylim(plot_bounds[2],plot_bounds[3])
    #plt.axis(plot_bounds)
    #plt.grid(True)
    #for (x, y, size) in obstacleList:
    #    PlotCircle(x, y, size,plot_bounds)
    #plt.pause(0.01)
    #plt.grid(True)
    #plt.pause(0.01)  # Need for Mac
    #plt.show()


    #new_bounds = split_bounds_for_rrt(0,1,region_bounds)

    #RRT_Get_Path(new_bounds,start=[(5,5)],goal=[(5,50)])


    end = timer.time()

    print('runtime:')
    print(end-start)
    runtime = end-start

    if show_sol:
        ###############################################################################
        #Print the Final Trajectories
        caps_idxs = np.unique(agent_caps)
        fig = plt.figure()
        plt.clf()
        fig,viewport = show_world(ts,fig)
        for i in range(0,num_agents):
            if agent_caps[i] == caps_idxs[0]:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-k')
            elif agent_caps[i] == caps_idxs[1]:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], ':k')
            elif agent_caps[i] == caps_idxs[2]:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '--g')
            elif agent_caps[i] == caps_idxs[3]:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-.r')
            elif agent_caps[i] == caps_idxs[4]:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-.b')


        plt.axis(plot_region_bounds)
        plt.show(block=False)
        plt.pause(1)
        plt.waitforbuttonpress()
        plt.clf()

        ###############################################################################
        #Play a video of the Trajectories
    if record_sol:
        metadata = dict(title='Traj_Sol', artist='Matplotlib',comment='Movie support!')
        writer = FFMpegWriter(fps=12, metadata=metadata)
        writer.setup(fig,'pre_replan_robust.mp4',1000)

        for time in range(0,(sim_time)):
            plt.clf()
            fig,viewport = show_world(ts,fig)
            for i in range(0,num_agents):
                if agent_caps[i] == 1:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],color="r",marker='x',markersize=15)
                elif agent_caps[i] == 2:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"oc",markersize=15)
                elif agent_caps[i] == 3:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"*w",markersize=15)
                elif agent_caps[i] == 8:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"hk",markersize=12)


            plt.axis(plot_region_bounds)
            plt.title('Time: ' + str(np.divide(time,10)))
            writer.grab_frame()
            plt.show(block=False)
            plt.pause(0.01)


    return(the_plan,agent_caps,past_paths)
    
    
    
def run_replanner(m,ts,data,the_old_plan,replan_request):

    #get all the environment variables from m
    plot_region_bounds = m.plot_region_bounds
    obstaclesList = m.local_obstacles
    max_attempts = m.max_attempts
    max_rrt_time = m.max_rrt_time
    agent_radius = m.agent_radius
    planning_step_time = m.planning_step_time
    cap_height_map = m.cap_height_map
    record_sol = m.record_sol
    show_sol = m.show_sol
    grave_state = m.grave_state
    dropout_time = m.replan_time
    
    for u, v in ts.g.edges():
        assert ts.g.has_edge(v, u)

    #Take the data and parse it into state and edge transitions
    states,edges,end_time,preds = read_sol_data(data,ts)
    sim_time = end_time

    
    num_agents = len(the_old_plan)
    the_plan = np.empty((num_agents,int(len(the_old_plan[0]))),dtype=object)
    for p in range(0,num_agents):
        for q in range(0,((dropout_time)*planning_step_time)):
            the_plan[p][q] = the_old_plan[p][q]
            #print(the_plan[p][q])
            
    
    
    start = timer.time()

    for u, v in ts.g.edges():
        assert ts.g.has_edge(v, u)

    #Take the data and parse it into state and edge transitions
    states,edges,end_time,preds = read_sol_data(data,ts)
    sim_time = end_time

    

    ###############################################################################
    #Generate individual region level trajectories
    ###############################################################################
    #agent_positions,caps,num_agents,transit_times,agent_caps = assign_caps_to_trajs(states,edges,preds,sim_time)
    
    agent_positions,caps,num_agents,transit_times,agent_caps = assign_caps_to_trajs(states,edges,preds,sim_time,replan_agent=None,grave_state=grave_state,start_time=0,replan_agent_idx=replan_request.index,replanning_time=dropout_time)
    
    
    ###############################################################################
    #Generate Region Bound Definitions
    ###############################################################################
    region_bounds,box_bounds_obstacleList,overlapping_regions = define_region_bounds(ts,states)

   

    ###############################################################################
    #Obstacles and capability differentiation
    ###############################################################################
    #Include any unforseen or hard coded obstacles or force agents to be on different planes of operation
    #cap_height_map = np.array([1,0,0,0,0,0,0,2,2,2])
   
    #obstaclesList  = [[
    #    [0,0,0],
    #    [0,0,0]
    #],
    #[
    #    [0,0,0],
    #    [0,0,0]
    #],
    #[
    #    [0,0,0],
    #    [0,0,0]
    #]
    #]
    
    ###############################################################################
    #Generate low level trajectories
    ###############################################################################
    #I do this sequentally so it is less book keeping. It shouldnt really matter
    #since the paths are computed sequentally in rrt anyway.

    #agent_radius = [6,4,4,4,4,4,4,2,2,2]
    #agent_radius = np.multiply(np.ones(10),2)

    #planning_step_time = 10
    found_the_plan = False
    restart_main_loop =False
    #Main Loop Begins Here:
    while found_the_plan == False:
        restart_main_loop = False
        #the_plan = np.empty((num_agents,int(np.multiply(planning_step_time,sim_time))),dtype=object)
        past_paths = []
        count_idx = 0
        past_a = []
        
        for a in np.random.permutation(range(0,num_agents)):
            if restart_main_loop == True:
                found_the_plan = False
                print('found: ',a)
                break
            print(a)
           
        ################################################################################
        #Determine which past paths to consider given agent capabilities (flying or not)
        ################################################################################
            past_path_idxs = np.where(cap_height_map == cap_height_map[a])
            to_avoid = np.intersect1d(past_path_idxs,past_a)
            #print(to_avoid)
            cap_past_paths = []
            if len(to_avoid) != 0:
                for num in range(0,len(to_avoid)):
                    index = np.where(past_a == to_avoid[num])
                    cap_past_paths.append(past_paths[index[0][0]])
            else:
                cap_past_paths = None
            obstacles = obstaclesList[cap_height_map[a]]
            
        ################################################################################
        #Cycle through actions for agent
        ################################################################################

            for t in range(dropout_time,sim_time):
                #if a in dropout_agents:
                 #   for iters in range(t*planning_step_time,sim_time*planning_step_time):
                  #      the_plan[a,iters] = np.asarray([10000, 10000])
                  #  continue
                   
                if restart_main_loop == True:
                    found_the_plan = False
                    break
                start_point = None
                time_idx = int(np.multiply(planning_step_time,t))
                if np.size(the_plan[a,time_idx]) < 2:
                    action = agent_positions[t,a]
                    #if a == 6:
                    #    print(agent_positions[:,6],action,t,time_idx)
                    if time_idx-1 >= 0:
                        if np.size(the_plan[a,time_idx-1])>1:
                            start_point = the_plan[a,time_idx-1]
                        else:
                            start_point = None
                    else:
                        start_point = None


                    ##Find Random Start Positions:
        ###############################################################################
        #Determine start positions
        ###############################################################################

                    if np.size(action) == 1 and not (grave_state in [action]):
                        if np.size(start_point) > 1:
                            collision = False
                            for inc in range(0,planning_step_time):
                                if (collision_check(start_point,time_idx+inc,agent_radius[a],cap_past_paths)):
                                        collision = True
                            if collision:
                                for region,set in region_bounds:
                                    if region == action:
                                        if count_idx>0:
                                            other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            other_box_regions = single_region_box_bounds_for_rrt(action,box_bounds_obstacleList,overlapping_regions)
                                            rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time=time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                        else:
                                            other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            other_box_regions = single_region_box_bounds_for_rrt(action,box_bounds_obstacleList,overlapping_regions)
                                            rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)

                                if cap_past_paths!=None:
                                    timed_past_paths = []
                                    for w in range(0,len(cap_past_paths)):
                                        timed_past_paths.append(cap_past_paths[w][(time_idx):])
                                else:
                                    timed_past_paths = None

                                other_regions = np.concatenate((other_regions,obstacles))
                                no_short_path = True
                                collision_idx = 0
                                while no_short_path == True:
                                    candidate_path = RRT_Get_Path(regions_to_avoid=other_regions,start=start_point,goal=rand_point,past_paths=timed_past_paths,start_region=None,goal_region=None,agentnum=a,agent_radius=agent_radius,expandDis=1,bounds=plot_region_bounds,max_rrt_time=max_rrt_time,box_bounds_obs_regions=other_box_regions)
                                    len_cand_path = len(candidate_path)
                                    if len_cand_path > planning_step_time or len_cand_path == 0:
                                        collision_idx +=1
                                        if collision_idx >4:
                                            restart_main_loop = True
                                            found_the_plan = False

                                            break
                                        for region,set in region_bounds:
                                            if region == action:
                                                if count_idx>0:
                                                    other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                                    other_regions = np.concatenate((obstacles,other_regions))
                                                    rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time=time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                                else:
                                                    other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                                    other_regions = np.concatenate((obstacles,other_regions))
                                                    rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)

                                    elif len_cand_path == planning_step_time:
                                        no_short_path = False
                                        the_plan[a,time_idx:time_idx+planning_step_time] = candidate_path
                                    else:
                                        diff_len = planning_step_time-len_cand_path
                                        the_plan[a,time_idx:time_idx+len_cand_path]=candidate_path
                                        for dif_inc in range(0,diff_len):
                                            the_plan[a,time_idx+len_cand_path+dif_inc] = candidate_path[len_cand_path-1]
                                        no_short_path = False

                            else:
                                for inc in range(0,planning_step_time):
                                    the_plan[a,time_idx+inc] = start_point
                                #Check if this point is in any new past paths
                        else:
                            for region,set in region_bounds:
                                if region == action:
                                    if count_idx>0:
                                        other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time=time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                    else:
                                        other_regions = single_region_bounds_for_rrt(action,region_bounds,overlapping_regions)
                                        #print other_regions
                                        #print obstacles
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        rand_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                            for inc in range(0,planning_step_time):
                                the_plan[a,time_idx+inc] = rand_point
        #If agent needs to transistion, this determines start and end points
                    elif np.size(action) == 3 and not (grave_state in [action]):
                        #transition
                        if time_idx-1>=0:
                            if np.size(the_plan[a,time_idx-1])>1:
                                start_point = np.asarray(the_plan[a,time_idx-1])
                                start_region = None
                                for region,set in region_bounds:
                                    if region == action[1]:
                                        other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                        if count_idx > 0:
                                            other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths =cap_past_paths,current_time =time_idx+((action[2]-1)*planning_step_time),other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                            else:
                                start_point = None
                                for region,set in region_bounds:
                                    if region == action[0]:
                                        other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        start_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = time_idx,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                    if region == action[1]:
                                        other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                        other_regions = np.concatenate((obstacles,other_regions))
                                        goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                        if count_idx > 0:
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = time_idx+((action[2]-1)*planning_step_time),other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                        else:
                            start_point = None
                            for region,set in region_bounds:
                                if region == action[0]:
                                    other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                    other_regions = np.concatenate((obstacles,other_regions))
                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = 0,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                                if region == action[1]:
                                    other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                    other_regions = np.concatenate((obstacles,other_regions))
                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = 0,other_obstacles=other_regions,over_inc=planning_step_time,plot_region_bounds=plot_region_bounds)
                        regions_to_avoid = split_bounds_for_rrt(action[0],action[1],region_bounds,overlapping_regions)
                        box_regions_to_avoid = split_box_bounds_for_rrt(action[0],action[1],box_bounds_obstacleList,overlapping_regions)
                        #print 'obstacles: ',obstacles
                        #print 'regions_to_avoid: ',regions_to_avoid
                        #print 'action: ', action
                        if len(regions_to_avoid):
                            regions_to_avoid = np.concatenate((obstacles,regions_to_avoid))

                        if cap_past_paths!=None:
                            timed_past_paths = []
                            for w in range(0,len(cap_past_paths)):
                                timed_past_paths.append(cap_past_paths[w][(time_idx):])
                        else:
                            timed_past_paths = None


        ################################################################################
        #Compute RRT path
        ################################################################################

                        no_viable_path = True
                        loop_idx = 0
                        while no_viable_path==True:
                            loop_idx += 1
                            if loop_idx > max_attempts:
                                restart_main_loop = True
                                found_the_plan = False
                                break
                            if count_idx > 0:
                                #regions_to_avoid=regions_to_avoid
                                candidate_path = RRT_Get_Path(regions_to_avoid=regions_to_avoid,start=start_point,goal=goal_point,past_paths=timed_past_paths,start_region=None,goal_region=None,agentnum=a,agent_radius=agent_radius,expandDis=1,bounds=plot_region_bounds,max_rrt_time=max_rrt_time,box_bounds_obs_regions=box_regions_to_avoid)
                            else:
                                candidate_path = RRT_Get_Path(regions_to_avoid=regions_to_avoid,start=start_point,goal=goal_point,start_region=None,goal_region=None,agentnum=a,agent_radius=agent_radius,expandDis=1,bounds=plot_region_bounds,max_rrt_time=max_rrt_time,box_bounds_obs_regions=box_regions_to_avoid)
                            len_cand_path = len(candidate_path)
                            plan_time_bound = np.multiply(action[2]-1,planning_step_time)
                            if len_cand_path == 0:
                                if time_idx-1>=0:
                                    if np.size(the_plan[a,time_idx-1])>1:
                                        start_point = np.asarray(the_plan[a,time_idx-1])
                                        start_region = None
                                        for region,set in region_bounds:
                                            if region == action[1]:
                                                other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                                other_regions = np.concatenate((obstacles,other_regions))
                                                goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                                if count_idx > 0:
                                                    other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                                    other_regions = np.concatenate((obstacles,other_regions))
                                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths =cap_past_paths,current_time =t+((action[2]-1)*planning_step_time),other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)

                                    else:
                                        start_point = None
                                        for region,set in region_bounds:
                                            if region == action[0]:
                                                other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                                other_regions = np.concatenate((obstacles,other_regions))
                                                start_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                            if region == action[1]:
                                                other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                                other_regions = np.concatenate((obstacles,other_regions))
                                                goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                                if count_idx > 0:
                                                    goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,current_time = t+((action[2]-1)*planning_step_time),other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                else:
                                    start_point = None
                                    for region,set in region_bounds:
                                        if region == action[0]:
                                            other_regions = single_region_bounds_for_rrt(action[0],region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)
                                        if region == action[1]:
                                            other_regions = single_region_bounds_for_rrt(action[1],region_bounds,overlapping_regions)
                                            other_regions = np.concatenate((obstacles,other_regions))
                                            goal_point = random_point_in_region(set,agent_radius[a],past_paths = cap_past_paths,other_obstacles=other_regions,plot_region_bounds=plot_region_bounds)

                            elif len_cand_path <= plan_time_bound:
                                #put in loop to make extra hold points, and then slap that on the path and add it to the_plan
                                temp_hold = []
                                extra_hold = plan_time_bound - len_cand_path
                                hold_point = candidate_path[len_cand_path-1]
                                for extra in range(0,extra_hold):
                                    temp_hold.append(hold_point)
                                if np.size(temp_hold) > 1:
                                    candidate_path = np.concatenate((candidate_path,temp_hold))
                                else:
                                    candidate_path = candidate_path
                                for step in range(0,plan_time_bound):
                                    the_plan[a,time_idx+step] = candidate_path[step]

                                no_viable_path = False
                            else:
                                #print(len_cand_path,plan_time_bound)
                                no_viable_path = True

                    elif (grave_state in [action]):
                        #From t to end of time - the agent is in the grave state - need to figure out how to deal with this - I think we just put them all at like -100
                        print("its dead")
                        for iters in range(t*planning_step_time,sim_time*planning_step_time):
                            the_plan[a,iters] = np.asarray([-100, -100])
                        break
                    else:
                        print('Unexpected Trajectory Sequence - Edges should be [start,end,time]')
            #print(restart_main_loop,found_the_plan)
            if restart_main_loop == True:
                found_the_plan = False
                break
            else:
                found_the_plan = True
            count_idx += 1
            past_a.append(a)
                    #if a == 6:
                    #    print(the_plan[a],action,t,time_idx)
            past_formatted = []
            #print(the_plan[a])
            for k in range(0,np.multiply(planning_step_time,sim_time)):
                #print(the_plan[a][k])
                if the_plan[a][k] is not None:
                    past_formatted.append([the_plan[a][k][0],the_plan[a][k][1]])
                else:
                    print(a,k,the_plan[a][k])

            past_paths.append(past_formatted)
            #print(the_plan[a])
            np.savetxt(str(a)+'_val_test.txt',the_plan[a],fmt='%s')    
                 

    the_plan = np.array(the_plan)    
    
    
    if show_sol:
        ###############################################################################
        #Print the Final Trajectories

        fig = plt.figure()
        plt.clf()
        fig,viewport = show_world(ts,fig)
        for i in range(0,num_agents):
            if agent_caps[i] == 1:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-k')
            elif agent_caps[i] == 2:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], ':k')
            elif agent_caps[i] == 3:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '--k')
            elif agent_caps[i] == 8:
                plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-.c')

        plt.axis(plot_region_bounds)
        plt.show(block=False)
        plt.pause(1)
        plt.waitforbuttonpress()
        plt.clf()
    
    if record_sol:
        metadata = dict(title='Traj_Sol', artist='Matplotlib',comment='Movie support!')
        writer = FFMpegWriter(fps=10, metadata=metadata)
        writer.setup(fig,'post_replan_robust.mp4',199)

        for time in range(0,(sim_time)):
            plt.clf()
            fig,viewport = show_world(ts,fig)
            for i in range(0,num_agents):
                if agent_caps[i] == 1:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],color="r",marker='x',markersize=15)
                elif agent_caps[i] == 2:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"oc",markersize=15)
                elif agent_caps[i] == 3:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"*w",markersize=15)
                elif agent_caps[i] == 8:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"hk",markersize=12)


            plt.axis(plot_region_bounds)
            plt.title('Time: ' + str(np.divide(time,10)))
            writer.grab_frame()
            plt.show(block=False)
            plt.pause(0.01)
    
    return the_plan,agent_caps,0
    
    
    
    
    
    
    
    
    
    
    
