
import glob
import pandas as pd
rootDir = '../OutputFiles/IJRR_Classes/'

files = glob.glob(rootDir+'*.csv')
csv_total = pd.concat([pd.read_csv(file)for file in files])#,rootDir+'Results_part3.csv']])

#csv_total = pd.concat([pd.read_csv(file)for file in [rootDir+'Results.csv',rootDir+'Results_part2.csv']])#,rootDir+'Results_part3.csv']])
csv_total.to_csv(rootDir+'Results_total.csv')
