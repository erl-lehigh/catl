import pandas as pd
import scipy.stats as st
import numpy as np

#This allows matplotlib to save pdfs - it will mess with video generation
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt


def get_statistics(df,bool_expr, compTime = True, robustness = True,objective = True,linCon=True,nvars=True,travel=True):
    smallFrame = df[bool_expr]

    stats = smallFrame.describe()
    return stats

def two_sample_t_test(df,bool_expr_1,bool_expr_2,argument):

    sample1 = df[bool_expr_1]
    print sample1.describe()
    sample2 = df[bool_expr_2]
    print sample2.describe()
    return st.ttest_ind(sample1.loc[:,argument],sample2.loc[:,argument])


def plot_output(dfarray,dim_list,solve_opts,param_list):
    '''
    dfarray is a nexted dict where the first key is the solver options
    tuple given as a string and the second key is the number of states in the TS
    (equiv: product of grid dimensions)
    dim_list is a list of grid dimensions to be plotted on the x axis
    solve_opts is the list of  tuples of the solver options to  plotted as series
    param_list is a list of parameters (keys in the dataframe) that will be
    plotted on separate y axes
    '''
    top = [300,8,0.35] # handcoded for IJRR 
    width = [9,8,9.5] 
    names = ['Env_runtime_pdf.pdf','Env_robust_pdf.pdf','Env_travel_pdf.pdf']    
    num_states = [dims[0]*dims[1] for  dims in dim_list]
    name_dict = {'(False, False, 0.5, False)': 'Feasible',
    '(True, False, 0.5, False)': 'Robust',
    '(True, False, 0.5, True)': 'Robust Bounded',
    '(False, True, 0.5, False)': 'Regularized',
    '(True, True, 0.5, False)': 'Robust Regularized ',
    '(True, True, 0.5, True)': 'Robust Regularized Bounded'} #provides plain English names of different solver options tuples
    for param in param_list:
        fig = plt.figure(figsize=[width[param_list.index(param)],7])
        plt.ylabel(param,fontsize='xx-large',fontweight='bold')
        plt.xlabel('Number of States',fontsize='xx-large',fontweight='bold')
        for so in solve_opts:
            response = [dfarray[str(so)][ns].loc['mean',param] for ns in num_states]
            err = [2*dfarray[str(so)][ns].loc['std',param] for ns in num_states]
            plt.errorbar(num_states,response,yerr=err,label=name_dict[str(so)],linewidth=4,capthick=2)
        plt.xticks(num_states,fontsize='xx-large',fontweight='bold')  
        plt.yticks(fontsize='xx-large',fontweight='bold') 
        plt.ylim(0,top[param_list.index(param)]) # handcoded for IJRR
        plt.legend(fontsize='xx-large',prop=dict(weight='bold'))
        plt.show()

        #This saves the plot to the current folder with whatever name you want
        with PdfPages(names[param_list.index(param)]) as export_pdf:
            export_pdf.savefig(fig) #Save the figure that is currently in the foreground

def plot_output_agents(dfarray,num_agents_list,solve_opts,param_list):
    '''
    dfarray is a nexted dict where the first key is the solver options
    tuple given as a string and the second key is the number of states in the TS
    (equiv: product of grid dimensions)
    napc_list is a list of number of agents per class to be plotted on the x axis
    solve_opts is the list of  tuples of the solver options to  plotted as series
    param_list is a list of parameters (keys in the dataframe) that will be
    plotted on separate y axes
    '''
    top = [300,8,0.35] # handcoded for IJRR
    width = [9,8,9.5] 
    names = ['Agents_runtime_pdf.pdf','Agents_robust_pdf.pdf','Agents_travel_pdf.pdf']
    name_dict = {'(False, False, 0.5, False)': 'Feasible',
    '(True, False, 0.5, False)': 'Robust',
    '(True, False, 0.5, True)': 'Robust Bounded',
    '(False, True, 0.5, False)': 'Regularized',
    '(True, True, 0.5, False)': 'Robust Regularized ',
    '(True, True, 0.5, True)': 'Robust Regularized Bounded'} #provides plain English names of different solver options tuples
    for param in param_list:
        fig = plt.figure(figsize=[width[param_list.index(param)],7])
        plt.ylabel(param,fontsize='xx-large',fontweight='bold')
        plt.xlabel('Number of Agents',fontsize='xx-large',fontweight='bold')
        for so in solve_opts:
            response = [dfarray[str(so)][ns].loc['mean',param] for ns in num_agents_list]
            err = [2*dfarray[str(so)][ns].loc['std',param] for ns in num_agents_list]
            plt.errorbar(num_agents_list,response,yerr=err,label=name_dict[str(so)],linewidth=4,capthick=2)
        plt.xticks(num_agents_list,fontsize='xx-large',fontweight='bold')  
        plt.yticks(fontsize='xx-large',fontweight='bold')  
        plt.ylim(0,top[param_list.index(param)]) # handcoded for IJRR
        plt.legend(fontsize='xx-large',prop=dict(weight='bold'))
        plt.show()

        #This saves the plot to the current folder with whatever name you want
        with PdfPages(names[param_list.index(param)]) as export_pdf:
            export_pdf.savefig(fig) #Save the figure that is currently in the foreground

def plot_output_class(dfarray,class_cap,solve_opts,param_list):
    '''
    dfarray is a nexted dict where the first key is the solver options
    tuple given as a string and the second key is the number of states in the TS
    (equiv: product of grid dimensions)
    napc_list is a list of number of agents per class to be plotted on the x axis
    solve_opts is the list of  tuples of the solver options to  plotted as series
    param_list is a list of parameters (keys in the dataframe) that will be
    plotted on separate y axes
    '''
    top = [300,8,0.35] # handcoded for IJRR
    width = [9,8,9.5] 
    names = ['Class_runtime_pdf.pdf','Class_robust_pdf.pdf','Class_travel_pdf.pdf']
    name_dict = {'(False, False, 0.5, False)': 'Feasible',
    '(True, False, 0.5, False)': 'Robust',
    '(True, False, 0.5, True)': 'Robust Bounded',
    '(False, True, 0.5, False)': 'Regularized',
    '(True, True, 0.5, False)': 'Robust Regularized ',
    '(True, True, 0.5, True)': 'Robust Regularized Bounded'} #provides plain English names of different solver options tuples
    for param in param_list:
        fig = plt.figure(figsize=[width[param_list.index(param)],7])
        plt.ylabel(param,fontsize='xx-large',fontweight='bold')
        plt.xlabel('Classes and Capabilities per Class',fontsize='xx-large',fontweight='bold')
        for so in solve_opts:
            response = [dfarray[str(so)][ns].loc['mean',param] for ns in class_cap]
            err = [2*dfarray[str(so)][ns].loc['std',param] for ns in class_cap]
            plt.errorbar([1,2,3,4],response,yerr=err,label=name_dict[str(so)],linewidth=4,capthick=2)
        plt.xticks([1,2,3,4],[str(x) for x in class_cap],fontsize='xx-large',fontweight='bold')    
        plt.yticks(fontsize='xx-large',fontweight='bold')
        plt.ylim(0,top[param_list.index(param)]) # handcoded for IJRR
        plt.legend(fontsize='xx-large',prop=dict(weight='bold'))
        plt.show()

        #This saves the plot to the current folder with whatever name you want
        with PdfPages(names[param_list.index(param)]) as export_pdf:
            export_pdf.savefig(fig) #Save the figure that is currently in the foreground

def plot_output_aaai(dfarray,num_agents_list,solve_opts,param_list,names):
    '''
    dfarray is a nexted dict where the first key is the solver options
    tuple given as a string and the second key is the number of states in the TS
    (equiv: product of grid dimensions)
    napc_list is a list of number of agents per class to be plotted on the x axis
    solve_opts is the list of  tuples of the solver options to  plotted as series
    param_list is a list of parameters (keys in the dataframe) that will be
    plotted on separate y axes
    '''
    top = [125,8,0.35] # handcoded for IJRR
    width = [9,8,9.5] 
    # names = ['AAAI_runtime_pdf.pdf']
    name_dict = {'(False, False, 0.5, False, False)': 'Feasible',
    '(True, False, 0.5, False, False)': 'Robust',
    '(False, False, 0.5, False, True)': 'Decomp Feasible',
    '(True, False, 0.5, False, True)': 'Decomp Robust'} #provides plain English names of different solver options tuples
    for param in param_list:
        fig = plt.figure(figsize=[width[param_list.index(param)],7])
        plt.ylabel(param,fontsize='xx-large',fontweight='bold')
        plt.xlabel('Number of Agents',fontsize='xx-large',fontweight='bold')
        for so in solve_opts:
            response = [dfarray[str(so)][ns].loc['mean',param] for ns in num_agents_list]
            err = [2*dfarray[str(so)][ns].loc['std',param] for ns in num_agents_list]
            plt.errorbar(num_agents_list,response,yerr=err,label=name_dict[str(so)],linewidth=4,capthick=2)
        plt.xticks(num_agents_list,fontsize='xx-large',fontweight='bold')  
        plt.yticks(fontsize='xx-large',fontweight='bold')  
        plt.ylim(0,top[param_list.index(param)]) # handcoded for IJRR
        plt.legend(fontsize='xx-large',prop=dict(weight='bold'))
        plt.show()

        #This saves the plot to the current folder with whatever name you want
        with PdfPages(names[param_list.index(param)]) as export_pdf:
            export_pdf.savefig(fig) #Save the figure that is currently in the foreground

def plot_decomp_aaai(dfarray, num_agents_list,solve_opts,param_list,fname):


    param1 = param_list[0]
    param2 = param_list[1]
    so1 = solve_opts[0]
    so2 = solve_opts[1]

    fig = plt.figure()
    response1 = [dfarray[str(so1)][ns].loc['mean',param1] for ns in num_agents_list]
    err1 = [2*dfarray[str(so1)][ns].loc['std',param1] for ns in num_agents_list]    

    response2 = [dfarray[str(so1)][ns].loc['mean',param2] for ns in num_agents_list]
    err2 = [2*dfarray[str(so1)][ns].loc['std',param2] for ns in num_agents_list]   

    response3 = [dfarray[str(so2)][ns].loc['mean',param1] for ns in num_agents_list]
    err3 = [2*dfarray[str(so2)][ns].loc['std',param1] for ns in num_agents_list]    

    response4 = [dfarray[str(so2)][ns].loc['mean',param2] for ns in num_agents_list]
    err4 = [2*dfarray[str(so2)][ns].loc['std',param2] for ns in num_agents_list]   

    ind = np.arange(len(num_agents_list))
    width = 0.4
    top = [30,8,0.35] # handcoded for IJRR

    plt.bar(ind, response1, width, color='b')
    plt.bar(ind, response2, width, color='y')
    plt.bar(ind+width, response3, width, color='r')
    plt.bar(ind+width, response4, width, color='g')

    plt.ylim(0,top[0]) # handcoded for IJRR
    plt.xlabel('Number of Agents',fontsize='xx-large',fontweight='bold')
    plt.ylabel('Computation Time (s)',fontsize='xx-large',fontweight='bold')
    plt.xticks(ind+width, num_agents_list,fontsize='xx-large',fontweight='bold')
    plt.yticks(fontsize='xx-large',fontweight='bold')
    plt.legend(['Feasible MILP','Feasible Decomp','Robust MILP','Robust Decomp'],loc=2,fontsize='xx-large',prop=dict(weight='bold'))

    #This saves the plot to the current folder with whatever name you want
    with PdfPages(fname) as export_pdf:
        export_pdf.savefig(fig) #Save the figure that is currently in the foreground

    plt.show()

def plot_output_hscc(dfarray,num_agents_list,solve_opts,param_list,names):
    '''
    dfarray is a nexted dict where the first key is the solver options
    tuple given as a string and the second key is the number of states in the TS
    (equiv: product of grid dimensions)
    napc_list is a list of number of agents per class to be plotted on the x axis
    solve_opts is the list of  tuples of the solver options to  plotted as series
    param_list is a list of parameters (keys in the dataframe) that will be
    plotted on separate y axes
    '''
    top = [60,8,0.35] # handcoded for IJRR
    width = [9,8,9.5] 
    # names = ['AAAI_runtime_pdf.pdf']
    name_dict = {'(False, False, 0.5, False, False)': 'Central',
    '(False, False, 0.5, False, True)': 'Decomp'} #provides plain English names of different solver options tuples
    for param in param_list:
        fig = plt.figure(figsize=[width[param_list.index(param)],7])
        plt.ylabel(param,fontsize='xx-large',fontweight='bold')
        plt.xlabel('Number of Agents',fontsize='xx-large',fontweight='bold')
        for so in solve_opts:
            response = [dfarray[str(so)][ns].loc['mean',param] for ns in num_agents_list]
            err = [2*dfarray[str(so)][ns].loc['std',param] for ns in num_agents_list]
            plt.errorbar(num_agents_list,response,yerr=err,label=name_dict[str(so)],linewidth=4,capthick=2)
        plt.xticks(num_agents_list,fontsize='xx-large',fontweight='bold')  
        plt.yticks(fontsize='xx-large',fontweight='bold')  
        plt.ylim(0,top[param_list.index(param)]) # handcoded for IJRR
        plt.legend(fontsize='xx-large',prop=dict(weight='bold'))
        plt.show()

        #This saves the plot to the current folder with whatever name you want
        with PdfPages(names[param_list.index(param)]) as export_pdf:
            export_pdf.savefig(fig) #Save the figure that is currently in the foreground

def plot_decomp_hscc(dfarray, num_agents_list,solve_opts,param_list,fname):


    param1 = param_list[0]
    param2 = param_list[1]
    so1 = solve_opts[0]
    so2 = solve_opts[1]

    fig = plt.figure()
    response1 = [dfarray[str(so1)][ns].loc['mean',param1] for ns in num_agents_list]
    err1 = [2*dfarray[str(so1)][ns].loc['std',param1] for ns in num_agents_list]    

    response2 = [dfarray[str(so1)][ns].loc['mean',param2] for ns in num_agents_list]
    err2 = [2*dfarray[str(so1)][ns].loc['std',param2] for ns in num_agents_list]   

    response3 = [dfarray[str(so2)][ns].loc['mean',param1] for ns in num_agents_list]
    err3 = [2*dfarray[str(so2)][ns].loc['std',param1] for ns in num_agents_list]    

    response4 = [dfarray[str(so2)][ns].loc['mean',param2] for ns in num_agents_list]
    err4 = [2*dfarray[str(so2)][ns].loc['std',param2] for ns in num_agents_list]   

    ind = np.arange(len(num_agents_list))
    width = 0.4
    top = [30,8,0.35] # handcoded for IJRR

    plt.bar(ind, response1, width, color='b')
    # plt.bar(ind, response2, width, color='y')
    plt.bar(ind+width, response3, width, color='r')
    plt.bar(ind+width, response4, width, color='g')

    plt.ylim(0,top[0]) # handcoded for IJRR
    plt.xlabel('Number of Agents',fontsize='xx-large',fontweight='bold')
    plt.ylabel('Computation Time (s)',fontsize='xx-large',fontweight='bold')
    plt.xticks(ind+width, num_agents_list,fontsize='xx-large',fontweight='bold')
    plt.yticks(fontsize='xx-large',fontweight='bold')
    plt.legend(['Centralized MILP','MILP','Decomp'],loc=2,fontsize='xx-large',prop=dict(weight='bold'))

    #This saves the plot to the current folder with whatever name you want
    with PdfPages(fname) as export_pdf:
        export_pdf.savefig(fig) #Save the figure that is currently in the foreground

    plt.show()