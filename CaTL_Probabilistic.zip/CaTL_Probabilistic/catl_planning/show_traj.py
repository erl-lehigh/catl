import matplotlib
matplotlib.use("Agg")
from matplotlib.animation import FFMpegWriter
import matplotlib.pyplot as plt


from visualization import show_environment_agents
from visualization import show_transition_agents
from visualization import show_world

import numpy as np
import pandas as pd
from lomap import Ts


def show_sol_traj(m,the_plan,agent_caps,show_video=False):

    caps = np.unique(agent_caps)
    fig = plt.figure()
    plt.clf()
    fig,viewport = show_world(ts,fig)
    for i in range(0,num_agents):
        if agent_caps[i] == caps[0]:
            plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-k')
        elif agent_caps[i] == caps[1]:
            plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], ':y')
        elif agent_caps[i] == caps[2]:
            plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '--b')
        elif agent_caps[i] == caps[3]:
            plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-.g')
        elif agent_caps[i] == caps[4]:
            plt.plot([x for (x, y) in the_plan[i] if not x == -100], [y for (x, y) in the_plan[i] if not y == -100], '-.r')


    plt.axis(plot_region_bounds)
    plt.show(block=False)
    plt.pause(1)
    plt.waitforbuttonpress()
    plt.clf()
    
    
    if show_video:
        metadata = dict(title='Traj_Sol', artist='Matplotlib',comment='Movie support!')
        writer = FFMpegWriter(fps=12, metadata=metadata)
        writer.setup(fig,m.save_filename+'.mp4',1000)

        for time in range(0,(sim_time)):
            plt.clf()
            fig,viewport = show_world(ts,fig)
            for i in range(0,num_agents):
                if agent_caps[i] == 1:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],color="r",marker='x',markersize=15)
                elif agent_caps[i] == 2:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"oc",markersize=15)
                elif agent_caps[i] == 3:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"*w",markersize=15)
                elif agent_caps[i] == 8:
                    plt.plot(the_plan[i][time][0], the_plan[i][time][1],"hk",markersize=12)


            plt.axis(plot_region_bounds)
            plt.title('Time: ' + str(np.divide(time,10)))
            writer.grab_frame()
            plt.show(block=False)
            plt.pause(0.01)
