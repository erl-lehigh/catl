#from twtlplan.Twtl4Catl import Convert2TWTLTraj
from twtlplan.util import Box
from twtlplan.twtlplan import CaTL_Tree_Builder

import numpy as np
import pandas as pd
from lomap import Ts
import networkx as nx
import pickle
import sys


def build_TWTL_world(ts):

    props = {}
    obstacles = []
    worldx_min_val = 100000
    worldy_min_val = 100000
    worldx_max_val = -100000
    worldy_max_val = -100000
    for state in ts.g.node:
        #print('State: ',state)
        #print('Prop: ','grave' in ts.g.node[state]['prop'])
        if not 'grave' in ts.g.node[state]['prop']:
        #shape formatting: [[50, 20], [50, 50], [70,50], [70, 20]]
            if 'obs' in ts.g.node[state]['prop']:
                state_int = np.int(state[1:len(state)])
                bounds = ts.g.node[state]['shape']
                num_points = len(bounds)
                x_max = -100000
                x_min = 100000
                y_max = -100000
                y_min = 100000
                for idx in range(0,num_points):
                    if bounds[idx][0] < x_min:
                        x_min = bounds[idx][0]
                        if x_min < worldx_min_val:
                            worldx_min_val = x_min
                    if bounds[idx][0] > x_max:
                        x_max = bounds[idx][0]
                        if x_max > worldx_max_val:
                            worldx_max_val = x_max
                    if bounds[idx][1] < y_min:
                        y_min = bounds[idx][1]
                        if y_min < worldy_min_val:
                            worldy_min_val = y_min
                    if bounds[idx][1] > y_max:
                        y_max = bounds[idx][1]
                        if y_max > worldy_max_val:
                            worldy_max_val = y_max
                #print(np.array([[x_min, x_max], [y_min, y_max]]))
                obstacles.append(Box(np.array([[x_min, x_max], [y_min, y_max]])))
            else:
                state_int = np.int(state[1:len(state)])
                bounds = ts.g.node[state]['shape']
                num_points = len(bounds)
                x_max = -100000
                x_min = 100000
                y_max = -100000
                y_min = 100000
                for idx in range(0,num_points):
                    if bounds[idx][0] < x_min:
                        x_min = bounds[idx][0]
                        if x_min < worldx_min_val:
                            worldx_min_val = x_min
                    if bounds[idx][0] > x_max:
                        x_max = bounds[idx][0]
                        if x_max > worldx_max_val:
                            worldx_max_val = x_max
                    if bounds[idx][1] < y_min:
                        y_min = bounds[idx][1]
                        if y_min < worldy_min_val:
                            worldy_min_val = y_min
                    if bounds[idx][1] > y_max:
                        y_max = bounds[idx][1]
                        if y_max > worldy_max_val:
                            worldy_max_val = y_max
                #print(np.array([[x_min, x_max], [y_min, y_max]]))
                props[state] = Box(np.array([[x_min, x_max], [y_min, y_max]]))
    region_limits = Box(np.array([[worldx_min_val, worldx_max_val], [worldy_min_val, worldy_max_val]]))
    return region_limits,props,obstacles


def build_TWTL_world_for_traj(ts,ag_traj):

    states_used_array = []
    for pts in range(0,len(ag_traj)):
        states_used_array.append(ag_traj[pts][0])

    st_use = np.unique(states_used_array)
    st_string = []
    for s in st_use:
        st_string.append('q'+str(s))

    props = {}
    obstacles = []
    worldx_min_val = 100000
    worldy_min_val = 100000
    worldx_max_val = -100000
    worldy_max_val = -100000
    for state in ts.g.node:
        #print('State: ',state)
        if (not 'grave' in ts.g.node[state]['prop']) and (state in st_string):
        #shape formatting: [[50, 20], [50, 50], [70,50], [70, 20]]
            if 'obs' in ts.g.node[state]['prop']:
                state_int = np.int(state[1:len(state)])
                bounds = ts.g.node[state]['shape']
                num_points = len(bounds)
                x_max = -100000
                x_min = 100000
                y_max = -100000
                y_min = 100000
                for idx in range(0,num_points):
                    if bounds[idx][0] < x_min:
                        x_min = bounds[idx][0]
                        if x_min < worldx_min_val:
                            worldx_min_val = x_min
                    if bounds[idx][0] > x_max:
                        x_max = bounds[idx][0]
                        if x_max > worldx_max_val:
                            worldx_max_val = x_max
                    if bounds[idx][1] < y_min:
                        y_min = bounds[idx][1]
                        if y_min < worldy_min_val:
                            worldy_min_val = y_min
                    if bounds[idx][1] > y_max:
                        y_max = bounds[idx][1]
                        if y_max > worldy_max_val:
                            worldy_max_val = y_max
                #print(np.array([[x_min, x_max], [y_min, y_max]]))
                obstacles.append(Box(np.array([[x_min, x_max], [y_min, y_max]])))
            else:
                state_int = np.int(state[1:len(state)])
                bounds = ts.g.node[state]['shape']
                num_points = len(bounds)
                x_max = -100000
                x_min = 100000
                y_max = -100000
                y_min = 100000
                for idx in range(0,num_points):
                    if bounds[idx][0] < x_min:
                        x_min = bounds[idx][0]
                        if x_min < worldx_min_val:
                            worldx_min_val = x_min
                    if bounds[idx][0] > x_max:
                        x_max = bounds[idx][0]
                        if x_max > worldx_max_val:
                            worldx_max_val = x_max
                    if bounds[idx][1] < y_min:
                        y_min = bounds[idx][1]
                        if y_min < worldy_min_val:
                            worldy_min_val = y_min
                    if bounds[idx][1] > y_max:
                        y_max = bounds[idx][1]
                        if y_max > worldy_max_val:
                            worldy_max_val = y_max
                #print(np.array([[x_min, x_max], [y_min, y_max]]))
                props[state] = Box(np.array([[x_min, x_max], [y_min, y_max]]))
        elif not state in st_string:
                state_int = np.int(state[1:len(state)])
                bounds = ts.g.node[state]['shape']
                num_points = len(bounds)
                x_max = -100000
                x_min = 100000
                y_max = -100000
                y_min = 100000
                for idx in range(0,num_points):
                    if bounds[idx][0] < x_min:
                        x_min = bounds[idx][0]
                        if x_min < worldx_min_val:
                            worldx_min_val = x_min
                    if bounds[idx][0] > x_max:
                        x_max = bounds[idx][0]
                        if x_max > worldx_max_val:
                            worldx_max_val = x_max
                    if bounds[idx][1] < y_min:
                        y_min = bounds[idx][1]
                        if y_min < worldy_min_val:
                            worldy_min_val = y_min
                    if bounds[idx][1] > y_max:
                        y_max = bounds[idx][1]
                        if y_max > worldy_max_val:
                            worldy_max_val = y_max
                #print(np.array([[x_min, x_max], [y_min, y_max]]))
                obstacles.append(Box(np.array([[x_min+5, x_max-5], [y_min+5, y_max-5]])))

    region_limits = Box(np.array([[worldx_min_val, worldx_max_val], [worldy_min_val, worldy_max_val]]))
    #print('props',props)
    #print('obs',obstacles)
    
    return props,obstacles



def TWTLTraj2Tree(Specs,Trajects,region_trajs,ts_file):
    region_limits,props,obstacles = build_TWTL_world(ts_file)

    team_trees = []
    team_taus = []

    for i in range(0,len(Specs)):
        current_spec = Specs[i]
        agent_traj = Trajects[i]
        #print(current_spec)
        local_props,local_obstacles = build_TWTL_world_for_traj(ts_file,region_trajs[i])
        agent_tree,taus = CaTL_Tree_Builder(agent_traj,region_limits, local_props, local_obstacles, current_spec, d=1, eps=0)
        team_trees.append(agent_tree)
        team_taus.append(taus)

        #print(taus,current_spec)

    return team_trees,team_taus
        
        
        
        

