
'''
#LL Copyright
#This material is based upon work supported by the Under Secretary of Defense for Research and Engineering under Air Force Contract No. FA8702-15-D-0001. Any opinions, findings, conclusions or recommendations expressed in this material are those of the author(s) and do not necessarily reflect the views of the Under Secretary of Defense for Research and Engineering.
#Copyright 2019 Massachusetts Institute of Technology.
#The software firmware is provided to you on an As-Is basis
#Delivered to the U.S. Government with Unlimited Rights, as defined in DFARS Part 252.227-7013 or 7014 (Feb 2014). Notwithstanding any copyright notice, U.S. Government rights in this work are defined by DFARS 252.227-7013 or DFARS 252.227-7014 as detailed above. Use of this work other than as specifically authorized by the U.S. Government may violate any copyrights that exist in this work.
#LL Copyright
'''
import numpy as np
import pandas as pd
from lomap import Ts
import networkx as nx
import pickle
import sys


#Example spec = '[H^0 Q1]^[9,10] * [H^5 Q1]^[0, 6] * [H^0 Q2]^[19, 20] * [H^5 Q2]^[0, 6]''

###############################################################################
#Parse Data from sol file
###############################################################################
def read_sol_data(data,ts):
    #This is the data file to parse - designed for gurobi.sol files
    #data = pd.read_csv("isrr2019.sol",sep='\n')
    var_data = data.values
    states = []
    edges = []

    # obstacleList[0] - Ground obstacles
    # obstacleList[1] - Mid-air obstacles
    # obstacleList[2] - top-Air obstacles

    #temp_edge_weights = nx.get_edge_attributes(ts.g,'weight')

    #record last time
    end_time = 0

    #record_max_weight
    max_weight = 0

    #This loop extracts the states and edges from the solution and puts them into a numpy array
    for i in range(1,len(var_data)):

        if var_data[i,0][0] is 'z' and var_data[i,0][2] is 'q':
            #States
            if var_data[i,0].count('q')==1:
                vars = var_data[i,0].split("_")
                time_state = vars[3].split(" ")
                time = time_state[0]
                num = time_state[1]
                state = vars[1].replace("q","")
                cap = vars[2]
                if int(time) > end_time:
                    end_time = int(time)
                if int(num) > 0:
                    states.append([int(state),int(time),int(cap),int(num)])
            #Edges
            if var_data[i,0].count('q')==2:
                vars = var_data[i,0].split("_")
                time_state = vars[4].split(" ")
                time = time_state[0]
                num = time_state[1]
                state1 = vars[1].replace("q","")
                state2 = vars[2].replace("q","")
                cap = vars[3]
                if not 'grave' in ts.g.node['q'+str(state1)]['prop'] and not 'grave' in ts.g.node['q'+str(state2)]['prop']:
                    weight = ts.g.edge['q'+str(state1)]['q'+str(state2)]['weight']
                    if weight > max_weight:
                        max_weight = weight
                if int(time) > end_time:
                    end_time = int(time)
                #weight = temp_edge_weights[('q'+str(state1),'q'+str(state2))]
                if int(num) > 0:
                    edges.append([int(state1),int(state2),int(time),weight,int(cap),int(num)])

    #Make them numpy arrays
    states = np.asarray(states)
    #print('sim_time_cal: ',end_time+max_weight)
    edges = np.asarray(edges)
    return states,edges,(end_time+max_weight+1)


###############################################################################
#Generate Individual Region Trajectories
###############################################################################
def assign_caps_to_trajs(states,edges,sim_time,start_time=0):
    end_time = sim_time
    caps = np.unique(states[states[:,1]==0,2])
    agent_caps = []
    num_caps = np.zeros(len(caps))
    cap_idx = np.zeros(len(caps))
    counts = 0
    init_states = states[states[:,1]==0]

    time_stamps = np.asarray(states[:,1])

    #Count agents and capabilities
    for i in caps:
        choice_vals = np.where(states[states[:,1]==0,2]==i)
        num_caps[counts]=np.sum(init_states[choice_vals,3])
        for j in range(0,num_caps[counts].astype(int)):
            agent_caps.append(i)
        counts = counts+1

    num_agents = np.sum(num_caps).astype(int)
    agent_positions = np.empty((end_time,num_agents),dtype=object)
    transit_times = np.zeros((end_time,num_agents))

    #initialize trajectory
    for i in caps:
        num_of_type = 0
        choice_vals = np.where(states[states[:,1]==0,2]==i)
        for j in choice_vals[0]:
            past_num = num_of_type
            num_of_type = num_of_type + init_states[j,3]
            region_of_type = init_states[j,0]
            cap_idxs = np.where(agent_caps == i)
            for k in range(past_num,num_of_type):
                agent_positions[0,cap_idxs[0][k]] = (region_of_type.astype(int))

    edge_timer = np.zeros(num_agents)

    for t in range(start_time,sim_time):

        current_edge = edges[edges[:,2]==t]
        already_assigned = np.zeros(num_agents)
        #Update Edge Timing
        transit_times[t] = edge_timer
        edge_timer = edge_timer-1
        edge_timer[edge_timer<0] = 0
        #Prevent moving agents from being assigned
        already_assigned[edge_timer>0] = 1

        #insert line where if edge_timer > 0 with -1 then assigned
        for i in caps:
            num_of_type = 0
            choice_vals = np.where(current_edge[:,4]==i)
            for j in choice_vals[0]:
                eval_edge = current_edge[j,:]
                not_assigned = np.where(already_assigned== 0)
                current_cap = np.where(agent_caps==eval_edge[4])
                not_assigned = np.intersect1d(not_assigned,current_cap)
                free_agents = np.where(agent_positions[t,not_assigned] == eval_edge[0])
                available = not_assigned[free_agents[0]]
                available = np.asarray(available)

                if available.size < eval_edge[5]:
                    print('error time:',t)
                    print('available: ',available.size,' asking for: ',eval_edge[5])
                    exit('Requested Agents Not Available')
                for itr in range(0,eval_edge[5]):
                    if eval_edge[0] == eval_edge[1]:
                        #Agents stay in the same place
                        already_assigned[available[itr]] = 1
                        edge_timer[available[itr]] = 1
                        agent_positions[t+1][available[itr]] = eval_edge[0]
                    else:
                        #Agents enter edge
                        already_assigned[available[itr]] = 1
                        edge_timer[available[itr]] = eval_edge[3]
                        for idx in range(0,eval_edge[3]):
                            #On last iteration, make agent at position
                            if (t+idx+1)==sim_time:
                                time_idx = sim_time-1
                            else:
                                time_idx = t+idx+1

                            if idx >= eval_edge[3]-1:
                                agent_positions[time_idx][available[itr]] = eval_edge[1]
                            else:
                                agent_positions[time_idx][available[itr]] = [eval_edge[0],eval_edge[1],eval_edge[3]]

    #Catch agents that stay at states for multiple time steps
    for t in range(0,sim_time):
        for n in range(0,num_agents):
            if transit_times[t,n] == 0:
                if agent_positions[t,n] == None:
                    agent_positions[t,n] = agent_positions[t-1,n]


    return agent_positions,caps,num_agents,transit_times,agent_caps



def hold_at_region(leg,planning_step_time=1):
    hold_len = (leg[1])*planning_step_time
    #hold_len = (leg[1])*planning_step_time
    toregion = 'q'+str(leg[0])
    return '[H^'+str(hold_len-1)+' '+toregion+']^[0,'+str((hold_len))+']',hold_len

def transition_to_region(leg,planning_step_time=1):
    trans_len = (leg[2]-1)*planning_step_time
    toregion = 'q'+str(leg[1])
    return '[H^0 '+toregion+']^['+str((trans_len-1))+','+str((trans_len))+']',trans_len

def hold_at_region_end(leg,planning_step_time=1):
    hold_len = (leg[1]-1)*planning_step_time
    toregion = 'q'+str(leg[0])
    return '[H^'+str(hold_len-2)+' '+toregion+']^[0,'+str((hold_len-1))+']',hold_len

def transition_to_region_end(leg,planning_step_time=1):
    trans_len = leg[2]*planning_step_time
    toregion = 'q'+str(leg[1])
    return '[H^0 '+toregion+']^['+str((trans_len-2))+','+str((trans_len-1))+']',trans_len



def CatlSol2Twtl_main(data,ts,filename=None,planning_step_time=1):

    states,edges,sim_time = read_sol_data(data,ts)
    agent_positions,caps,num_agents,transit_times,agent_caps = assign_caps_to_trajs(states,edges,sim_time)
    
    #agent_positions[time][agent_index]= state or transition
    #Solution states have t-1 number in their States
    #Solution transitions will have n+1 time to "land" in a state

    ### This section takes in the long agent_positions struct and turns it into something
    ### that is just region and time there or transition regions and time.
    ### state time is time+1 and edges are time-1 since the last time in the transition
    ### should have that agent in that state for 1 time.
    agent_trajs = []
    for i in range(0,num_agents):
        last_state = agent_positions[0][i]
        state_change_count = 1
        built_traj = [] 
        for t in range(1,sim_time):
            state = agent_positions[t][i]
            #print('sim_time: ',sim_time,t)
            #print('state check',state,last_state,state_change_count)
            if np.equal(last_state,state).all():
                state_change_count += 1
            else:
                if np.size(last_state) == 1:
                    built_traj.append([last_state,state_change_count])
                    #print('state end',last_state,state_change_count)
                else:
                    built_traj.append(last_state)

                    #print('trans end',last_state)
                state_change_count = 1
            last_state = state
        state = agent_positions[t][i]
        if np.equal(last_state,state).all():
            if np.size(state) == 1:
                built_traj.append([last_state,state_change_count])
                #print(state_change_count)
                #print('state end',last_state,state_change_count)
            else:
                built_traj.append(state)
                #print('trans end',state)
        agent_trajs.append(built_traj)
    ###This section builds the TWTL specs as strings

    specs = []
    for i in range(0,num_agents):
        built_spec = ''
        for j in range(0,len(agent_trajs[i])):
            leg = agent_trajs[i][j]
            #print(leg,i)
            if len(leg) == 2:
                str_leg,spec_dur = hold_at_region(leg,planning_step_time)
            else:
                str_leg,spec_dur = transition_to_region(leg,planning_step_time)
            if j == len(agent_trajs[i])-1:
                if len(leg) == 2:
                    str_leg,spec_dur = hold_at_region_end(leg,planning_step_time)
                else:
                    str_leg,spec_dur = transition_to_region_end(leg,planning_step_time)
                built_spec = built_spec+str_leg
            else:
                built_spec = built_spec+str_leg+' * '
        #print(built_spec,agent_trajs[i])
        specs.append(built_spec)
        #pickle.dump(specs, open(filename+"_TWTL_specs.pkl", "w"))
    
    return(specs,agent_trajs)

def main():
    ts_filename='../TransitionSystems/demo_grave.yaml'
    load_filename = '../OutputFiles/demo_test'

    data = pd.read_csv(load_filename+".sol",sep='\n')
    ts = Ts.load(ts_filename)
    for u, v in ts.g.edges():
        assert ts.g.has_edge(v, u)

    twtl_specs,trajs = Catlsol2TWTL_main(data,ts,'run_test')

if __name__ == '__main__':
    main()
