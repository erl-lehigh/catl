'''
 Copyright (C) 2018 Cristian Ioan Vasile <cvasile@bu.edu>
 Hybrid and Networked Systems (HyNeSs) Group, BU Robotics Lab, Boston University
 See license.txt file for license information.
'''

import logging

from gurobipy import Model as GRBModel
from gurobipy import GRB, LinExpr

from lomap import Timer

from stl import stl2milp
from cmtl import CapabilityRequest, CMTLFormula
from catl_encoding import cmtl2stl
from visualization import show_environment
import pickle as pickle


def compute_capability_bitmap(agents):
    '''Computes a bitmap encoding of agents' capabilities. Each capability is
    associated with a bit in a binary word of length equal to the number of
    capabilities.
    Input
    -----
    List of agents, where agents are tuples (q, cap), q is the initial state of
    the agent, and cap is the set of capabilities. Agents' identifiers are their
    indices in the list.

    Output
    ------
    The output is a dictionary from capabilities to integers representing the
    capabilitie's binary word.
    '''
    capabilities = set.union(*[cap for _, cap in agents])
    capabilities = {c: 1<<k for k, c in enumerate(capabilities)}
    logging.debug('Capabilities bitmap: %s', capabilities)
    return capabilities

def compute_agent_classes(agents, capabilities):
    '''Computes the set of agent types w.r.t. capabilities.
    Input
    -----
    - List of agents, where agents are tuples (q, cap), q is the initial state of
    the agent, and cap is the set of capabilities. Agents' identifiers are their
    indices in the list.
    - Dictionary of capability encoding that maps capabilities to binary words
    represented as integers.
    Output
    ------
    Dictionary of agent classes that maps frozen (immutable) sets of
    capabilities to the binary words encoding the sets.
    '''
    return {frozenset(g): sum([capabilities[c] for c in g]) for _, g in agents}

def compute_initial_capability_distribution(ts, agents, capabilities):
    '''Computes the initial number of agents of each class at each state.
    Input
    -----
    - The transition system specifying the environment.
    - List of agents, where agents are tuples (q, cap), q is the initial state of
    the agent, and cap is the set of capabilities. Agents' identifiers are their
    indices in the list.
    - Dictionary of capability encoding that maps capabilities to binary words
    represented as integers.
    Output
    ------
    Dictionary from states to distribution of agents from each class. The
    distribution is a list of length equal to the number of capabilities, and
    each element is the number of agents of having those capabilities (a class).
    '''
    #Austin, I didnt get to fixing this but the problem is the way he is referencing
    #the indexes of the capabilities. I am not sure how to reference these correctly
    #without creating all of the capabilities variables.
    nc = len(capabilities)
    capability_distribution = {u: [0]*2**nc for u in ts.g}
    #print(capability_distribution)
    for state, g in agents:
        #print('cap: ',capabilities,'g: ',g)
        g_enc = sum([capabilities[c] for c in g])
        #print(g_enc, state)
        capability_distribution[state][g_enc] += 1
    '''
    nc = len(capabilities)
    capability_distribution = {u: [0]*(2**nc) for u in ts.g}
    for state, cap in agents:
        g = sum([capabilities[c] for c in cap])
        capability_distribution[state][g] += 1

    print(capability_distribution)
    '''
    return capability_distribution

def create_system_variables(m, ts, agent_classes, bound, vtype=GRB.INTEGER,num_agents=1000,regularize=True,alpha=0.5):
    '''Creates the state and transition variables associated with the given
    transition system.

    The state variables are z_{state}_{cap}_k, where {state} is a node in the TS
    graph, {cap} is a capability class encoded as an integer, and k is the time
    step.

    The transition variables are z_{state1}_{state2}_{cap}_k, where {state1} and
    {state2} define the transition, {cap} is a capability class encoded as an
    integer, and k is the time step.

    Input
    -----
    - The Gurobi model variable.
    - The transition system specifying the environment.
    - The agent classes given as a dictionary from frozen sets of capabilities
    to bitmaps (integers).
    - Time bound.
    - Variable type (default: integer).

    Note
    ----
    Data structure holding the variables is a list of list of variables, e.g.,

        d['vars'][k][g] is the z_{q/e}_bitmap(g)_k

    where d is the dictionary of attributes for a node q or an edge e in the TS,
    g is an agent class (frozen set of capabilities), bitmap(g) is the binary
    encoding of g as an integer, and k is the time step.
    Also, d['vars'] is a list of length `bound+1', d['vars'][k] is a dictionary
    from frozen sets to gurobi variables.
    '''
    # node variables
    #print(ts.g.nodes(data=True))
    if  regularize:
        newObj = LinExpr() #Create objective function for total travel time
    for u, d in ts.g.nodes(data=True):
        d['vars'] = [] # initialize node variables list
        for k in range(bound+1):
            #print(agent_classes.items())
            #name = 'z_' + str(u) + '_{g}_' + str(k)
            #d['vars'].append(g:m.addVar(vtype=vtype, name=name.format(enc))
            #                            for g, enc in agent_classes.items())

            name = 'z_' + str(u) + '_{}_' + str(k)
            d['vars'].append({g: m.addVar(vtype=vtype, lb=0, ub=num_agents,name=name.format(enc))
                            for g, enc in agent_classes.items()})

            #d['vars'].append(m.addVar(vtype=vtype, name=name.format(enc)) for g, enc in agent_classes.items())
    # edge variables

    for u, v, d in ts.g.edges(data=True):
        d['vars'] = [] # initialize edge variables list
        for k in range(-1,bound+1):
            name = 'z_' + str(u) + '_' + str(v) + '_{}_' + str(k)
            edgeList = {g: m.addVar(vtype=vtype, name=name.format(enc))
                            for g, enc in agent_classes.items()}
            d['vars'].append(edgeList)
            if  regularize and str(u) != str(v):
                for edge in edgeList.values():
                    newObj += alpha/(bound*num_agents)*edge*d['weight'] #This is the weighted total travel time
    if regularize:
        m.setObjectiveN(newObj,m.NumObj)
            #d['vars'].append(m.addVar(vtype=vtype, name=name.format(enc))
            #                            for g, enc in agent_classes.items())
            #d['vars'].append(m.addVar(vtype=vtype, name=name.format(enc)) for g, enc in agent_classes.items())

def add_system_constraints(m, ts, agent_classes, capability_distribution,
                           bound):
    '''Computes the constraints that capture the system dynamics.

    Input
    -----
    - The Gurobi model variable.
    - The transition system specifying the environment.
    - The agent classes given as a dictionary from frozen sets of capabilities
    to bitmaps (integers).
    - The initial distribution of capabilities at each state.
    - Time bound.

    Note
    ----
    The initial time constraints

        z_{state}_g_0 = \eta_{state}_g

    is equivalent to

        \sum_{e=(u, v) \in T} z_e_g_W(e) = \eta_{state}_g

    because of the definition of the team state at TS states,
    where \eta_{state}_g is the number of agents of class g at state {state} at
    time 0.
    '''
    # edge conservation constraints
    for u, ud in ts.g.nodes(data=True):
        for k in range(1,bound+2):
            for g, g_enc in agent_classes.items():
                print [(u,start,finish,d['weight'],k) for start, finish, d in ts.g.in_edges_iter(u, data=True)
                    if (k - d['weight']) >= 0]
                conserve = sum([d['vars'][k-d['weight']][g]
                            for start,finish, d in ts.g.in_edges_iter(u, data=True)
                                if (k - 1 - d['weight']) >= 0 or start == finish])

                # node constraint: team state
                team_state_eq = (ud['vars'][k-1][g] == conserve)
                m.addConstr(team_state_eq, 'team_{}_{}_{}'.format(u, g_enc, k))
                #print [(u,start,finish,d['weight']) for start, finish, d in ts.g.out_edges_iter(u, data=True)]
                # flow balancing constraint
                conserve -= sum([d['vars'][k][g]
                            for _, _, d in ts.g.out_edges_iter(u, data=True)])
                conserve = (conserve == 0)
                m.addConstr(conserve, 'conserve_{}_{}_{}'.format(u, g_enc, k))

#     # initial time constraints - encoding using transition variables
#     for u in ts.g.nodes():
#         for g, g_enc in agent_classes.items():
#             conserve = sum([d['vars'][d['weight']][g]
#                             for _, _, d in ts.g.out_edges_iter(u, data=True)
#                                 if d['weight'] <= bound])
#             conserve = (conserve == capability_distribution[u][g])
#             m.addConstr(conserve, 'init_distrib_{}_{}'.format(u, g_enc))


    # initial time constraints - encoding using state variables
    for u, ud in ts.g.nodes(data=True):
        for g, g_enc in agent_classes.items():
            for start, finish, d in ts.g.in_edges_iter(u, data=True):
                if start == finish:
                    conserve = (d['vars'][0][g] == capability_distribution[u][g_enc])
                    m.addConstr(conserve, 'init_distrib_{}_{}_{}'.format(start,finish,g_enc))
                else:
                    conserve = (d['vars'][0][g] == 0)
                    m.addConstr(conserve, 'init_distrib_{}_{}_{}'.format(start,finish,g_enc))

def extract_propositions(ts, ast):
    '''Returns the set of propositions in the formula, and checks that it is
    included in the transitions system.

    Input
    -----
    - The transition system specifying the environment.
    - The AST of the CaTL specification formula.

    Output
    ------
    Set of propositions in the specification formula.
    '''
    #print [d['prop'] for _, d in ts.g.nodes(data=True)]
    ts_propositions = set.union(*[d['prop'] for _, d in ts.g.nodes(data=True)])
    formula_propositions = set(ast.propositions())
    assert formula_propositions <= ts_propositions, \
                                'There are unknown propositions in the formula!'
    return formula_propositions

def add_proposition_constraints(m, stl_milp, ts, ast, capabilities,
                                agent_classes, bound, vtype=GRB.INTEGER,num_agents=1000):
    '''Adds the proposition constraints. First, the proposition-state variables
    are defined such that capabilities are not double booked. Second, contraints
    are added such that proposition are satisfied as best as possible. The
    variables in the MILP encoding of the STL formula are used for the encoding
    as the minimizers of over proposition-state variables.

    Input
    -----
    - The Gurobi model variable.
    - The MILP encoding of the STL formula obtained from the CaTL specification.
    - The transition system specifying the environment.
    - The AST of the CaTL specification formula.
    - Dictionary of capability encoding that maps capabilities to binary words
    represented as integers.
    - The agent classes given as a dictionary from frozen sets of capabilities
    to bitmaps (integers).
    - Time bound.
    - Variable type (default: integer).'F[0, 10] T(2, orange, {(UV, 1), (Mo, 1)})'
    '''
    props = extract_propositions(ts, ast)

    # add proposition-state variables
    for u, ud in ts.g.nodes(data=True):
        ud['prop_vars'] = dict()
        for c in capabilities:
            ud['prop_vars'][c] = []
            for k in range(bound+1):
                ud['prop_vars'][c].append(dict())
                #print ud.keys()
                for prop in ud['prop']:
                    name = 'z_{}_{}_{}_{}'.format(prop, u, c, k)
                    ud['prop_vars'][c][k][prop] = m.addVar(vtype=vtype,lb=0, ub=num_agents,
                                                           name=name)

    # constraints for relating (proposition, state) pairs to system states
    for u, ud in ts.g.nodes(data=True):
        for c in capabilities:
            for k in range(bound+1):
                equality = sum([ud['prop_vars'][c][k][prop]
                                                    for prop in ud['prop']])
                equality -= sum([ud['vars'][k][g] for g in agent_classes
                                                                    if c in g])
                equality = (equality == 0)
                m.addConstr(equality, 'prop_state_{}_{}_{}'.format(u, c, k))

    # add propositions constraints for only those variables appearing in the
    # MILP encoding of the formula
    for prop in props:
        for c in capabilities:
            for k in range(bound+1):
                variable = '{}_{}'.format(prop, c)
                if (variable in stl_milp.variables
                                        and k in stl_milp.variables[variable]):
                    minPropTotal = -1
                    for u, ud in ts.g.nodes(data=True):
                        if prop in ud['prop']:
                            pvar = m.addVar(vtype=GRB.BINARY,name='p_{}_{}_{}_{}'.format(prop, c, k, u))
                            minPropTotal +=  pvar
                            minPropLB = (ud['prop_vars'][c][k][prop] -(1-pvar)*stl_milp.M <= stl_milp.variables[variable][k])
                            minPropUB = (ud['prop_vars'][c][k][prop] +(1-pvar)*stl_milp.M>= stl_milp.variables[variable][k])
                            min_prop = (stl_milp.variables[variable][k]
                                                <= ud['prop_vars'][c][k][prop])
                            m.addConstr(min_prop, 'min_prop_{}_{}_{}_{}'.format(
                                                                prop, c, k, u))
                            m.addConstr(minPropLB, 'min_prop_lb_{}_{}_{}_{}'.format(
                                                             prop, c, k, u))
                            m.addConstr(minPropUB, 'min_prop_ub_{}_{}_{}_{}'.format(
                                                            prop, c, k, u))
                    minPropTotal = (minPropTotal == 0)
                    m.addConstr(minPropTotal,'min_prop_total_{}_{}_{}_{}'.format(
                                                        prop, c, k, u))


def extract_trajetories(m, ts, agents, bound):
    '''TODO:
    '''
    raise NotImplementedError
    # initialize trajectories for each agent
    trajectories = [[(state, 0)] for state, _ in agents]

    for k in range(1, bound+1):
        # setup matching problem
        prev = [trajectories[agent][-1] for agent in len(agents)]

        matching = dict()
        constraints = {} # active transitions whose constraints have to be met
        for a, (state, time) in enumerate(prev):
            assert k-1 <= time
            if time == k-1: # check if vehicle needs to be assigned next state
                matching[prev] = [] # initialize possible future states
                agent_class = agents[a][1] # extract agent class
                # loop over outgoing transitions that have agents of the given
                # class traversing them; add outgoing neighbors
                for _, next_state, d in ts.g.out_edges_iter(state, data=True):
                    if d['vars'][time+d['weight']][agent_class] > 0:
                        matching[prev].append((next_state, time+d['weight']))
                        constraints.add((state, next_state, time+d['weight']))

        # create constraint matching problem
        # TODO: each agent in `matching' has to be matched to a future statez_q6_6_11
        # such that each active transition in `constraints' has exactly the
        # the correct amount of agents traversing it
        # NOTE: It seems to me to be an instance of the knapsack problem, but I
        # am not sure. It can be posed as an ILP.

    return trajectories

def constrain_grave_state(m,agents,ts,ast,capabilities,agent_classes,grave_region,replan_region=None,replan_cap=None,replan_time=None,replan_agent_loss=None):

    if replan_time == None:
        for k in range(0,int(ast.bound())+1):
            for g in agent_classes.items():
                name = 'z_' + str(grave_region) + '_' + str(g[1]) + '_' + str(k)
                name_val = m.getVarByName(name)
                m.addConstr(name_val == 0, 'grave_reject_{}_{}_{}'.format(str(grave_region),g[1],k))
    else:
         for k in range(replan_time-1,int(ast.bound())+1):
            for g in agent_classes.items():
                if g[1] == replan_cap:
                    name = 'grave_reject_{}_{}_{}'.format(str(grave_region),g[1],k)
                    name_val = m.getConstrByName(name)
                    m.remove(name_val)
                    name1 = 'z_' + str(grave_region) + '_' + str(g[1]) + '_' + str(k)
                    name_val1 = m.getVarByName(name1)
                    m.addConstr(name_val1 <= replan_agent_loss, 'grave_reject_{}_{}_{}'.format(str(grave_region),g[1],k))


def replan_route(m,agents,ts,ast,capabilities,agent_classes,stl_milp,replan_region,replan_cap,replan_time,replan_agent_loss,grave_region):
    '''TODO:
       -Set equality for 0 to replan_time variables
       -@ replan time, remove replan_agent from flow constraint
       -@ replan time, remove replan_agent from active state variable - set to equality constaint
       -re-add all constraints from prior model
    '''
    '''
       -remove all past constraints before replan_time

       -make equality constraints for all past variables
    '''

    # Generate equality constraints for past variables up to time replan_time-1:
    props = extract_propositions(ts, ast)
    # node variables
    #print(ts.g.nodes(data=True))
    for u, d in ts.g.nodes(data=True):
        for k in range(0,replan_time):
            for g in agent_classes.items():
                name = 'z_' + str(u) + '_' + str(g[1]) + '_' + str(k)
                name_val = m.getVarByName(name)
                m.addConstr(name_val == int(name_val.X), 'replan_eq_{}_{}_{}'.format(u,g[1],k))

    #name = 'z_' + str(replan_region) + '_' + str(replan_cap) + '_' + str(replan_time)
    #name_val = m.getVarByName(name)
    #m.addConstr(name_val == int(name_val.X)-replan_agent_loss, 'replan_eq_{}_{}_{}'.format(str(replan_region),str(replan_cap),str(replan_time)))

    # edge variables
    for u, v, d in ts.g.edges(data=True):
        for k in range(-1,replan_time):
            for g in agent_classes.items():
                #if str(u) == str(replan_region) and str(v) == str(replan_region) and str(g) == str(replan_cap) and str(k) == str(replan_time):
                 #   continue
                #if str(u) == str(replan_region) and str(v) == str(grave_region) and str(g[1]) == str(replan_cap) and str(k) == str(replan_time):
                #    name = 'z_' + str(u) + '_' + str(v) + '_' + str(g[1]) + '_' + str(k)
                #    name_val = m.getVarByName(name)
                #    m.addConstr(name_val == (int(replan_agent_loss)+int(name_val.X)), 'replan_eq_{}_{}_{}_{}'.format(u,v,g[1],k))
                #else:
                name = 'z_' + str(u) + '_' + str(v) + '_' + str(g[1]) + '_' + str(k)
                name_val = m.getVarByName(name)
                m.addConstr(name_val == int(name_val.X), 'replan_eq_{}_{}_{}_{}'.format(u,v,g[1],k))
    name = 'z_' + str(replan_region) + '_' + str(grave_region) + '_' + str(replan_cap) + '_' + str(replan_time)
    name_val = m.getVarByName(name)
    m.addConstr(name_val == (int(replan_agent_loss)+int(name_val.X)), 'replan_eq_{}_{}_{}_{}'.format(str(replan_region),str(grave_region),str(replan_cap),str(replan_time)))
    #Proposition Variables
    for prop in props:
        for c in capabilities:
            for k in range(0,replan_time):
                variable = '{}_{}'.format(prop, c)
                if (variable in stl_milp.variables
                                        and k in stl_milp.variables[variable]):
                    for u, ud in ts.g.nodes(data=True):
                        if prop in ud['prop']:
                            name='p_{}_{}_{}_{}'.format(prop, c, k, u)
                            name_val = m.getVarByName(name)
                            m.addConstr(name_val == int(name_val.X), 'replan_props_{}_{}_{}_{}'.format(prop, c, k, u))

    #Propotion State Variables
    for u, ud in ts.g.nodes(data=True):
        ud['prop_vars'] = dict()
        for c in capabilities:
            ud['prop_vars'][c] = []
            for k in range(0,replan_time):
                ud['prop_vars'][c].append(dict())
                #print ud.keys()
                for prop in ud['prop']:
                    name = 'z_{}_{}_{}_{}'.format(prop, u, c, k)
                    name_val = m.getVarByName(name)
                    m.addConstr(name_val == int(name_val.X), 'replan_prop_vars_{}_{}_{}_{}'.format(prop, c, k, u))


    #Edit flow constraints to reflect lost agent:

    replan_time_const = replan_time+1
    team_constr = m.getConstrByName('team_{}_{}_{}'.format(replan_region,replan_cap,replan_time_const))
    conserve_constr = m.getConstrByName('conserve_{}_{}_{}'.format(replan_region,replan_cap,replan_time_const))

    team_constr.setAttr("rhs", -1.0*replan_agent_loss)
    #conserve_constr.setAttr("rhs",-1.0*replan_agent_loss)

    #name = 'z_' + str(replan_region) + '_' + str(replan_cap) + '_' + str(replan_time)
    #name_val = m.getVarByName(name)
    #m.addConstr(name_val == (int(name_val.X)-replan_agent_loss), 'replan_eq_{}_{}_{}'.format(replan_region,replan_cap,replan_time))

    m.update()
    m.optimize()





def route_planning(ts, agents, formula, bound=None,file_name=None, replan_req=False, load_old_file=False, reload_file=None):
    '''Performs route planning for agents `agents' moving in a transition system
    `ts' such that the CaTL specification `formula' is satisfied.

    Input
    -----
    - The transition system specifying the environment.
    - List of agents, where agents are tuples (q, cap), q is the initial state
    of the agent, and cap is the set of capabilities. Agents' identifiers are
    their indices in the list.
    - The CaTL specification formula.
    - The time bound used in the encoding (default: computed from CaTL formula).

    Output
    ------
    TODO: TBD
    '''

    replan_grave = 'q9'


    ast = CMTLFormula.from_formula(formula)
    if bound is None:
        bound = int(ast.bound())
    print ast
    # create MILP
    if load_old_file:
        old_m = gurobipy.read(reload_file+'.lp')
        #old_m.read(reload_file+'.mps')
        old_m.read(reload_file+'.sol')

    m = GRBModel('milp')

    # create system variables
    capabilities = compute_capability_bitmap(agents)
    agent_classes = compute_agent_classes(agents, capabilities)
    create_system_variables(m, ts, agent_classes, bound,num_agents=len(agents))


    # add system constraints
    capability_distribution = compute_initial_capability_distribution(ts,
                                                           agents, capabilities)
    add_system_constraints(m, ts, agent_classes, capability_distribution, bound)

    # add CMTL formula constraints
    stl = cmtl2stl(ast)
    print stl
    stl_milp = stl2milp.stl2milp(stl, model=m,robust=True)
    z_formula = stl_milp.to_milp(stl)

    # add proposition constraints
    add_proposition_constraints(m, stl_milp, ts, ast, capabilities,
                            agent_classes, bound,num_agents=len(agents))

    constrain_grave_state(m,agents,ts,ast,capabilities,agent_classes,replan_grave)

    if load_old_file:
        #m = gurobipy.read(reload_file+'.lp')
        #m.read(reload_file+'.sol')
        old_m.optimize()
    else:
        # run optimizer
        m.optimize()
    #print(capabilities)

        if m.status == GRB.Status.OPTIMAL:
            logging.info('"Optimal objective LP": %f', m.objVal)
        elif m.status == GRB.Status.INF_OR_UNBD:
            logging.error('Model is infeasible or unbounded')
        elif m.status == GRB.Status.INFEASIBLE:
            logging.error('Model is infeasible')
        elif m.status == GRB.Status.UNBOUNDED:
            logging.error('Model is unbounded')
        else:
            logging.error('Optimization ended with status %s', m.status)

    if load_old_file == False:
        m.write("example_pre_replan_test_simple_newspec.mps")
        m.write("example_pre_replan_test_simple_newspec.lp")
        m.write("example_pre_replan_test_simple_newspec.sol")

    if replan_req:
        replan_time = 24
        replan_region = 'q2'
        replan_grave = 'q9'
        replan_num = 1
        replan_cap = 3
        constrain_grave_state(m,agents,ts,ast,capabilities,agent_classes,replan_grave,replan_region,replan_cap,replan_time,replan_num)
        replan_route(m,agents,ts,ast,capabilities,agent_classes,stl_milp,replan_region,replan_cap,replan_time,replan_num,replan_grave)


    if m.status == GRB.Status.OPTIMAL:
        logging.info('"Optimal objective LP": %f', m.objVal)
    elif m.status == GRB.Status.INF_OR_UNBD:
        logging.error('Model is infeasible or unbounded')
    elif m.status == GRB.Status.INFEASIBLE:
        logging.error('Model is infeasible')
    elif m.status == GRB.Status.UNBOUNDED:
        logging.error('Model is unbounded')
    else:
        logging.error('Optimization ended with status %s', m.status)
    if replan_req:
        m.write("example_replan_test_simple.mps")
        m.write("example_replan_test_simple.lp")
        m.write("example_replan_test_simple.sol")
#     return extract_trajetories(m, ts, agents, bound) #TODO:
    return m
