from __future__ import print_function
from z3 import *
import networkx as nx
from catl_encoding.cmtl import CMTLFormula
from catl_encoding.cmtl import Operation as CMTLOperation
from itertools import *
import sys

def encode_assignment_z3(opt,vrs,constraints,G,ts):

    # TODO: refactor so we use constraints (the variable) to index into variables that have already been declared 
    # lambda_m_Agent_j is the decision variable, so it doesn't need to be encoded explicitly

    # declare Agent_j_Capability_i  
    for jj in range(len(vrs['agents'])):
        for ii in range(len(vrs['caps'])):
            ji = [(x,y) for x in range(len(vrs['agents'])) for y in range(len(vrs['caps']))].index((jj,ii))
            if vrs['caps'][ii] in vrs['agents'][jj][1]:
                opt.add(constraints['Agent_j_Capability_i'][ji]==True)
            else:
                opt.add(constraints['Agent_j_Capability_i'][ji]==False)

    # ensure all agents are assigned to at least one task!
    for jj in range(len(vrs['agents'])):
        mj = [[(x,y) for x in vrs['leaves'] for y in range(len(vrs['agents']))].index((m,jj)) for m in vrs['leaves']]
        constraint_list = [constraints['lambda_m_Agent_j'][x] for x in mj]
        opt.add(Or(constraint_list)==True)

    # lambda_m_Agent_j_Capability_i
    for m in vrs['leaves']:
        for jj in range(len(vrs['agents'])):
            for ii in range(len(vrs['caps'])):
                # encode lambda_m_Agent_j_Capability_i
                mji = [(x, y, z) for x in vrs['leaves'] for y in range(len(vrs['agents'])) for z in range(len(vrs['caps']))].index((m,jj,ii))
                ji = [(x,y) for x in range(len(vrs['agents'])) for y in range(len(vrs['caps']))].index((jj,ii))
                mj = [(x,y) for x in vrs['leaves'] for y in range(len(vrs['agents']))].index((m,jj))
                opt.add(If(And(constraints['Agent_j_Capability_i'][ji],constraints['lambda_m_Agent_j'][mj]),constraints['lambda_m_Agent_j_Capability_i'][mji]==1,constraints['lambda_m_Agent_j_Capability_i'][mji]==0))

    # lambda_m_Eligible
    for m in vrs['leaves']:
        eligible_list = list()
        ce_list = list()
        for x in zip(G.node[m]['label']['caps'],G.node[m]['label']['counts']):
            mji = [[(l, y, z) for l in vrs['leaves'] for y in range(len(vrs['agents'])) for z in range(len(vrs['caps']))].index((m,jj,vrs['caps'].index(x[0]))) for jj in range(len(vrs['agents']))]
            # get label
            label = G.node[m]['label']['label']
            # find multiplicity of that label in ts
            lab_mult = len([y for y in ts.g.nodes() if label in ts.g.node[y]['prop']])
            # list of things that need to sum to at least x[1]
            mji_list = [constraints['lambda_m_Agent_j_Capability_i'][k] for k in mji]
            num_req = x[1]*lab_mult
            eligible_list.append((Sum(mji_list)>=(x[1]*lab_mult)))
            ce_list.append(Sum(mji_list)-(x[1]*lab_mult))
        m_idx = vrs['leaves'].index(m)
        opt.add(If(And(eligible_list),constraints['lambda_m_Eligible'][m_idx]==True,constraints['lambda_m_Eligible'][m_idx]==False))
        constraints['lambda_m_Excess'][m_idx] = find_min(ce_list)
    constraints['lambda_Excess'] = find_min(constraints['lambda_m_Excess'])

    # make sure no agents are ineligibly assigned!
    for m in vrs['leaves']:
        m_idx = vrs['leaves'].index(m)
        for jj in range(len(vrs['agents'])):
            # index of agent leaf pairing
            mj = [(x,y) for x in vrs['leaves'] for y in range(len(vrs['agents']))].index((m,jj))
            # if leaf is ineligible:
            opt.add(Implies(Not(constraints['lambda_m_Eligible'][m_idx]),Not(constraints['lambda_m_Agent_j'][mj])))
            # agents are not assigned to it

    # lambda_m_Task_mu_Independent
    for x in range(len(vrs['leaves'])):
        opt.add(constraints['lambda_m_Independent'][x]==True)
    
    return opt


def operator_constraints_z3(opt,G,vrs,constraints,ts):

    # list of first letter of operators that we need to consider
    cu_set = ['A', 'U'] # first letter of labels 'AND' and 'UNTIL'
    d_set = ['O'] # first letter of label 'OR'
    ae_set = ['F', 'G'] # first letter of labels 'F' (eventually) and 'G' (always)

    opt = encode_assignment_z3(opt,vrs,constraints,G,ts)

    # loop over nodes
    for x in vrs['nodes']:
    # check type of operator:
        # get first letter of operator and check what kind it is
        op = G.node[x]['label']['label'][0] 
        # call <operator>_constraints function
        if x=='0':
            opt = root_conjunction_constraints_z3(opt,G,vrs,constraints,x)
        elif op in cu_set:
            opt = conjunction_until_constraints_z3(opt,G,vrs,constraints,x)
        elif op in d_set:
            opt = disjunction_constraints_z3(opt,G,vrs,constraints,x)
        elif op in ae_set:
            opt = always_eventually_constraints_z3(opt,G,vrs,constraints,x)

    return opt

def root_conjunction_constraints_z3(opt,G,vrs,constraints,idx):

    # index of idx
    node_idx = vrs['nodes'].index(idx)

    # index of child nodes
    child_idxs = G.successors(idx)

    # v_m_Eligible
    child_eligible = list()
    for x in child_idxs:
        if x in vrs['leaves']:
            child_idx = vrs['leaves'].index(x)            
            child_eligible.append(constraints['lambda_m_Eligible'][child_idx])

        else:
            child_idx = vrs['nodes'].index(x)
            child_eligible.append(constraints['v_m_Eligible'][child_idx])

    opt.add(If(And(child_eligible),constraints['v_m_Eligible'][node_idx]==True,constraints['v_m_Eligible'][node_idx]==False))

    for j in range(len(vrs['agents'])):
        ch_agent_list = []
        for x in child_idxs:
            if x in vrs['leaves']:
                xj = [(u, v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((x,j))
                ch_agent_list.append(constraints['lambda_m_Agent_j'][xj])
            else:
                xj = [(u, v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((x,j))
                ch_agent_list.append(constraints['v_m_Agent_j'][xj])  
        mj = [(u, v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((idx,j))
        opt.add(If(Or(ch_agent_list),constraints['v_m_Agent_j'][mj]==True,constraints['v_m_Agent_j'][mj]==False))

    for x in combinations(child_idxs,2):
        v_list = list()
        for j in range(len(vrs['agents'])):
            v_agent_list = list()
            if x[0] in vrs['leaves']:
                xj = [(u,v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((x[0],j))
                v_agent_list.append(constraints['lambda_m_Agent_j'][xj])
            else:
                xj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((x[0],j))
                v_agent_list.append(constraints['v_m_Agent_j'][xj])
            if x[1] in vrs['leaves']:
                xj = [(u,v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((x[1],j))
                v_agent_list.append(constraints['lambda_m_Agent_j'][xj])
            else:
                xj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((x[1],j))
                v_agent_list.append(constraints['v_m_Agent_j'][xj])
            v_list.append(And(v_agent_list))
        x_idx = [u for u in combinations(child_idxs,2)].index(x)
        opt.add(If(Or(v_list),constraints['root_v_m_v_mu_Independent'][x_idx]==False,constraints['root_v_m_v_mu_Independent'][x_idx]==True))
        opt.add(If(constraints['root_v_m_v_mu_Independent'][x_idx]==True,constraints['root_Independent_cost'][x_idx]==-10,constraints['root_Independent_cost'][x_idx]==0))

    # add root independent for overall cost ?

    return opt

def conjunction_until_constraints_z3(opt,G,vrs,constraints,idx):
    # get constraints from node idx in G
    # node is for conjunction or until

    # index of child nodes
    child_idxs = G.successors(idx)

    # index of parent node
    if G.predecessors(idx):
        parent_idx = vrs['nodes'].index(G.predecessors(idx)[0])
    else:
        # if node is root, let parent_idx be empty -- this condition shouldn't be met
        parent_idx = []
    # index of idx
    node_idx = vrs['nodes'].index(idx)

    # v_m_Eligible
    child_eligible = list()
    for x in child_idxs:
        if x in vrs['leaves']:
            child_idx = vrs['leaves'].index(x)            
            child_eligible.append(constraints['lambda_m_Eligible'][child_idx])
        else:
            child_idx = vrs['nodes'].index(x)
            child_eligible.append(constraints['v_m_Eligible'][child_idx])
    
    for j in range(len(vrs['agents'])):
        ch_agent_list = []
        for x in child_idxs:
            if x in vrs['leaves']:
                xj = [(u, v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((x,j))
                ch_agent_list.append(constraints['lambda_m_Agent_j'][xj])
            else:
                xj = [(u, v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((x,j))
                ch_agent_list.append(constraints['v_m_Agent_j'][xj])  
        mj = [(u, v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((idx,j))
        opt.add(If(Or(ch_agent_list),constraints['v_m_Agent_j'][mj]==True,constraints['v_m_Agent_j'][mj]==False))

    # v_m_Eligible is an And() operation over a list of Child_Eligible
    opt.add(If(And(child_eligible),constraints['v_m_Eligible'][node_idx]==True,constraints['v_m_Eligible'][node_idx]==False))

    # since we are not at the root, we only have binary relationships
    # put a warning here just in case
    if len(child_idxs)>2:
        print ("WARNING: Expected binary operator at UNTIL and CONJUNCTION")
        sys.exit()
    v_list = list()
    for j in range(len(vrs['agents'])):
        v_agent_list = list()
        for x in child_idxs:
            if x in vrs['leaves']:
                xj = [(u,v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((x,j))
                v_agent_list.append(constraints['lambda_m_Agent_j'][xj])
            else:
                xj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((x,j))
                v_agent_list.append(constraints['v_m_Agent_j'][xj])
        v_list.append(And(v_agent_list))
    opt.add(If(Or(v_list),constraints['v_m_Independent'][node_idx]==False,constraints['v_m_Independent'][node_idx]==True))
    opt.add(If(constraints['v_m_Independent'][node_idx],constraints['v_Independent_cost'][node_idx]==-1,constraints['v_Independent_cost'][node_idx]==0))

    return opt

def always_eventually_constraints_z3(opt,G,vrs,constraints,idx):
    # get constraints from node idx in G
    # node is for always or eventually operator

    # index of child node
    child_idx = G.successors(idx)[0]
    # index of parent node
    parent_idx = vrs['nodes'].index(G.predecessors(idx)[0])
    # index of idx
    node_idx = vrs['nodes'].index(idx)
    # index in Op_m_Class_f constraints
    init_idx = node_idx*len(vrs['all_class'])

    if child_idx in vrs['leaves']: # child is a task
        for y in range(len(vrs['agents'])):
            mj = [(u,v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((child_idx,y))
            vj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((idx,y))
            opt.add(If(constraints['lambda_m_Agent_j'][mj],constraints['v_m_Agent_j'][vj]==True,constraints['v_m_Agent_j'][vj]==False))
        child_idx = vrs['leaves'].index(child_idx)
        opt.add(If(constraints['lambda_m_Eligible'][child_idx],constraints['v_m_Eligible'][node_idx]==True,constraints['v_m_Eligible'][node_idx]==False))
        opt.add(constraints['v_m_Independent'][node_idx]==constraints['lambda_m_Independent'][child_idx])
        opt.add(If(constraints['v_m_Independent'][node_idx],constraints['v_Independent_cost'][node_idx]==-1,constraints['v_Independent_cost'][node_idx]==0))

    else: # child is an operator
        for y in range(len(vrs['agents'])):
            mj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((child_idx,y))
            vj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((idx,y))
            opt.add(If(constraints['v_m_Agent_j'][mj],constraints['v_m_Agent_j'][vj]==True,constraints['v_m_Agent_j'][vj]==False))
        child_idx = vrs['nodes'].index(child_idx)
        # v_m_Eligible
        opt.add(If(constraints['v_m_Eligible'][child_idx],constraints['v_m_Eligible'][node_idx]==True,constraints['v_m_Eligible'][node_idx]==False))
        opt.add(constraints['v_m_Independent'][node_idx]==constraints['v_m_Independent'][child_idx])
        opt.add(If(constraints['v_m_Independent'][node_idx],constraints['v_Independent_cost'][node_idx]==-1,constraints['v_Independent_cost'][node_idx]==0))

    return opt

def disjunction_constraints_z3(opt,G,vrs,constraints,idx):

    # get indices of child nodes
    child_idxs = G.successors(idx)

    # index of parent node
    parent_idx = vrs['nodes'].index(G.predecessors(idx)[0])
    #index of idx
    node_idx = vrs['nodes'].index(idx)
    init_idx = node_idx*len(vrs['all_class'])

    # add xor between the eligibility of the children
    child_xor = list()
    for x in child_idxs:
        if x in vrs['leaves']:
            # append leaf eligibility
            child_idx = vrs['leaves'].index(x)
            child_xor.append(constraints['lambda_m_Eligible'][child_idx])
        else:
            # append node eligibility
            child_idx = vrs['nodes'].index(x)
            child_xor.append(constraints['v_m_Eligible'][child_idx])

    opt.add(listXor(child_xor))

    child_consts = list()
    for x in child_idxs:
        child_list = list()
        if x in vrs['leaves']:
            child_idx = vrs['leaves'].index(x)
            child_list.append(constraints['v_m_Eligible'][node_idx]==constraints['lambda_m_Eligible'][child_idx])
            child_list.append(constraints['v_m_Independent'][node_idx]==constraints['lambda_m_Independent'][child_idx])
            child_list.append(If(constraints['v_m_Independent'][node_idx],constraints['v_Independent_cost'][node_idx]==-1,constraints['v_Independent_cost'][node_idx]==0))
            for y in range(len(vrs['agents'])):
                mj = [(u,v) for u in vrs['leaves'] for v in range(len(vrs['agents']))].index((x,y))
                vj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((idx,y))
                child_list.append(If(constraints['lambda_m_Agent_j'][mj],constraints['v_m_Agent_j'][vj]==True,constraints['v_m_Agent_j'][vj]==False))
        else:
            child_idx = vrs['nodes'].index(x)
            child_list.append(constraints['v_m_Eligible'][node_idx]==constraints['v_m_Eligible'][child_idx])
            child_list.append(constraints['v_m_Independent'][node_idx]==constraints['v_m_Independent'][child_idx])
            child_list.append(If(constraints['v_m_Independent'][node_idx],constraints['v_Independent_cost'][node_idx]==-1,constraints['v_Independent_cost'][node_idx]==0))
            for y in range(len(vrs['agents'])):
                mj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((x,y))
                vj = [(u,v) for u in vrs['nodes'] for v in range(len(vrs['agents']))].index((idx,y))
                child_list.append(If(constraints['v_m_Agent_j'][mj],constraints['v_m_Agent_j'][vj]==True,constraints['v_m_Agent_j'][vj]==False))
        child_consts.append(And(child_list))

    opt.add(listXor(child_consts))

    return opt

def mymin(x,y):
    # function to compute min of two integers
    return If(x >= y, y, x)

def find_min(mylist):
    # function to compute min from list of integers
    if len(mylist)>1:
        min_exp = mymin(mylist[0],mylist[1])
        for i in range(2,len(mylist)):
            min_exp = mymin(min_exp,mylist[i])
    else:
        min_exp = mylist[0]
    return min_exp

def listXor(in_list):
    # helper function to nest Xor for more than 2 arguments

    xor_out = Xor(in_list[0],in_list[1])
    if len(in_list)>2:
        for x in range(2,len(in_list)):
            xor_out = Xor(xor_out,in_list[x])

    return xor_out

def declare_vrs(vrs,G):
    # make dictionary of lists of constraints to be passed to other functions in z3_functions

    constraints = dict()

    # agents and capabilities
    constraints['Agent_j_Capability_i'] = [Bool('Agent_%s_Capability_%s' % (x,y)) for x in range(len(vrs['agents'])) for y in range(len(vrs['caps']))]

    # task constraints
    constraints['lambda_m_Agent_j'] = [Bool('lambda_%s_Agent_%s' % (x, y)) for x in vrs['leaves'] for y in range(len(vrs['agents']))]
    constraints['lambda_m_Eligible'] = [Bool('lambda_%s_Eligible' % x) for x in vrs['leaves']]
    constraints['lambda_m_Agent_j_Capability_i'] = [Int('lambda_%s_Agent_%s_Capability_%s' % (x, y, z)) for x in vrs['leaves'] for y in range(len(vrs['agents'])) for z in range(len(vrs['caps']))]
    constraints['lambda_m_Independent'] = [Bool('lambda_%s_Independent' % x) for x in vrs['leaves']]
    constraints['lambda_m_Excess'] = [Int('lambda_%s_Excess' % x) for x in vrs['leaves']]
    constraints['lambda_Excess'] = [Int('lambda_Excess')]
    
    # node constraints
    constraints['v_m_Eligible'] = [Bool('v_%s_Eligible' % x) for x in vrs['nodes']]
    constraints['v_m_Agent_j'] = [Bool('v_%s_Agent_%s' % (x,y)) for x in vrs['nodes'] for y in range(len(vrs['agents']))]
    constraints['v_m_Independent'] = [Bool('v_%s_Independent' % x) for x in vrs['nodes']]
    constraints['v_Independent_cost'] = [Int('v_%s_Independent_cost' % x) for x in vrs['nodes']]

    children = G.successors('0')
    constraints['root_v_m_v_mu_Independent'] = [Bool('root_v_%s_v_%s_Independent' % (y[0],y[1])) for y in combinations(children,2)] 
    constraints['root_Independent_cost'] = [Int('root_v_%s_v_%s_Independent_cost' % (y[0],y[1])) for y in combinations(children,2)]
    constraints['root_Independent'] = [Bool('root_Independent')]
    
    return constraints

def plotAST_nx(specification):
    ast = CMTLFormula.from_formula(specification)
    dot = nx.DiGraph()
    idx = 0
    cmdStr = 'ast'
    dot.add_node(str(idx))
    dot.node[str(idx)]['label'] = propMap(eval(cmdStr+'.op'),cmdStr,ast)
    successor, sString = getProps(ast)
    numChildren = len(successor)
    toCheck = range(numChildren)
    maxIdx = idx

    while toCheck:
        chkIdx = toCheck.pop(0)
        if len(eval(cmdStr+'.'+sString))>1:
            newCmd = cmdStr+'.'+sString+'['+str(chkIdx)+']'
        else:
            newCmd = cmdStr+'.'+sString
        dot, maxIdx = addNode_nx(dot, newCmd,0,maxIdx,ast)

    return dot

def getProps(obj):
    if "op" in dir(obj):
        if obj.op in (CMTLOperation.NOT, CMTLOperation.EVENT, CMTLOperation.ALWAYS):
            successor = [obj.child]
            sString = 'child'
        elif obj.op in (CMTLOperation.AND, CMTLOperation.OR):
            successor = obj.children
            sString = 'children'
        elif obj.op in (CMTLOperation.IMPLIES, CMTLOperation.UNTIL):
            successor = [obj.left, obj.right]
            sString = ['left', 'right']
        else:
            successor = []
            sString = ''
        return successor, sString

def addNode_nx(digraph,cmdStr,pIdx,maxIdx,ast):

    idx = maxIdx+1
    digraph.add_node(str(idx))
    digraph.node[str(idx)]['label'] = propMap(eval(cmdStr+'.op'),cmdStr,ast)
    digraph.add_edge(str(pIdx),str(idx))
    maxIdx = idx

    successor, sString = getProps(eval(cmdStr))
    if isinstance(successor,list):
        numChildren = len(successor)
        toCheck = range(numChildren)
        while toCheck:
            chkIdx = toCheck.pop(0)
            if 'left' in sString:
                newCmd =cmdStr+'.'+sString[chkIdx]
            elif sString=='children':
                newCmd = cmdStr+'.'+sString+'['+str(chkIdx)+']'
            else:
                newCmd = cmdStr+'.'+sString
            digraph, maxIdx = addNode_nx(digraph, newCmd,idx,maxIdx,ast)
    else:
        newCmd = cmdStr+'.'+sString
        digraph, maxIdx = addNode_nx(digraph, newCmd,idx,maxIdx,ast)

    return digraph, maxIdx

def getLeaves_nx(G):
    # requires string pointing to dot file with graphviz graph object

    # get leaves of graph
    leaves = [x for x in G.nodes() if G.out_degree(x)==0 and G.in_degree(x)==1]

    return leaves


def propMap(prop_num,cmdStr,ast):

    if prop_num == 0: # NOP
        propString = {'label': 'NOP'}
    elif prop_num == 1: # NOT
        propString = {'label': '!'}
    elif prop_num == 2: # OR
        propString = {'label': 'OR'}
    elif prop_num == 3: # AND
        propString = {'label': 'AND'}
    elif prop_num == 4: # IMPLIES
        propString = {'label': '-->'}
    elif prop_num == 5: # UNTIL
        propString = {'label': 'U ['+str(eval(cmdStr+'.low'))+', '+str(eval(cmdStr+'.high'))+']'}
    elif prop_num == 6: # EVENT
        propString = {'label': 'F ['+str(eval(cmdStr+'.low'))+', '+str(eval(cmdStr+'.high'))+']'}
    elif prop_num == 7: # ALWAYS
        propString = {'label': 'G ['+str(eval(cmdStr+'.low'))+', '+str(eval(cmdStr+'.high'))+']'}
    elif prop_num == 8: # PRED
        countList = [i.count for i in eval(cmdStr+'.capability_requests')]
        capList = [i.capability for i in eval(cmdStr+'.capability_requests')]
        propString = {'label': str(eval(cmdStr+'.proposition')), 'duration': str(eval(cmdStr+'.duration')),'caps':capList,'counts':countList}
    elif prop_num == 9: # BOOL
        propString = {'label': 'BOOL'}
    return propString

def init_vrs(agents,G):

    # list of capabilities
    caps = list(set.union(*[cap for _, cap in agents]))

    # get set of unique classes
    classes = [x for _,x in agents]
    all_class = list()
    for x in range(len(classes)-1,-1,-1):
        if classes.index(classes[x])==x:
            all_class.append(classes[x])

    # maximum number of each class
    max_f = [ len([x for x in range(len(classes)) if classes[x]==y]) for y in all_class]

    leaves = getLeaves_nx(G)
    nodes = list(set(G.nodes())-set(leaves))

    vrs = dict()

    vrs['caps']        = caps
    vrs['all_class']   = all_class
    vrs['nodes']       = nodes
    vrs['leaves']      = leaves
    vrs['max_f']       = max_f
    vrs['agents']      = agents

    return vrs
