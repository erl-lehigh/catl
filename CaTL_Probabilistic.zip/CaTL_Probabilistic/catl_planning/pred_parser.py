import pandas as pd
import numpy as np

from lomap import Ts
from traj_planner import *

def pred_parser(data):
	# full predicate parser

	# convert to matrix
	var_data = data.as_matrix()
	
	# get all variables that start as 'p'
	p_vars = [x[0] for x in var_data if x[0][0:2]=='p_']

	# populate an array with p_vars
	# entries are label, predicate, time, state, count
	preds = []
	map(lambda x: preds.append([x.split('_')[1],x.split('_')[2],x.split('_')[3],x.split('_')[4].split(' ')[0],x.split('_')[4].split(' ')[1]]), p_vars)
	np.asarray(preds)

	return preds

def pred_parser_short(data):
	# returns triples instead of the full predicate parsing

	# convert to matrix
	var_data = data.as_matrix()
	
	# get all variables that start as 'p'
	p_vars = [x[0] for x in var_data if x[0][0:2]=='p_']

	# populate an array with p_vars
	# entries are label, predicate, time, state, count
	preds = []
	map(lambda x: preds.append([x.split('_')[2],x.split('_')[3],x.split('_')[4].split(' ')[0]]), p_vars)
	np.asarray(preds)

	return preds

def get_agent_preds(data,traj,caps,ts):
	# get relevant predicates from agent and trajectory

	# now match location at each time with label, for each cap, to get predicates of the form:
	# Label_Cap_Time
	preds = pred_parser_short(data)
	agent_preds = list()
	for cap in caps: # capability
		for t,s in traj: # states
			if [cap, str(t), 'q'+str(s)] in preds:
				for l in ts.g.node['q'+str(s)]['prop']:
					agent_preds.append(l+'_'+cap+'_'+str(t))

	return agent_preds

def get_occ_times(data,traj,caps,ts):
	# for an agent and trajectort, return times that correspond to predicates in the sol file

	agent_preds = get_agent_preds(data,traj,caps,ts)

	# indices that an agent *might* be occupied
	occ_times = [x.split('_')[2] for x in agent_preds]

	return occ_times

def get_occ_list(agents,agent_positions,data,ts):
	occ_times = list()
	# get times when an agent *might* be contributing to a spec
	for	agent_idx in range(len(agents)):
		traj = [[idx,x[agent_idx]] for idx, x in enumerate(agent_positions) if isinstance(x[agent_idx],int)]
		# list of capabilities
		caps = agents[agent_idx][1]
		occ_times.append(get_occ_times(data,traj,caps,ts))

	return occ_times

def get_sol_preds(data):
	# test mapping back to task
	var_data = data.as_matrix()

	# let's find all relevant predicates from the sol file?
	# Indexes and rows of the from 'G_<stuff>_<time> 1'
	G_rows = [[idx,x[0]] for idx, x in enumerate(var_data) if x[0][0:2]=='G_' and x[0][-1]=='1']
	sig_list = []
	for row in G_rows:
		findSig = True
		findIdx = row[0]
		sig = [row[1]]
		while findSig:
			if var_data[findIdx+2][0][0:4]=='pred':
				findIdx+=2
				sig.append(var_data[findIdx+1][0])
			else:
				findSig = False
		sig_list.append(sig)

	time_vars = list()
	# loop over sig_list to extract the data we care about
	for item in sig_list:
		# check to make sure that there is at least one predicate in the item!
		if len(item)>1:
			# extract time stamp from G
			t_0 = int(item[0].split(' ')[0].split('_')[-1])
			for idx, sig in enumerate(item):
				# ignore first index, since it's 'G_'
				if idx > 0:
					row = sig.split(' ')[0].split('_') # list of label, cap, time
					t_f = int(row[-1]) # end time +1, but we use it in range, so it's fine
					time_vars += [[row[0],row[1],x] for x in range(t_0,t_f)]

	return time_vars

def get_agent_props(agent_idx,agents,agent_positions,time_vars):
	# props, caps, and time stamps for agent
	p0 = [[idx,cap,p] for idx,pos in enumerate(agent_positions) 
		if not isinstance(pos[agent_idx],list) 
		for p in ts.g.node['q'+str(pos[agent_idx])]['prop'] 
		for cap in agents[agent_idx][1]]

	p0_pred = [x for x in time_vars if [x[2],x[1],x[0]] in p0]

	return p0_pred

if __name__=="__main__":

	# load all of the stuff
	ts_filename='../TransitionSystems/demo_grave.yaml'
	data = pd.read_csv("../OutputFiles/case1/case1.sol")
	ts = Ts.load(ts_filename)
	states,edges,sim_time,preds = read_sol_data(data,ts)
	agents = [('q7', {'A1'}), ('q7', {'A1'}), ('q7', {'A2'}),  ('q7', {'A1','A2'}), ('q7',{'A1','A2'}),
	      ('q7',  {'A1'}), ('q7',  {'A2'}), ('q7',  {'A1'}), ('q7', {'A2'}), ('q7',{'A1'}),('q7',{'A2'})]

	# test initial predicate parser
	preds = pred_parser(data)

	# get trajectories and other data from solution file
	states,edges,end_time,preds = read_sol_data(data,ts)
	agent_positions,caps,num_agents,transit_times,agent_caps = assign_caps_to_trajs(states,edges,preds,end_time)

	# get list of when agents are occupied according to .sol file
	occ_list = get_occ_list(agents,agent_positions,data,ts)

	# get variables from sol file where agents matter
	time_vars = get_sol_preds(data)

	# get trajectory for agent number 0
	for agent_idx in range(len(agents)):
		prop_list = get_agent_props(agent_idx,agents,agent_positions,time_vars)

		print "Agent ", agent_idx
		for x in prop_list:
			print x