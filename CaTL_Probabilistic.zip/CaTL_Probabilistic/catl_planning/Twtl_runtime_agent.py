from util import Tree, nearest, col_free, random_sample,random_gaus_sample, steer, near, \
    mincost_nodes, PlotOpts
import util
from twtl_util import get_cat_operands, toalpha, successors, translate, final, \
    next_state, fromalpha, subform_states, forward_inputsyms, interval, nstates

import numpy as np
import time
import networkx as nx
import math

from simulation_closedform import CBF_RRT #One Step Simulation
import safe_rrt_linsys as safe_rrt
import informed_cbf_rrt as informed_safe_rrt
import rrt
import cv2
import rospy
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist, PoseStamped, Pose
#FOR VIDEO - Uncomment two lines below
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.colors as colors
import matplotlib.cm as cmx
from matplotlib.animation import FFMpegWriter
from matplotlib.backends.backend_agg import FigureCanvasAgg

from matplotlib.backends.backend_pdf import PdfPages

def update_mocap_data(data):
    global mocap_pose
    mocap_pose = data
    #print(data)

def sim_to_world_convert(simy, simx):

    x_off = -0.686
    y_off = -1.330
    scaley = -0.67
    scalex = 0.67 #6773

    simx = np.array(simx)
    simy = np.array(simy)

    worldx = (simx * scalex) + x_off
    worldy = (simy * scaley) + y_off

    return(worldx,worldy)

def twtl_online(m_struct,GlobalTraj,region,props,obstacles,avoid,visit,sensor_radius,velocity,init_taus,full_tree,visualize=True):
    t = 0
    agent_position = GlobalTraj[0,0:2]
    #print(GlobalTraj)
    full_tree = full_tree.root()

    real_taus = init_taus
    current_taus = init_taus
    spotted_targets = []
    ignore_list = []
    globalx = []
    globaly = []
    globalstate = []
    globalcost = []
    num_visit_replan = 0
    num_obs_replan = 0
    init_obs = obstacles
    sol_len = len(GlobalTraj)

    Box_obstacles = obstacles
    num_of_obstacles = len(Box_obstacles)
    cbf_obstacles = []
    obstacle_inflation = 1.1
    for obstacle_index in range(0,num_of_obstacles):
        constraints = Box_obstacles[obstacle_index].constraints
        r = obstacle_inflation * np.sqrt(2*((constraints[0,1]-constraints[0,0])*0.5)**2)
        x_centroid = (constraints[0,1]-constraints[0,0])*0.5+constraints[0,0]
        y_centroid = (constraints[1,1]-constraints[1,0])*0.5+constraints[1,0]
        cbf_obstacles.append([x_centroid,y_centroid,r])
    m_struct.cbf_obs = cbf_obstacles

    if GlobalTraj[0][0] != GlobalTraj[sol_len-1][0] or GlobalTraj[0][1] != GlobalTraj[sol_len-1][1]:
        start = GlobalTraj[sol_len-1][0:2]
        goal = GlobalTraj[0][0:2]
        #print(cbf_obstacles)
        cbf_planner = safe_rrt.RRT(start,goal,cbf_obstacles)
        local_plan = cbf_planner.Planning(animation=False)
        #local_plan = rrt.FindRRTPath(start,goal,region.constraints,rrtobstacleList,obstacles,velocity)
        for points in local_plan:
            this_point = np.array((points[0],points[1],GlobalTraj[sol_len-1][2],GlobalTraj[sol_len-1][3]))
            GlobalTraj = np.vstack((GlobalTraj,this_point))


    for points in GlobalTraj:
        globalx.append(points[0])
        globaly.append(points[1])
        globalstate.append(points[2])
        globalcost.append(points[3])


    CurrentTraj = GlobalTraj


    #Setup the video recorder
    if visualize:
        fig = plt.figure()
        metadata = dict(title='Traj_Sol', artist='Matplotlib',comment='Movie support!')
        writer = FFMpegWriter(fps=5, metadata=metadata)
        writer.setup(fig,m_struct.file_name+'.mp4',200)
    avo_targets = []
    avoid_obs = []
    prior_targets = []
    tree_change_time = -1
    cur_traj_len = len(CurrentTraj)
    #Ros image publisher
    if m_struct.run_ros_pubs == True:
        rospy.init_node('world_pubber', anonymous=True)
        global waypointdr
        global mocap_pose
        waypointdr = PoseStamped()
        mocap_pose = PoseStamped()
        drone_height = 0.6
        image_pub = rospy.Publisher("world_image",Image)
        drone_pub = rospy.Publisher('/quad_waypoint', PoseStamped, queue_size=10)
        drone_sub = rospy.Subscriber("/quad_pumpkin/mavros/mocap/pose", PoseStamped,update_mocap_data)
        bridge = CvBridge()

    while t <= len(CurrentTraj)-1:
        prior_targets = avo_targets
        avo_targets,avo_dists,vis_targets,vis_dists,targets_exist = targets_visible(agent_position,sensor_radius,visit,avoid)
        past_cur_traj_len = cur_traj_len
        cur_traj_len = len(CurrentTraj)

        #Get the current tree and its change index
        if m_struct.reverse_time == True:
            if tree_change_time <= t or past_cur_traj_len != cur_traj_len:
                cur_kp_tree,tree_change_time = next_kp_tree(full_tree,CurrentTraj,t)
                cur_kp_tree.parent = None

        #print('seen targets', prior_targets,avo_targets)
        #print(CurrentTraj)
        if targets_exist:
            #print(avo_targets,avo_dists,vis_targets,vis_dists)
            #Once a Leak is detected - Robot will visit it even if it cant see it
            #Priority - Humans
            #         - Leaks
            #         - Global Spec
            same_flag = avo_targets == prior_targets
            avo_dists = np.asarray(avo_dists)

            if (len(avo_targets)>0):
                avoid_obs = []
                for i in range(0,len(avo_targets)):
                    if (avo_dists[i] < (avo_targets[i][1][0]+(velocity))) and (avo_targets[i] not in prior_targets):
                        #print(prior_targets, avo_targets[i])
                        avoid_obs.append(avo_targets[i])
                        #print('AHH NEED TO GET AWAY FROM PERSON!')
                if len(avoid_obs)>0:
                    if len(spotted_targets)>0:
                        #local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,visit_point=spotted_targets[0][0],velocity=velocity)
                        local_plan,next_state_time = local_planner_informed(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,visit_point=spotted_targets[0][0],velocity=velocity)
                        CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time,visit_point=spotted_targets[0][0])
                    else:
                        #print('avoid_struct',avoid_obs)

                        if False:#m_struct.reverse_time == True:
                            local_plan,next_state_time = local_planner_kp_tree_reconnect(cur_kp_tree,CurrentTraj[t,:2],CurrentTraj[t,3],m_struct.d_reconnect,cbf_obstacles)
                        else:
                            local_plan,next_state_time = local_planner_informed(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,velocity=velocity)
                            #local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,velocity=velocity)
                            #local_plan,next_state_time = local_planner_rrt(agent_position,t,CurrentTraj,avoid_obs,region,props,init_obs,velocity=velocity)
                        CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time)
                        #need to implement init_obs avoidance of and back on plan

                    num_obs_replan += 1
                #Find next free point in global trajectory and point in next_state and compare costs

            #Keep a list of things to visit
            elif len(vis_targets) > 0:

                for j in range(0,len(vis_targets)):
                    if vis_dists[j] < (vis_targets[j][1][0]):

                        spotted_targets_remove = []
                        for k in range(0,len(spotted_targets)):
                            if spotted_targets[k][3]==vis_targets[j][3]:
                                spotted_targets_remove.append(vis_targets[j])
                                ignore_list.append(vis_targets[j][3])
                                #print('ignore_list')
                        if len(spotted_targets_remove)>0:
                            for targets in spotted_targets_remove:
                                spotted_targets.remove(targets)

                    else:
                        already_seen = False
                        for k in range(0,len(spotted_targets)):
                            if spotted_targets[k][3]==vis_targets[j][3]:
                                already_seen = True
                        if not already_seen and vis_targets[j][3] not in ignore_list:
                            #Check if any points on global traj visit this point

                            #GT_dists = []
                            #for idx in range(0,len(globalx)):
                            #    GT_dists.append(np.linalg.norm(np.array((globalx[idx],globaly[idx]))-np.array(vis_targets[j][0])))
                            #if not any(val < vis_targets[j][1][0] for val in GT_dists):
                            #print('AHH NEED TO GET TO LEAK!')
                            spotted_targets.append(vis_targets[j])
                            #local_plan,next_state_time = local_planner_rrt(agent_position,t,CurrentTraj,avoid_obs,region,props,init_obs,visit_point=spotted_targets[0][0],velocity=velocity)
                            local_plan,next_state_time = local_planner_informed(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,visit_point=spotted_targets[0][0],velocity=velocity)
                            #local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,visit_point=spotted_targets[0][0],velocity=velocity)
                            CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time,visit_point=spotted_targets[0][0])
                            num_visit_replan += 1
                            #plan off solution and back
            #if len(spotted_targets)>0:
            #    local_plan = local_planner(agent_position,t,GlobalTraj,avoid_obs,region,props,init_obs,visit_point=spotted_targets[0][0])
            #    print(local_plan)
            agent_position = CurrentTraj[t,0:2]
            #figure out which ones to avoid and which ones to go to.
        else:
            #avoid_obs = []
            #spotted_targets = []
            agent_position = CurrentTraj[t,0:2]
        #print('spotted_targets',vis_targets,spotted_targets,ignore_list,vis_dists)
        for y in range(0,len(vis_dists)):
            if vis_dists[y] < 0.01:
                if vis_targets[y][3] not in ignore_list:
                    spotted_targets.remove(vis_targets[y])
                    ignore_list.append(vis_targets[y][3])
                    #print('ignore_list')

        #Check for avoid or visit targets
            #If need to replan for now - add a local trajectory
        current_taus = compute_current_taus(CurrentTraj,GlobalTraj,real_taus)
        #print("current_traj",CurrentTraj)
        #print("taus",current_taus)
        #Visualize environment
        try:
            p = 0#print(spotted_targets,avoid_obs)
        except:
            avoid_obs =[]
        curx = []
        cury = []

        if visualize:
            ax = fig.add_subplot(111)
            ax.set_xlim(region.constraints[0])
            ax.set_ylim(region.constraints[1])
            ax.set_title(current_taus)
            plot_box(ax, region, facecolor="white")

            for o in init_obs:
                plot_box(ax, o, facecolor="red")

            ax.plot(globalx,globaly,'b.-',linewidth=1.75)

            for points in CurrentTraj:
                curx.append(points[0])
                cury.append(points[1])
            ax.plot(curx,cury,'k.-',linewidth=1)
            for people in avoid:
                ax.plot(people[0][0],people[0][1],'ro')
                plot_circle(people[0][0],people[0][1],people[1][0],color='r')
            for poi in visit:
                ax.plot(poi[0][0],poi[0][1],'yo')
                plot_circle(poi[0][0],poi[0][1],poi[1][0])
            for names, regions in props.items():
                plot_box(ax, regions, facecolor="green")
                label(ax, regions.center(), names, 20)
            ax.plot(agent_position[0],agent_position[1],'k*',markersize=25)
            plot_circle(agent_position[0],agent_position[1],sensor_radius,color='k')
            with PdfPages(r'saved_pdf.pdf') as export_pdf:
                export_pdf.savefig(fig) #Save the figure that is currently in the foreground
            save_keypoint_figure(GlobalTraj,region,init_obs,props)
            plt.show(block=False)
        #fig_stream,ax = plt.subplots()
        if m_struct.run_ros_pubs == True:
            canvas = plt.get_current_fig_manager().canvas
            #agg = canvas.switch_backends(FigureCanvasAgg)
            #agg.draw()
            #s = agg.tostring_rgb()
            img = np.fromstring(canvas.tostring_rgb(), dtype=np.uint8, sep='')
            img  = img.reshape(canvas.get_width_height()[::-1] + (3,))
            img = cv2.cvtColor(img,cv2.COLOR_RGB2BGR)
            try:
                image_pub.publish(bridge.cv2_to_imgmsg(img, "bgr8"))
            except CvBridgeError as e:
                print(e)
        # img is rgb, convert to opencv's default bgr
        if visualize:
            writer.grab_frame()
            #plt.waitforbuttonpress()
            plt.pause(.1)
            plt.clf()
        #Update variables and trajecoty data/record things
        avoid,visit = compute_dynamic_requests(region,init_obs,avoid,visit)

        t += 1
        if t == len(CurrentTraj) and m_struct.single_it == False:
            CurrentTraj = GlobalTraj
            t = 0

        if m_struct.run_ros_pubs == True:
            if t == 1:
                global waypointdr
                waypointdr.pose.position.x = CurrentTraj[t,0]
                waypointdr.pose.position.y = CurrentTraj[t,1]
                waypointdr.pose.position.z = drone_height
                drone_pub.publish(waypointdr)

            near_dist = 20.0
            dist_drone = near_dist+1.0
            while dist_drone > near_dist:
                dr1_x = mocap_pose.pose.position.x
                dr1_y = mocap_pose.pose.position.y
                dr1_z = mocap_pose.pose.position.z
                setdr1_x,setdr1_y = sim_to_world_convert(waypointdr.pose.position.x,waypointdr.pose.position.y)
                setdr1_z = waypointdr.pose.position.z
                setpoint_vectdr1 = (dr1_x-setdr1_x,dr1_y-setdr1_y,dr1_z-setdr1_z)
                dist_drone = np.linalg.norm(setpoint_vectdr1)
                time.sleep(.01)
                print(setdr1_x,setdr1_y)
                print(mocap_pose)
                print(dist_drone)
            waypointdr.pose.position.x = CurrentTraj[t-1,0]
            waypointdr.pose.position.y = CurrentTraj[t-1,1]
            waypointdr.pose.position.z = drone_height

            drone_pub.publish(waypointdr)
    return CurrentTraj,current_taus,num_obs_replan,num_visit_replan

########################################
#Save Single Online Trace
########################################

def twtl_save_online(m_struct,GlobalTraj,region,props,obstacles,avoid,visit,sensor_radius,velocity):
    t = 0

    #if m_struct.reverse_time == True:
    #    GlobalTraj = GlobalTraj[::-1]

    agent_position = GlobalTraj[0,0:2]
    #print(GlobalTraj)
    spotted_targets = []
    ignore_list = []
    globalx = []
    globaly = []
    globalstate = []
    globalcost = []
    init_obs = obstacles
    sol_len = len(GlobalTraj)

    Box_obstacles = obstacles
    num_of_obstacles = len(Box_obstacles)
    cbf_obstacles = []
    obstacle_inflation = 1.1
    for obstacle_index in range(0,num_of_obstacles):
        constraints = Box_obstacles[obstacle_index].constraints
        r = obstacle_inflation * np.sqrt(2*((constraints[0,1]-constraints[0,0])*0.5)**2)
        x_centroid = (constraints[0,1]-constraints[0,0])*0.5+constraints[0,0]
        y_centroid = (constraints[1,1]-constraints[1,0])*0.5+constraints[1,0]
        cbf_obstacles.append([x_centroid,y_centroid,r])
    m_struct.cbf_obs = cbf_obstacles

    #if GlobalTraj[0][0] != GlobalTraj[sol_len-1][0] or GlobalTraj[0][1] != GlobalTraj[sol_len-1][1]:
        #rrtobstacleList = [
        #    (0,0,0),
        #    (0,0,0)
        #    ]

    #    start = GlobalTraj[sol_len-1][0:2]
    #    goal = GlobalTraj[0][0:2]
    #    print(cbf_obstacles)
    #    cbf_planner = safe_rrt.RRT(start,goal,cbf_obstacles)
    #    local_plan = cbf_planner.Planning(animation=False)
        #local_plan = rrt.FindRRTPath(start,goal,region.constraints,rrtobstacleList,obstacles,velocity)
    #    for points in local_plan:
    #        this_point = np.array((points[0],points[1],GlobalTraj[sol_len-1][2],GlobalTraj[sol_len-1][3]))
    #        GlobalTraj = np.vstack((GlobalTraj,this_point))


    for points in GlobalTraj:
        globalx.append(points[0])
        globaly.append(points[1])
        globalstate.append(points[2])
        globalcost.append(points[3])


    CurrentTraj = GlobalTraj

    #Setup the video recorder
    fig = plt.figure()
    metadata = dict(title='Traj_Sol', artist='Matplotlib',comment='Movie support!')
    writer = FFMpegWriter(fps=5, metadata=metadata)
    writer.setup(fig,m_struct.file_name+'.mp4',200)
    avo_targets = []

    prior_targets = []

    #Ros image publisher
    if m_struct.run_ros_pubs == True:
        rospy.init_node('world_pubber', anonymous=True)
        global waypointdr
        global mocap_pose
        waypointdr = PoseStamped()
        mocap_pose = PoseStamped()
        drone_height = 0.6
        image_pub = rospy.Publisher("world_image",Image)
        drone_pub = rospy.Publisher('/quad_waypoint', PoseStamped, queue_size=10)
        drone_sub = rospy.Subscriber("/quad_pumpkin/mavros/mocap/pose", PoseStamped,update_mocap_data)
        bridge = CvBridge()

    while t <= len(CurrentTraj):
        prior_targets = avo_targets
        avo_targets,avo_dists,vis_targets,vis_dists,targets_exist = targets_visible(agent_position,sensor_radius,visit,avoid)

        if targets_exist:
            #print(avo_targets,avo_dists,vis_targets,vis_dists)
            #Once a Leak is detected - Robot will visit it even if it cant see it
            #Priority - Humans
            #         - Leaks
            #         - Global Spec
            same_flag = avo_targets == prior_targets
            avo_dists = np.asarray(avo_dists)

            if (len(avo_targets)>0):
                avoid_obs = []
                for i in range(0,len(avo_targets)):
                    if (avo_dists[i] < (avo_targets[i][1][0]+(velocity))): #and (avo_targets[i] not in prior_targets):
                        print(prior_targets, avo_targets[i])
                        avoid_obs.append(avo_targets[i])
                        print('AHH NEED TO GET AWAY FROM PERSON!')
                    #if (avo_dists[i] > (avo_targets[i][1][0]+velocity)) and (avo_targets[i][3] in prior_targets):
                    #    prior_targets.remove(avo_targets[i][3])
                    #    print('AHH NEED TO GET AWAY FROM PERSON!')
                if len(avoid_obs)>0:
                    print('avoid_struct',avoid_obs)
                    #local_plan,next_state_time = local_planner_rrt(agent_position,t,CurrentTraj,avoid_obs,region,props,init_obs,velocity=velocity)
                    local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,velocity=velocity)
                    CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time)
                        #need to implement init_obs avoidance of and back on plan

                #Find next free point in global trajectory and point in next_state and compare costs

            #Keep a list of things to visit
            if len(vis_targets) > 0:

                for j in range(0,len(vis_targets)):
                    if vis_dists[j] < (vis_targets[j][1][0]):
                        spotted_targets_remove = []
                        for k in range(0,len(spotted_targets)):
                            print(spotted_targets,k,vis_targets,j)
                            if spotted_targets[k][3]==vis_targets[j][3]:
                                spotted_targets_remove.append(vis_targets[j])
                                ignore_list.append(vis_targets[j][3])
                        if len(spotted_targets_remove)>0:
                            for targets in spotted_targets_remove:
                                spotted_targets.remove(targets)


                    else:
                        already_seen = False
                        for k in range(0,len(spotted_targets)):
                            if spotted_targets[k][3]==vis_targets[j][3]:
                                already_seen = True
                        if not already_seen and vis_targets[j][3] not in ignore_list:
                            #Check if any points on global traj visit this point

                            #GT_dists = []
                            #for idx in range(0,len(globalx)):
                            #    GT_dists.append(np.linalg.norm(np.array((globalx[idx],globaly[idx]))-np.array(vis_targets[j][0])))
                            #if not any(val < vis_targets[j][1][0] for val in GT_dists):
                            print('AHH NEED TO GET TO LEAK!')
                            spotted_targets.append(vis_targets[j])
                            #local_plan,next_state_time = local_planner_rrt(agent_position,t,CurrentTraj,avoid_obs,region,props,init_obs,visit_point=spotted_targets[0][0],velocity=velocity)
                            local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,visit_point=spotted_targets[0][0],velocity=velocity)
                            CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time,visit_point=spotted_targets[0][0])
                            #plan off solution and back
            #if len(spotted_targets)>0:
            #    local_plan = local_planner(agent_position,t,GlobalTraj,avoid_obs,region,props,init_obs,visit_point=spotted_targets[0][0])
            #    print(local_plan)
            agent_position = CurrentTraj[t,0:2]
            #figure out which ones to avoid and which ones to go to.
        else:
            #avoid_obs = []
            #spotted_targets = []
            agent_position = CurrentTraj[t,0:2]

        #Check for avoid or visit targets
            #If need to replan for now - add a local trajectory

        #Visualize environment
        try:
            print(spotted_targets,avoid_obs)
        except:
            avoid_obs =[]
        curx = []
        cury = []


        ax = fig.add_subplot(111)
        ax.set_xlim(region.constraints[0])
        ax.set_ylim(region.constraints[1])
        plot_box(ax, region, facecolor="white")

        for o in init_obs:
            plot_box(ax, o, facecolor="red")

        ax.plot(globalx,globaly,'b.-',linewidth=1.75)

        for points in CurrentTraj:
            curx.append(points[0])
            cury.append(points[1])
        ax.plot(curx,cury,'k.-',linewidth=1)
        for people in avoid:
            ax.plot(people[0][0],people[0][1],'ro')
            plot_circle(people[0][0],people[0][1],people[1][0],color='r')
        for poi in visit:
            ax.plot(poi[0][0],poi[0][1],'yo')
            plot_circle(poi[0][0],poi[0][1],poi[1][0])
        for names, regions in props.items():
            plot_box(ax, regions, facecolor="green")
            label(ax, regions.center(), names, 20)
        ax.plot(agent_position[0],agent_position[1],'k*',markersize=25)
        plot_circle(agent_position[0],agent_position[1],sensor_radius,color='k')
        plt.show(block=False)
        #fig_stream,ax = plt.subplots()
        if m_struct.run_ros_pubs == True:
            canvas = plt.get_current_fig_manager().canvas
            #agg = canvas.switch_backends(FigureCanvasAgg)
            #agg.draw()
            #s = agg.tostring_rgb()
            img = np.fromstring(canvas.tostring_rgb(), dtype=np.uint8, sep='')
            img  = img.reshape(canvas.get_width_height()[::-1] + (3,))
            img = cv2.cvtColor(img,cv2.COLOR_RGB2BGR)
            try:
                image_pub.publish(bridge.cv2_to_imgmsg(img, "bgr8"))
            except CvBridgeError as e:
                print(e)
        # img is rgb, convert to opencv's default bgr
        writer.grab_frame()
        #plt.waitforbuttonpress()
        plt.pause(.1)
        plt.clf()
        #Update variables and trajecoty data/record things
        avoid,visit = compute_dynamic_requests(region,init_obs,avoid,visit)

        t += 1
        if t == len(CurrentTraj):
            return GlobalTraj,CurrentTraj

        if m_struct.run_ros_pubs == True:
            if t == 1:
                global waypointdr
                waypointdr.pose.position.x = CurrentTraj[t,0]
                waypointdr.pose.position.y = CurrentTraj[t,1]
                waypointdr.pose.position.z = drone_height
                drone_pub.publish(waypointdr)

            near_dist = 20.0
            dist_drone = near_dist+1.0
            while dist_drone > near_dist:
                dr1_x = mocap_pose.pose.position.x
                dr1_y = mocap_pose.pose.position.y
                dr1_z = mocap_pose.pose.position.z
                setdr1_x,setdr1_y = sim_to_world_convert(waypointdr.pose.position.x,waypointdr.pose.position.y)
                setdr1_z = waypointdr.pose.position.z
                setpoint_vectdr1 = (dr1_x-setdr1_x,dr1_y-setdr1_y,dr1_z-setdr1_z)
                dist_drone = np.linalg.norm(setpoint_vectdr1)
                time.sleep(.01)
                print(setdr1_x,setdr1_y)
                print(mocap_pose)
                print(dist_drone)
            waypointdr.pose.position.x = CurrentTraj[t-1,0]
            waypointdr.pose.position.y = CurrentTraj[t-1,1]
            waypointdr.pose.position.z = drone_height

            drone_pub.publish(waypointdr)

    return GlobalTraj,CurrentTraj



###############################################################
# Online Test Infrustructure
###############################################################

def twtl_online_test(m_struct,GlobalTraj,region,props,obstacles,avoid,visit,sensor_radius,velocity,init_taus,full_tree):

    t = 0
    #if m_struct.reverse_time == True:
    #    GlobalTraj = GlobalTraj[::-1]
    agent_position = GlobalTraj[0,0:2]

    #print(GlobalTraj)
    real_taus = init_taus
    current_taus = init_taus
    spotted_targets = []
    ignore_list = []
    globalx = []
    globaly = []
    globalstate = []
    globalcost = []
    init_obs = obstacles
    sol_len = len(GlobalTraj)

    Box_obstacles = obstacles
    num_of_obstacles = len(Box_obstacles)
    cbf_obstacles = []
    obstacle_inflation = 1.1
    for obstacle_index in range(0,num_of_obstacles):
        constraints = Box_obstacles[obstacle_index].constraints
        r = obstacle_inflation * np.sqrt(2*((constraints[0,1]-constraints[0,0])*0.5)**2)
        x_centroid = (constraints[0,1]-constraints[0,0])*0.5+constraints[0,0]
        y_centroid = (constraints[1,1]-constraints[1,0])*0.5+constraints[1,0]
        cbf_obstacles.append([x_centroid,y_centroid,r])
    m_struct.cbf_obs = cbf_obstacles

    if GlobalTraj[0][0] != GlobalTraj[sol_len-1][0] or GlobalTraj[0][1] != GlobalTraj[sol_len-1][1]:
        #rrtobstacleList = [
        #    (0,0,0),
        #    (0,0,0)
        #    ]

        start = GlobalTraj[sol_len-1][0:2]
        goal = GlobalTraj[0][0:2]
        print(cbf_obstacles)
        cbf_planner = safe_rrt.RRT(start,goal,cbf_obstacles)
        local_plan = cbf_planner.Planning(animation=False)
        #local_plan = rrt.FindRRTPath(start,goal,region.constraints,rrtobstacleList,obstacles,velocity)
        for points in local_plan:
            this_point = np.array((points[0],points[1],GlobalTraj[sol_len-1][2],GlobalTraj[sol_len-1][3]))
            GlobalTraj = np.vstack((GlobalTraj,this_point))


    for points in GlobalTraj:
        globalx.append(points[0])
        globaly.append(points[1])
        globalstate.append(points[2])
        globalcost.append(points[3])


    CurrentTraj = GlobalTraj

    #Setup the video recorder
    fig = plt.figure()
    metadata = dict(title='Traj_Sol', artist='Matplotlib',comment='Movie support!')
    writer = FFMpegWriter(fps=5, metadata=metadata)
    writer.setup(fig,m_struct.file_name+'.mp4',200)
    avo_targets = []
    avoid_obs = []
    prior_targets = []

    #Ros image publisher
    if m_struct.run_ros_pubs == True:
        rospy.init_node('world_pubber', anonymous=True)
        global waypointdr
        global mocap_pose
        waypointdr = PoseStamped()
        mocap_pose = PoseStamped()
        drone_height = 0.6
        image_pub = rospy.Publisher("world_image",Image)
        drone_pub = rospy.Publisher('/quad_waypoint', PoseStamped, queue_size=10)
        drone_sub = rospy.Subscriber("/quad_pumpkin/mavros/mocap/pose", PoseStamped,update_mocap_data)
        bridge = CvBridge()

    while t <= len(CurrentTraj):
        #current_node
        prior_targets = avo_targets
        avo_targets,avo_dists,vis_targets,vis_dists,targets_exist = targets_visible(agent_position,sensor_radius,visit,avoid)

        if targets_exist:
            #print(avo_targets,avo_dists,vis_targets,vis_dists)
            #Once a Leak is detected - Robot will visit it even if it cant see it
            #Priority - Humans
            #         - Leaks
            #         - Global Spec
            same_flag = avo_targets == prior_targets
            avo_dists = np.asarray(avo_dists)

            if (len(avo_targets)>0):
                avoid_obs = []
                for i in range(0,len(avo_targets)):
                    if (avo_dists[i] < (avo_targets[i][1][0]+(velocity))): #and (avo_targets[i] not in prior_targets):
                        print(prior_targets, avo_targets[i])
                        avoid_obs.append(avo_targets[i])
                        print('AHH NEED TO GET AWAY FROM PERSON!')
                    #if (avo_dists[i] > (avo_targets[i][1][0]+velocity)) and (avo_targets[i][3] in prior_targets):
                    #    prior_targets.remove(avo_targets[i][3])
                    #    print('AHH NEED TO GET AWAY FROM PERSON!')
                if len(avoid_obs)>0:
                    print('avoid_struct',avoid_obs)
                    #local_plan,next_state_time = local_planner_rrt(agent_position,t,CurrentTraj,avoid_obs,region,props,init_obs,velocity=velocity)
                    local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,velocity=velocity)
                    CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time)
                        #need to implement init_obs avoidance of and back on plan

                #Find next free point in global trajectory and point in next_state and compare costs

            #Keep a list of things to visit
            if len(vis_targets) > 0:

                for j in range(0,len(vis_targets)):
                    if vis_dists[j] < (vis_targets[j][1][0]):
                        spotted_targets_remove = []
                        for k in range(0,len(spotted_targets)):
                            print(spotted_targets,k,vis_targets,j)
                            if spotted_targets[k][3]==vis_targets[j][3]:
                                spotted_targets_remove.append(vis_targets[j])
                                ignore_list.append(vis_targets[j][3])
                        if len(spotted_targets_remove)>0:
                            for targets in spotted_targets_remove:
                                spotted_targets.remove(targets)


                    else:
                        already_seen = False
                        for k in range(0,len(spotted_targets)):
                            if spotted_targets[k][3]==vis_targets[j][3]:
                                already_seen = True
                        if not already_seen and vis_targets[j][3] not in ignore_list:
                            #Check if any points on global traj visit this point

                            #GT_dists = []
                            #for idx in range(0,len(globalx)):
                            #    GT_dists.append(np.linalg.norm(np.array((globalx[idx],globaly[idx]))-np.array(vis_targets[j][0])))
                            #if not any(val < vis_targets[j][1][0] for val in GT_dists):
                            print('AHH NEED TO GET TO LEAK!')
                            spotted_targets.append(vis_targets[j])
                            #local_plan,next_state_time = local_planner_rrt(agent_position,t,CurrentTraj,avoid_obs,region,props,init_obs,visit_point=spotted_targets[0][0],velocity=velocity)
                            local_plan,next_state_time = local_planner(m_struct,agent_position,t,CurrentTraj,avoid_obs,region,props,cbf_obstacles,visit_point=spotted_targets[0][0],velocity=velocity)
                            CurrentTraj = update_current_plan(CurrentTraj,local_plan,t,next_state_time,visit_point=spotted_targets[0][0])
                            #plan off solution and back
            #if len(spotted_targets)>0:
            #    local_plan = local_planner(agent_position,t,GlobalTraj,avoid_obs,region,props,init_obs,visit_point=spotted_targets[0][0])
            #    print(local_plan)
            agent_position = CurrentTraj[t,0:2]
            #figure out which ones to avoid and which ones to go to.
        else:
            #avoid_obs = []
            #spotted_targets = []
            agent_position = CurrentTraj[t,0:2]

        #Check for avoid or visit targets
            #If need to replan for now - add a local trajectory
        current_taus = compute_current_taus(CurrentTraj,GlobalTraj,real_taus)

        print("taus",current_taus)
        #Visualize environment
        try:
            print(spotted_targets,avoid_obs)
        except:
            avoid_obs =[]
        curx = []
        cury = []


        ax = fig.add_subplot(111)
        ax.set_xlim(region.constraints[0])
        ax.set_ylim(region.constraints[1])
        ax.set_title(current_taus)
        plot_box(ax, region, facecolor="white")

        for o in init_obs:
            plot_box(ax, o, facecolor="red")

        ax.plot(globalx,globaly,'b.-',linewidth=1.75)

        for points in CurrentTraj:
            curx.append(points[0])
            cury.append(points[1])
        ax.plot(curx,cury,'k.-',linewidth=1)
        for people in avoid:
            ax.plot(people[0][0],people[0][1],'ro')
            plot_circle(people[0][0],people[0][1],people[1][0],color='r')
        for poi in visit:
            ax.plot(poi[0][0],poi[0][1],'yo')
            plot_circle(poi[0][0],poi[0][1],poi[1][0])
        for names, regions in props.items():
            plot_box(ax, regions, facecolor="green")
            label(ax, regions.center(), names, 20)
        ax.plot(agent_position[0],agent_position[1],'k*',markersize=25)
        plot_circle(agent_position[0],agent_position[1],sensor_radius,color='k')
        plt.show(block=False)
        #fig_stream,ax = plt.subplots()
        if m_struct.run_ros_pubs == True:
            canvas = plt.get_current_fig_manager().canvas
            #agg = canvas.switch_backends(FigureCanvasAgg)
            #agg.draw()
            #s = agg.tostring_rgb()
            img = np.fromstring(canvas.tostring_rgb(), dtype=np.uint8, sep='')
            img  = img.reshape(canvas.get_width_height()[::-1] + (3,))
            img = cv2.cvtColor(img,cv2.COLOR_RGB2BGR)
            try:
                image_pub.publish(bridge.cv2_to_imgmsg(img, "bgr8"))
            except CvBridgeError as e:
                print(e)
        # img is rgb, convert to opencv's default bgr
        writer.grab_frame()
        #plt.waitforbuttonpress()
        plt.pause(.1)
        plt.clf()
        #Update variables and trajecoty data/record things
        avoid,visit = compute_dynamic_requests(region,init_obs,avoid,visit)

        t += 1
        if t == len(CurrentTraj):
            CurrentTraj = GlobalTraj
            t = 0

        if m_struct.run_ros_pubs == True:
            if t == 1:
                global waypointdr
                waypointdr.pose.position.x = CurrentTraj[t,0]
                waypointdr.pose.position.y = CurrentTraj[t,1]
                waypointdr.pose.position.z = drone_height
                drone_pub.publish(waypointdr)

            near_dist = 20.0
            dist_drone = near_dist+1.0
            while dist_drone > near_dist:
                dr1_x = mocap_pose.pose.position.x
                dr1_y = mocap_pose.pose.position.y
                dr1_z = mocap_pose.pose.position.z
                setdr1_x,setdr1_y = sim_to_world_convert(waypointdr.pose.position.x,waypointdr.pose.position.y)
                setdr1_z = waypointdr.pose.position.z
                setpoint_vectdr1 = (dr1_x-setdr1_x,dr1_y-setdr1_y,dr1_z-setdr1_z)
                dist_drone = np.linalg.norm(setpoint_vectdr1)
                time.sleep(.01)
                print(setdr1_x,setdr1_y)
                print(mocap_pose)
                print(dist_drone)
            waypointdr.pose.position.x = CurrentTraj[t-1,0]
            waypointdr.pose.position.y = CurrentTraj[t-1,1]
            waypointdr.pose.position.z = drone_height

            drone_pub.publish(waypointdr)
    return 1

def compute_dynamic_requests(region,obstacles1,avoid,visit):
    #Progress the obstacles forward for one time unit
    x = 0
    y = 0
    r = 0
    vx = 0
    vy = 0
    nextx = 0
    nexty = 0

    for i in range(0,len(avoid)):
        x = avoid[i][0][0]
        y = avoid[i][0][1]
        r = avoid[i][1]
        vx = avoid[i][2][0]
        vy = avoid[i][2][1]
        nextx = x + vx
        nexty = y + vy
        point_safe = True
        count = 0
        for obs in obstacles1:
            if obs.contains(np.array((nextx,nexty))):
                point_safe = False
        if not region.contains(np.array((nextx,nexty))):
            point_safe = False

        if point_safe:
            avoid[i][0][0] = nextx
            avoid[i][0][1] = nexty
        else:
            #Recompute velocity vector and apply to point
            safe_found = False
            while not safe_found:
                temp_vx = np.random.normal(vx,1)
                temp_vy = np.random.normal(vy,1)
                norm = np.linalg.norm((temp_vx,temp_vy))
                temp_vx = np.divide(temp_vx,norm*10)
                temp_vy = np.divide(temp_vy,norm*10)
                temp_nextx = x+temp_vx
                temp_nexty = y+temp_vy
                safe_found = True
                for obs in obstacles1:
                    if obs.contains(np.array((temp_nextx,temp_nexty))):
                        safe_found = False
                if not region.contains(np.array((temp_nextx,temp_nexty))):
                    safe_found = False
                if safe_found == True:
                    avoid[i][0][0] = temp_nextx
                    avoid[i][0][1] = temp_nexty
                    avoid[i][2][0] = temp_vx
                    avoid[i][2][1] = temp_vy
                if count > 100:
                    safe_found = True
                    avoid[i][0][0] = x - vx
                    avoid[i][0][1] = y - vy
                    avoid[i][2][0] = -vx
                    avoid[i][2][1] = -vy
                count += 1
    for i in range(0,len(visit)):
        if visit[i][2][0] != 0 and visit[i][2][1] != 0:
            x = visit[i][0][0]
            y = visit[i][0][1]
            r = visit[i][1]
            vx = visit[i][2][0]
            vy = visit[i][2][1]
            nextx = x + vx
            nexty = y + vy
            point_safe = True
            for obs in obstacles1:
                if obs.contains(np.array((nextx,nexty))):
                    point_safe = False
            if not region.contains(np.array((nextx,nexty))):
                point_safe = False

            if point_safe:
                visit[i][0][0] = nextx
                visit[i][0][1] = nexty
            else:
                #Recompute velocity vector and apply to point
                safe_found = False
                while not safe_found:
                    print('RESET VISIT SPEEDS')
                    temp_vx = np.random.normal(vx,1)
                    temp_vy = np.random.normal(vy,1)
                    norm = np.linalg.norm((temp_vx,temp_vy))
                    temp_vx = np.divide(temp_vx,norm*10)
                    temp_vy = np.divide(temp_vy,norm*10)
                    temp_nextx = x+temp_vx
                    temp_nexty = y+temp_vy
                    safe_found = True
                    for obs in obstacles1:
                        if obs.contains(np.array((temp_nextx,temp_nexty))):
                            safe_found = False
                    if not region.contains(np.array((temp_nextx,temp_nexty))):
                        safe_found = False
                    if safe_found == True:
                        visit[i][0][0] = temp_nextx
                        visit[i][0][1] = temp_nexty
                        visit[i][2][0] = temp_vx
                        visit[i][2][1] = temp_vy
                    if count > 100:
                        safe_found = True
                        visit[i][0][0] = x - vx
                        visit[i][0][1] = y - vy
                        visit[i][2][0] = -vx
                        visit[i][2][1] = -vy
                    count += 1
    return avoid,visit

def targets_visible(agent_position,sensor_radius,visit,avoid):
    avo_targets = []
    vis_targets = []
    avo_dists = []
    vis_dists = []
    targets_exist = False
    avoids_exist = False
    for attract in visit:
        dist = np.linalg.norm(agent_position-attract[0])
        if dist <= (attract[1][0]+sensor_radius):
            targets_exist = True
            vis_targets.append(attract)
            vis_dists.append(dist)
    for repel in avoid:
        dist = np.linalg.norm(agent_position-repel[0])
        if dist <= sensor_radius:
            targets_exist = True
            avoids_exist = True
            avo_targets.append(repel)
            avo_dists.append(dist)

    return avo_targets,avo_dists,vis_targets,vis_dists,targets_exist

def local_planner(m_struct,current_point,global_time,GlobalTraj,avoid_obs,region,props,cbf_obstacles,visit_point=None,velocity=0.5):

    #Given current state, find path that avoids things as best as possible
    #Find next state:
    first_obs = cbf_obstacles
    next_state_not_found = True

    next_time = global_time+1
    counter = 0
    total_time = 1
    obstacle_inflation = 1.1

    #determine what point to reactivly plan to
    while(next_state_not_found):
        if next_time == len(GlobalTraj):
            next_time = 0
            counter += 1
            if counter > 2:
                print('Global Trajectory Has Only One State - Check Global Solution')
                exit()
        if GlobalTraj[global_time,2] != GlobalTraj[next_time,2]:
            goal_time = next_time
            next_state = GlobalTraj[next_time,2]
            goal_point = GlobalTraj[next_time,0:2]
            next_state_time = total_time
            next_state_not_found = False
        else:
            next_time+=1
            total_time += 1

    rrtobstacleList = cbf_obstacles[0:6]
    #print('cbf_obs_init',cbf_obstacles)
    if avoid_obs != []:
        for obs in avoid_obs:
            #print('avoid_obs',obs)
            ##Might need to expand or shrink radius based on velocity and cbfs
            rrtobstacleList.append([obs[0][0],obs[0][1],obs[1][0],obs[2][0],obs[2][1]])
    #print(rrtobstacleList)
    #Use Timed RRT to get back pose values
    if visit_point != None:
        '''
        new_obs2 = []
        for name,obs in props.items():
            if not obs.inflate_contains(np.array((goal_point[0],goal_point[1])),1) and not obs.inflate_contains(np.array((current_point[0],current_point[1])),1) and not obs.inflate_contains(np.array((visit_point[0],visit_point[1])),1):
                constraints_new = obs.constraints
                r = obstacle_inflation * np.sqrt(2*((constraints_new[0,1]-constraints_new[0,0])*0.5)**2)
                x_centroid = (constraints_new[0,1]-constraints_new[0,0])*0.5+constraints_new[0,0]
                y_centroid = (constraints_new[1,1]-constraints_new[1,0])*0.5+constraints_new[1,0]
                new_obs2.append([x_centroid,y_centroid,r])
        for obs_data in rrtobstacleList:#m_struct.cbf_obs:
             new_obs2.append(obs_data)
        print('here',new_obs2)
        '''
        #print('obs_len',len(rrtobstacleList))
        cbf_planner_new = safe_rrt.RRT(current_point,visit_point,rrtobstacleList)#new_obs2)
        path_there = cbf_planner_new.Planning(animation=False)
        #print("path_there")
        cbf_planner_new = safe_rrt.RRT(visit_point,goal_point,rrtobstacleList)#new_obs2)
        path_back = cbf_planner_new.Planning(animation=False)
        #print("path_back")
        #print(rrtobstacleList,obstacles2,current_point,visit_point,goal_point)
        #path_there = rrt.FindRRTPath(current_point,visit_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        #path_back = rrt.FindRRTPath(visit_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if path_there == [] or path_back == []:
            new_obs3 = rrtobstacleList#m_struct.cbf_obs
            while path_there == [] or path_back == []:
                cbf_planner_new = safe_rrt.RRT(current_point,visit_point,new_obs3)
                path_there = cbf_planner_new.Planning(animation=False)
                cbf_planner_new = safe_rrt.RRT(visit_point,goal_point,new_obs3)
                path_back = cbf_planner_new.Planning(animation=False)
                #path_there = rrt.FindRRTPath(current_point,visit_point,region.constraints,rrtobstacleList,obstacles2,velocity)
                #path_back = rrt.FindRRTPath(visit_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        local_plan = np.concatenate((path_there,path_back[1:]))
        return local_plan,next_state_time

    else:
        '''
        extra_obs = rrtobstacleList#m_struct.cbf_obs
        for name,obs in props.items():
            if not obs.contains(np.array((goal_point[0],goal_point[1]))) and not obs.contains(np.array((current_point[0],current_point[1]))):
                constraints3 = obs.constraints
                r = obstacle_inflation * np.sqrt(2*((constraints3[0,1]-constraints3[0,0])*0.5)**2)
                x_centroid = (constraints3[0,1]-constraints3[0,0])*0.5+constraints3[0,0]
                y_centroid = (constraints3[1,1]-constraints3[1,0])*0.5+constraints3[1,0]
                extra_obs.append([x_centroid,y_centroid,r])
        print('here',extra_obs)
        '''
        #print('obs_len',len(rrtobstacleList))
        cbf_planner_new = safe_rrt.RRT(current_point,goal_point,rrtobstacleList)#extra_obs)
        local_plan = cbf_planner_new.Planning(animation=False)
        #local_plan = rrt.FindRRTPath(current_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if local_plan == []:
            #extra_obs = rrtobstacleList#m_struct.cbf_obs
            cbf_planner_new = safe_rrt.RRT(current_point,goal_point,rrtobstacleList)#extra_obs)
            while local_plan == []:
                local_plan = cbf_planner_new.Planning(animation=False)
                #local_plan = rrt.FindRRTPath(current_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        return local_plan,next_state_time

def local_planner_informed(m_struct,current_point,global_time,GlobalTraj,avoid_obs,region,props,cbf_obstacles,visit_point=None,velocity=0.5):

    #Given current state, find path that avoids things as best as possible
    #Find next state:
    first_obs = cbf_obstacles
    next_state_not_found = True

    next_time = global_time+1
    counter = 0
    total_time = 1
    obstacle_inflation = 1.1

    #determine what point to reactivly plan to
    while(next_state_not_found):
        if next_time == len(GlobalTraj):
            next_time = 0
            counter += 1
            if counter > 2:
                print('Global Trajectory Has Only One State - Check Global Solution')
                exit()
        if GlobalTraj[global_time,2] != GlobalTraj[next_time,2]:
            goal_time = next_time
            next_state = GlobalTraj[next_time,2]
            goal_point = GlobalTraj[next_time,0:2]
            next_state_time = total_time
            next_state_not_found = False
        else:
            next_time+=1
            total_time += 1

    rrtobstacleList = cbf_obstacles[0:6]
    #print('cbf_obs_init',cbf_obstacles)
    if avoid_obs != []:
        for obs in avoid_obs:
            #print('avoid_obs',obs)
            ##Might need to expand or shrink radius based on velocity and cbfs
            rrtobstacleList.append([obs[0][0],obs[0][1],obs[1][0],obs[2][0],obs[2][1]])
    #print(rrtobstacleList)
    #Use Timed RRT to get back pose values
    if visit_point != None:
        '''
        new_obs2 = []
        for name,obs in props.items():
            if not obs.inflate_contains(np.array((goal_point[0],goal_point[1])),1) and not obs.inflate_contains(np.array((current_point[0],current_point[1])),1) and not obs.inflate_contains(np.array((visit_point[0],visit_point[1])),1):
                constraints_new = obs.constraints
                r = obstacle_inflation * np.sqrt(2*((constraints_new[0,1]-constraints_new[0,0])*0.5)**2)
                x_centroid = (constraints_new[0,1]-constraints_new[0,0])*0.5+constraints_new[0,0]
                y_centroid = (constraints_new[1,1]-constraints_new[1,0])*0.5+constraints_new[1,0]
                new_obs2.append([x_centroid,y_centroid,r])
        for obs_data in rrtobstacleList:#m_struct.cbf_obs:
             new_obs2.append(obs_data)
        print('here',new_obs2)
        '''
        #print('obs_len',len(rrtobstacleList))
        cbf_planner_new = informed_safe_rrt.RRT(current_point,visit_point,rrtobstacleList)#new_obs2)
        path_there = cbf_planner_new.Planning(animation=False)
        #print("path_there")
        cbf_planner_new = informed_safe_rrt.RRT(visit_point,goal_point,rrtobstacleList)#new_obs2)
        path_back = cbf_planner_new.Planning(animation=False)
        #print("path_back")
        #print(rrtobstacleList,obstacles2,current_point,visit_point,goal_point)
        #path_there = rrt.FindRRTPath(current_point,visit_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        #path_back = rrt.FindRRTPath(visit_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if path_there == [] or path_back == []:
            new_obs3 = rrtobstacleList#m_struct.cbf_obs
            while path_there == [] or path_back == []:
                cbf_planner_new = informed_safe_rrt.RRT(current_point,visit_point,new_obs3)
                path_there = cbf_planner_new.Planning(animation=False)
                cbf_planner_new = informed_safe_rrt.RRT(visit_point,goal_point,new_obs3)
                path_back = cbf_planner_new.Planning(animation=False)
                #path_there = rrt.FindRRTPath(current_point,visit_point,region.constraints,rrtobstacleList,obstacles2,velocity)
                #path_back = rrt.FindRRTPath(visit_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)

        if path_there is None or path_back is None:
            return(None,None)
        else:
            local_plan = np.concatenate((path_there,path_back[1:]))
            return local_plan,next_state_time

    else:
        '''
        extra_obs = rrtobstacleList#m_struct.cbf_obs
        for name,obs in props.items():
            if not obs.contains(np.array((goal_point[0],goal_point[1]))) and not obs.contains(np.array((current_point[0],current_point[1]))):
                constraints3 = obs.constraints
                r = obstacle_inflation * np.sqrt(2*((constraints3[0,1]-constraints3[0,0])*0.5)**2)
                x_centroid = (constraints3[0,1]-constraints3[0,0])*0.5+constraints3[0,0]
                y_centroid = (constraints3[1,1]-constraints3[1,0])*0.5+constraints3[1,0]
                extra_obs.append([x_centroid,y_centroid,r])
        print('here',extra_obs)
        '''
        #print('obs_len',len(rrtobstacleList))
        cbf_planner_new = informed_safe_rrt.RRT(current_point,goal_point,rrtobstacleList)#extra_obs)
        local_plan = cbf_planner_new.Planning(animation=False)
        #local_plan = rrt.FindRRTPath(current_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if local_plan == []:
            #extra_obs = rrtobstacleList#m_struct.cbf_obs
            cbf_planner_new = informed_safe_rrt.RRT(current_point,goal_point,rrtobstacleList)#extra_obs)
            while local_plan == []:
                local_plan = cbf_planner_new.Planning(animation=False)
                #local_plan = rrt.FindRRTPath(current_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if local_plan is None:
            return(None,None)
        return local_plan,next_state_time

def local_planner_rrt(current_point,global_time,GlobalTraj,avoid_obs,region,props,obstacles2,visit_point=None,velocity=1):
    #Given current state, find path that avoids things as best as possible
    #Find next state:
    first_obs = obstacles2
    next_state_not_found = True
    next_time = global_time+1
    counter = 0
    total_time = 1
    while(next_state_not_found):
        if next_time == len(GlobalTraj):
            next_time = 0
            counter += 1
            if counter > 2:
                print('Global Trajectory Has Only One State - Check Global Solution')
                exit()
        if GlobalTraj[global_time,2] != GlobalTraj[next_time,2]:
            goal_time = next_time
            next_state = GlobalTraj[next_time,2]
            goal_point = GlobalTraj[next_time,0:2]
            next_state_time = total_time
            next_state_not_found = False
        else:
            next_time+=1
            total_time += 1

    rrtobstacleList = [
        (0,0,0),
        (0,0,0)
        ]
    if avoid_obs != []:
        for obs in avoid_obs:
            ##Might need to expand radius based on velocity
            rrtobstacleList.append((obs[0][0],obs[0][1],obs[1][0]))

    #Use Timed RRT to get back pose values
    if visit_point != None:
        path_there = rrt.FindRRTPath(current_point,visit_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        path_back = rrt.FindRRTPath(visit_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if path_there == [] or path_back == []:
            obstacles2 = first_obs
            while path_there == [] or path_back == []:
                path_there = rrt.FindRRTPath(current_point,visit_point,region.constraints,rrtobstacleList,obstacles2,velocity)
                path_back = rrt.FindRRTPath(visit_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        local_plan = np.concatenate((path_there,path_back))
        print(next_state_time)
        return local_plan,next_state_time

    else:

        local_plan = rrt.FindRRTPath(current_point,goal_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        if local_plan == []:
            obstacles2 = first_obs
            while local_plan == []:
                local_plan = rrt.FindRRTPath(current_point,current_point,region.constraints,rrtobstacleList,obstacles2,velocity)
        print(next_state_time)
        return local_plan,next_state_time

def local_planner_kp_tree_reconnect(cur_kp_tree,cur_point,cur_state,d_reconnect,obs_list):
    #get nodes in current state / of higher cost
    #trim due to obstacles
    #find point nearest to current point
    #check collisions
    #plan to point with cbf if possible
        #if not possible - revert to other d_reconnect
    #return new path otherwise
    return True
def update_current_plan(current_plan,local_plan,time,next_state_time,visit_point=None):
    if local_plan is None:
        #print('current local',current_plan,local_plan)
        end_idx = get_next_tau_interval(current_plan,time)
        current_plan = np.insert(current_plan,time,current_plan[time-1],axis=0)
        for h in range(time,end_idx+1):
            current_plan[h,3] += 1
        #print(current_plan,time)
        return(current_plan)

    end_idx = get_next_tau_interval(current_plan,time)
    start_array = current_plan[time-1]
    full_local_plan = []
    counter = 0
    for points in local_plan[:-1]:
        full_local_plan.append([points[0],points[1],start_array[2]+0.001,(start_array[3]+counter)])
        counter += 1
    len_before = len(current_plan)
    current_plan = np.delete(current_plan,range(time-1,time+next_state_time),0)
    current_plan = np.insert(current_plan,time-1,full_local_plan,axis=0)
    len_after = len(current_plan)
    len_local = len_after-len_before
    #Change the other costs in the concatenation to reflect new length.
    len_extra_states = end_idx-(next_state_time+time)
    #Update cost of completeing trajectory
    end_leg_time = (time)+len_extra_states+len_local+next_state_time
    for i in range(time,end_leg_time):
        current_plan[i,3] = current_plan[i-1,3]+1

    return current_plan

def bak_update_current_plan(current_plan,local_plan,time,next_state_time,visit_point=None):

    end_idx = get_next_tau_interval(current_plan,time)
    print(current_plan,local_plan,time,next_state_time,end_idx)
    local_length = len(local_plan)
    #print('from_stitcher',time,end_idx,local_length,next_state_time)
    start_array = current_plan[time]

    if visit_point != None:
        full_state_local_plan = []
        t_count = -1
        v1 = 0
        for points in local_plan:
            if points[0] == visit_point[0] and points[1] == visit_point[1]:
                v1 = 1
            if v1 == 0:
                state_val = start_array[2]
            else:
                state_val = start_array[2]+.5
            full_point = [points[0],points[1],state_val,start_array[3]+t_count]
            t_count += 1
            full_state_local_plan.append(full_point)
    else:
        full_state_local_plan = []
        t_count = -1
        for points in local_plan:
            full_point = [points[0],points[1],start_array[2],start_array[3]+t_count]
            t_count += 1
            full_state_local_plan.append(full_point)

    current_plan = np.delete(current_plan,range(time-1,time+next_state_time),0)

    current_plan = np.insert(current_plan,time-1,full_state_local_plan,axis=0)
    #print('current_plan',current_plan)
    #Change the other costs in the concatenation to reflect new length.
    len_added = len(full_state_local_plan)
    new_ns = next_state_time+len_added
    end_diff = +end_idx-next_state_time
    #print(len_added,new_ns,end_diff)
    for i in range(new_ns,new_ns+end_diff):
        current_plan[i,3] = current_plan[i-1,3] +1
        #print('index',i)
    #print(current_plan)
    return current_plan

def compute_current_taus(CTraj,GTraj,taus):

    #Determine tau cost at the end of each tau leg
    tau_time = 0
    orig_tau_costs = []
    for tau in range(0,len(taus)):
        tau_finder = True
        while(tau_finder):
            if tau_time+1 == len(GTraj):
                tau_cost = GTraj[tau_time,3]
                tau_finder = False
            elif GTraj[tau_time+1,3] != GTraj[tau_time,3]+1:
                next_tau_time = tau_time
                tau_finder = False
                tau_cost = GTraj[tau_time,3]
                tau_time +=1
            else:
                tau_time += 1
        orig_tau_costs.append(tau_cost)

    tau_time2 = 0
    new_tau_costs = []
    for tau2 in range(0,len(taus)):
        tau_finder2 = True
        while(tau_finder2):
            if tau_time2+1 == len(CTraj):
                tau_cost2 = CTraj[tau_time2,3]
                tau_finder2 = False
            elif CTraj[tau_time2+1,3] != CTraj[tau_time2,3]+1:
                next_tau_time2 = tau_time2
                tau_finder2 = False
                tau_cost2 = CTraj[tau_time2,3]
                tau_time2 +=1
            else:
                tau_time2 += 1
        new_tau_costs.append(tau_cost2)

    updated_tau = []
    for j in range(0,len(new_tau_costs)):
        diff_val = new_tau_costs[j]-orig_tau_costs[j]
        updated_tau.append(taus[j]+diff_val)

    return updated_tau

def get_next_tau_interval(CurrentTraj,cur_idx):
    tau_time = cur_idx
    tau_finder = True
    while(tau_finder):
        if tau_time+1 == len(CurrentTraj):
            tau_cost = CurrentTraj[tau_time,3]
            tau_finder = False
        elif CurrentTraj[tau_time+1,3] != CurrentTraj[tau_time,3]+1:
            next_tau_time = tau_time
            tau_finder = False
            tau_cost = CurrentTraj[tau_time,3]
            tau_time +=1
        else:
            tau_time += 1
    return tau_time

def next_kp_tree(full_tree,cur_traj,cur_ind):
#This function determines what tree to use for replanning if needed - the root of the tree is the keypoint
        cur_state = math.trunc(cur_traj[cur_ind,2])
        the_time = cur_ind
        not_found = True
        while(not_found):
            if the_time+1 == len(cur_traj):
                not_found = False
                return full_tree.find(cur_traj[0,:2]),0
            elif math.trunc(cur_traj[the_time+1,2]) != math.trunc(cur_traj[the_time,2]):
                not_found = False
                return full_tree.find(cur_traj[(the_time+1),:2],),(the_time+1)
            else:
                the_time += 1
        return(full_tree.find(cur_traj[0,:2])),0


def save_keypoint_figure(GlobalTraj,region,init_obs,props):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.set_xlim(region.constraints[0])
    ax.set_ylim(region.constraints[1])
    plot_box(ax, region, facecolor="white")

    for o in init_obs:
        plot_box(ax, o, facecolor="red")

    globalx1 = []
    globaly1 = []
    globalstate1 = []
    globalcost1 = []

    for points in GlobalTraj:
        globalx1.append(points[0])
        globaly1.append(points[1])
        globalstate1.append(points[2])
        globalcost1.append(points[3])

    kp_time = 0
    kpsx = []
    kpsy = []

    tau_finder = True
    while(tau_finder):
        if kp_time+1 == len(globalx1):
            tau_finder = False
        elif globalstate1[kp_time+1] != globalstate1[kp_time]:
            kpsx.append(globalx1[kp_time+1])
            kpsy.append(globaly1[kp_time+1])
            kp_time +=1
        else:
            kp_time += 1

    ax.plot(globalx1,globaly1,'b.-',linewidth=1.75)
    ax.scatter(kpsx,kpsy,marker='D',color='r')

    for names, regions in props.items():
        plot_box(ax, regions, facecolor="green")
        label(ax, regions.center(), names, 20)

    with PdfPages(r'keypoint_pdf.pdf') as export_pdf:
        export_pdf.savefig(fig) #Save the figure that is currently in the foreground
    plt.show(block=False)
    exit()


def plot_box(ax, box, **kwargs):
    cs = box.constraints
    x, y = cs[:2,0]
    w, h = cs[:2,1] - cs[:2,0]
    ax.add_patch(patches.Rectangle((x,y), w, h, alpha=.5, **kwargs))

def plot_circle(x,y,r,color='y'):
    circle = plt.Circle((x, y), radius=r, fc=color,alpha=0.4)
    plt.gca().add_patch(circle)

def label(ax, center, text, size):
    ax.text(center[0], center[1], text, ha="center", va="center", size=size)
