# Generated from catl.g4 by ANTLR 4.7.1
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys


'''
 Copyright (C) 2018-2020 Cristian Ioan Vasile <cvasile@lehigh.edu>
 Explainable Robotics Lab (ERL), Autonomous and Intelligent Robotics (AIR) Lab,
 Lehigh University
 Hybrid and Networked Systems (HyNeSs) Group, BU Robotics Lab, Boston University
 See license.txt file for license information.
'''

def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3")
        buf.write(u"\26o\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write(u"\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2")
        buf.write(u"\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\5\2%\n\2\3\2\3\2")
        buf.write(u"\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\2")
        buf.write(u"\3\2\3\2\7\28\n\2\f\2\16\2;\13\2\3\3\3\3\3\3\3\3\3\3")
        buf.write(u"\3\3\3\3\3\3\3\3\5\3F\n\3\3\3\3\3\3\3\5\3K\n\3\3\4\3")
        buf.write(u"\4\3\4\3\4\7\4Q\n\4\f\4\16\4T\13\4\3\4\3\4\3\5\3\5\3")
        buf.write(u"\5\3\5\3\5\3\5\3\6\3\6\3\6\3\6\7\6b\n\6\f\6\16\6e\13")
        buf.write(u"\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\3\7\3\7\2\3\2\b\2\4\6")
        buf.write(u"\b\n\f\2\3\3\2\24\25\2t\2$\3\2\2\2\4J\3\2\2\2\6L\3\2")
        buf.write(u"\2\2\bW\3\2\2\2\n]\3\2\2\2\fh\3\2\2\2\16\17\b\2\1\2\17")
        buf.write(u"\20\7\3\2\2\20\21\5\2\2\2\21\22\7\4\2\2\22%\3\2\2\2\23")
        buf.write(u"%\5\4\3\2\24\25\7\16\2\2\25%\5\2\2\t\26\27\7\17\2\2\27")
        buf.write(u"\30\7\5\2\2\30\31\t\2\2\2\31\32\7\6\2\2\32\33\t\2\2\2")
        buf.write(u"\33\34\7\7\2\2\34%\5\2\2\b\35\36\7\20\2\2\36\37\7\5\2")
        buf.write(u"\2\37 \t\2\2\2 !\7\6\2\2!\"\t\2\2\2\"#\7\7\2\2#%\5\2")
        buf.write(u"\2\7$\16\3\2\2\2$\23\3\2\2\2$\24\3\2\2\2$\26\3\2\2\2")
        buf.write(u"$\35\3\2\2\2%9\3\2\2\2&\'\f\6\2\2\'(\7\r\2\2(8\5\2\2")
        buf.write(u"\7)*\f\5\2\2*+\7\13\2\2+8\5\2\2\6,-\f\4\2\2-.\7\f\2\2")
        buf.write(u".8\5\2\2\5/\60\f\3\2\2\60\61\7\21\2\2\61\62\7\5\2\2\62")
        buf.write(u"\63\t\2\2\2\63\64\7\6\2\2\64\65\t\2\2\2\65\66\7\7\2\2")
        buf.write(u"\668\5\2\2\4\67&\3\2\2\2\67)\3\2\2\2\67,\3\2\2\2\67/")
        buf.write(u"\3\2\2\28;\3\2\2\29\67\3\2\2\29:\3\2\2\2:\3\3\2\2\2;")
        buf.write(u"9\3\2\2\2<=\7\b\2\2=>\7\3\2\2>?\t\2\2\2?@\7\6\2\2@A\7")
        buf.write(u"\23\2\2AB\7\6\2\2BE\5\6\4\2CD\7\6\2\2DF\5\n\6\2EC\3\2")
        buf.write(u"\2\2EF\3\2\2\2FG\3\2\2\2GH\7\4\2\2HK\3\2\2\2IK\7\22\2")
        buf.write(u"\2J<\3\2\2\2JI\3\2\2\2K\5\3\2\2\2LM\7\t\2\2MR\5\b\5\2")
        buf.write(u"NO\7\6\2\2OQ\5\b\5\2PN\3\2\2\2QT\3\2\2\2RP\3\2\2\2RS")
        buf.write(u"\3\2\2\2SU\3\2\2\2TR\3\2\2\2UV\7\n\2\2V\7\3\2\2\2WX\7")
        buf.write(u"\3\2\2XY\7\23\2\2YZ\7\6\2\2Z[\7\25\2\2[\\\7\4\2\2\\\t")
        buf.write(u"\3\2\2\2]^\7\t\2\2^c\5\f\7\2_`\7\6\2\2`b\5\f\7\2a_\3")
        buf.write(u"\2\2\2be\3\2\2\2ca\3\2\2\2cd\3\2\2\2df\3\2\2\2ec\3\2")
        buf.write(u"\2\2fg\7\n\2\2g\13\3\2\2\2hi\7\3\2\2ij\7\23\2\2jk\7\6")
        buf.write(u"\2\2kl\t\2\2\2lm\7\4\2\2m\r\3\2\2\2\t$\679EJRc")
        return buf.getvalue()


class catlParser ( Parser ):

    grammarFileName = "catl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"'('", u"')'", u"'['", u"','", u"']'", 
                     u"'T'", u"'{'", u"'}'", u"<INVALID>", u"<INVALID>", 
                     u"'=>'", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"'U'" ]

    symbolicNames = [ u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                      u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                      u"<INVALID>", u"AND", u"OR", u"IMPLIES", u"NOT", u"EVENT", 
                      u"ALWAYS", u"UNTIL", u"BOOLEAN", u"VARIABLE", u"RATIONAL", 
                      u"INT", u"WS" ]

    RULE_catlProperty = 0
    RULE_predicate = 1
    RULE_capabilities = 2
    RULE_capabilityRequest = 3
    RULE_resources = 4
    RULE_resourceRequest = 5

    ruleNames =  [ u"catlProperty", u"predicate", u"capabilities", u"capabilityRequest", 
                   u"resources", u"resourceRequest" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    AND=9
    OR=10
    IMPLIES=11
    NOT=12
    EVENT=13
    ALWAYS=14
    UNTIL=15
    BOOLEAN=16
    VARIABLE=17
    RATIONAL=18
    INT=19
    WS=20

    def __init__(self, input, output=sys.stdout):
        super(catlParser, self).__init__(input, output=output)
        self.checkVersion("4.7.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class CatlPropertyContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(catlParser.CatlPropertyContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return catlParser.RULE_catlProperty

     
        def copyFrom(self, ctx):
            super(catlParser.CatlPropertyContext, self).copyFrom(ctx)


    class CatlPredicateContext(CatlPropertyContext):

        def __init__(self, parser, ctx): # actually a catlParser.CatlPropertyContext)
            super(catlParser.CatlPredicateContext, self).__init__(parser)
            self.copyFrom(ctx)

        def predicate(self):
            return self.getTypedRuleContext(catlParser.PredicateContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterCatlPredicate"):
                listener.enterCatlPredicate(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitCatlPredicate"):
                listener.exitCatlPredicate(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitCatlPredicate"):
                return visitor.visitCatlPredicate(self)
            else:
                return visitor.visitChildren(self)


    class FormulaContext(CatlPropertyContext):

        def __init__(self, parser, ctx): # actually a catlParser.CatlPropertyContext)
            super(catlParser.FormulaContext, self).__init__(parser)
            self.left = None # CatlPropertyContext
            self.op = None # Token
            self.child = None # CatlPropertyContext
            self.low = None # Token
            self.high = None # Token
            self.right = None # CatlPropertyContext
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(catlParser.NOT, 0)
        def catlProperty(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(catlParser.CatlPropertyContext)
            else:
                return self.getTypedRuleContext(catlParser.CatlPropertyContext,i)

        def EVENT(self):
            return self.getToken(catlParser.EVENT, 0)
        def RATIONAL(self, i=None):
            if i is None:
                return self.getTokens(catlParser.RATIONAL)
            else:
                return self.getToken(catlParser.RATIONAL, i)
        def INT(self, i=None):
            if i is None:
                return self.getTokens(catlParser.INT)
            else:
                return self.getToken(catlParser.INT, i)
        def ALWAYS(self):
            return self.getToken(catlParser.ALWAYS, 0)
        def IMPLIES(self):
            return self.getToken(catlParser.IMPLIES, 0)
        def AND(self):
            return self.getToken(catlParser.AND, 0)
        def OR(self):
            return self.getToken(catlParser.OR, 0)
        def UNTIL(self):
            return self.getToken(catlParser.UNTIL, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterFormula"):
                listener.enterFormula(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitFormula"):
                listener.exitFormula(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitFormula"):
                return visitor.visitFormula(self)
            else:
                return visitor.visitChildren(self)


    class ParpropContext(CatlPropertyContext):

        def __init__(self, parser, ctx): # actually a catlParser.CatlPropertyContext)
            super(catlParser.ParpropContext, self).__init__(parser)
            self.child = None # CatlPropertyContext
            self.copyFrom(ctx)

        def catlProperty(self):
            return self.getTypedRuleContext(catlParser.CatlPropertyContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterParprop"):
                listener.enterParprop(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitParprop"):
                listener.exitParprop(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitParprop"):
                return visitor.visitParprop(self)
            else:
                return visitor.visitChildren(self)



    def catlProperty(self, _p=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = catlParser.CatlPropertyContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 0
        self.enterRecursionRule(localctx, 0, self.RULE_catlProperty, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 34
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [catlParser.T__0]:
                localctx = catlParser.ParpropContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 13
                self.match(catlParser.T__0)
                self.state = 14
                localctx.child = self.catlProperty(0)
                self.state = 15
                self.match(catlParser.T__1)
                pass
            elif token in [catlParser.T__5, catlParser.BOOLEAN]:
                localctx = catlParser.CatlPredicateContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 17
                self.predicate()
                pass
            elif token in [catlParser.NOT]:
                localctx = catlParser.FormulaContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 18
                localctx.op = self.match(catlParser.NOT)
                self.state = 19
                localctx.child = self.catlProperty(7)
                pass
            elif token in [catlParser.EVENT]:
                localctx = catlParser.FormulaContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 20
                localctx.op = self.match(catlParser.EVENT)
                self.state = 21
                self.match(catlParser.T__2)
                self.state = 22
                localctx.low = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                    localctx.low = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 23
                self.match(catlParser.T__3)
                self.state = 24
                localctx.high = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                    localctx.high = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 25
                self.match(catlParser.T__4)
                self.state = 26
                localctx.child = self.catlProperty(6)
                pass
            elif token in [catlParser.ALWAYS]:
                localctx = catlParser.FormulaContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 27
                localctx.op = self.match(catlParser.ALWAYS)
                self.state = 28
                self.match(catlParser.T__2)
                self.state = 29
                localctx.low = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                    localctx.low = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 30
                self.match(catlParser.T__3)
                self.state = 31
                localctx.high = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                    localctx.high = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 32
                self.match(catlParser.T__4)
                self.state = 33
                localctx.child = self.catlProperty(5)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 55
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 53
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                    if la_ == 1:
                        localctx = catlParser.FormulaContext(self, catlParser.CatlPropertyContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_catlProperty)
                        self.state = 36
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 37
                        localctx.op = self.match(catlParser.IMPLIES)
                        self.state = 38
                        localctx.right = self.catlProperty(5)
                        pass

                    elif la_ == 2:
                        localctx = catlParser.FormulaContext(self, catlParser.CatlPropertyContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_catlProperty)
                        self.state = 39
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 40
                        localctx.op = self.match(catlParser.AND)
                        self.state = 41
                        localctx.right = self.catlProperty(4)
                        pass

                    elif la_ == 3:
                        localctx = catlParser.FormulaContext(self, catlParser.CatlPropertyContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_catlProperty)
                        self.state = 42
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 43
                        localctx.op = self.match(catlParser.OR)
                        self.state = 44
                        localctx.right = self.catlProperty(3)
                        pass

                    elif la_ == 4:
                        localctx = catlParser.FormulaContext(self, catlParser.CatlPropertyContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_catlProperty)
                        self.state = 45
                        if not self.precpred(self._ctx, 1):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 1)")
                        self.state = 46
                        localctx.op = self.match(catlParser.UNTIL)
                        self.state = 47
                        self.match(catlParser.T__2)
                        self.state = 48
                        localctx.low = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                            localctx.low = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 49
                        self.match(catlParser.T__3)
                        self.state = 50
                        localctx.high = self._input.LT(1)
                        _la = self._input.LA(1)
                        if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                            localctx.high = self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 51
                        self.match(catlParser.T__4)
                        self.state = 52
                        localctx.right = self.catlProperty(2)
                        pass

             
                self.state = 57
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class PredicateContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(catlParser.PredicateContext, self).__init__(parent, invokingState)
            self.parser = parser
            self.op = None # Token
            self.duration = None # Token
            self.proposition = None # Token

        def capabilities(self):
            return self.getTypedRuleContext(catlParser.CapabilitiesContext,0)


        def VARIABLE(self):
            return self.getToken(catlParser.VARIABLE, 0)

        def RATIONAL(self):
            return self.getToken(catlParser.RATIONAL, 0)

        def INT(self):
            return self.getToken(catlParser.INT, 0)

        def resources(self):
            return self.getTypedRuleContext(catlParser.ResourcesContext,0)


        def BOOLEAN(self):
            return self.getToken(catlParser.BOOLEAN, 0)

        def getRuleIndex(self):
            return catlParser.RULE_predicate

        def enterRule(self, listener):
            if hasattr(listener, "enterPredicate"):
                listener.enterPredicate(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPredicate"):
                listener.exitPredicate(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitPredicate"):
                return visitor.visitPredicate(self)
            else:
                return visitor.visitChildren(self)




    def predicate(self):

        localctx = catlParser.PredicateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_predicate)
        self._la = 0 # Token type
        try:
            self.state = 72
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [catlParser.T__5]:
                self.enterOuterAlt(localctx, 1)
                self.state = 58
                localctx.op = self.match(catlParser.T__5)
                self.state = 59
                self.match(catlParser.T__0)
                self.state = 60
                localctx.duration = self._input.LT(1)
                _la = self._input.LA(1)
                if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                    localctx.duration = self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 61
                self.match(catlParser.T__3)
                self.state = 62
                localctx.proposition = self.match(catlParser.VARIABLE)
                self.state = 63
                self.match(catlParser.T__3)
                self.state = 64
                self.capabilities()
                self.state = 67
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==catlParser.T__3:
                    self.state = 65
                    self.match(catlParser.T__3)
                    self.state = 66
                    self.resources()


                self.state = 69
                self.match(catlParser.T__1)
                pass
            elif token in [catlParser.BOOLEAN]:
                self.enterOuterAlt(localctx, 2)
                self.state = 71
                localctx.op = self.match(catlParser.BOOLEAN)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CapabilitiesContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(catlParser.CapabilitiesContext, self).__init__(parent, invokingState)
            self.parser = parser

        def capabilityRequest(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(catlParser.CapabilityRequestContext)
            else:
                return self.getTypedRuleContext(catlParser.CapabilityRequestContext,i)


        def getRuleIndex(self):
            return catlParser.RULE_capabilities

        def enterRule(self, listener):
            if hasattr(listener, "enterCapabilities"):
                listener.enterCapabilities(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitCapabilities"):
                listener.exitCapabilities(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitCapabilities"):
                return visitor.visitCapabilities(self)
            else:
                return visitor.visitChildren(self)




    def capabilities(self):

        localctx = catlParser.CapabilitiesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_capabilities)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            self.match(catlParser.T__6)
            self.state = 75
            self.capabilityRequest()
            self.state = 80
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==catlParser.T__3:
                self.state = 76
                self.match(catlParser.T__3)
                self.state = 77
                self.capabilityRequest()
                self.state = 82
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 83
            self.match(catlParser.T__7)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CapabilityRequestContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(catlParser.CapabilityRequestContext, self).__init__(parent, invokingState)
            self.parser = parser
            self.cap = None # Token
            self.count = None # Token

        def VARIABLE(self):
            return self.getToken(catlParser.VARIABLE, 0)

        def INT(self):
            return self.getToken(catlParser.INT, 0)

        def getRuleIndex(self):
            return catlParser.RULE_capabilityRequest

        def enterRule(self, listener):
            if hasattr(listener, "enterCapabilityRequest"):
                listener.enterCapabilityRequest(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitCapabilityRequest"):
                listener.exitCapabilityRequest(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitCapabilityRequest"):
                return visitor.visitCapabilityRequest(self)
            else:
                return visitor.visitChildren(self)




    def capabilityRequest(self):

        localctx = catlParser.CapabilityRequestContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_capabilityRequest)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.match(catlParser.T__0)
            self.state = 86
            localctx.cap = self.match(catlParser.VARIABLE)
            self.state = 87
            self.match(catlParser.T__3)
            self.state = 88
            localctx.count = self.match(catlParser.INT)
            self.state = 89
            self.match(catlParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ResourcesContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(catlParser.ResourcesContext, self).__init__(parent, invokingState)
            self.parser = parser

        def resourceRequest(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(catlParser.ResourceRequestContext)
            else:
                return self.getTypedRuleContext(catlParser.ResourceRequestContext,i)


        def getRuleIndex(self):
            return catlParser.RULE_resources

        def enterRule(self, listener):
            if hasattr(listener, "enterResources"):
                listener.enterResources(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitResources"):
                listener.exitResources(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitResources"):
                return visitor.visitResources(self)
            else:
                return visitor.visitChildren(self)




    def resources(self):

        localctx = catlParser.ResourcesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_resources)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 91
            self.match(catlParser.T__6)
            self.state = 92
            self.resourceRequest()
            self.state = 97
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==catlParser.T__3:
                self.state = 93
                self.match(catlParser.T__3)
                self.state = 94
                self.resourceRequest()
                self.state = 99
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 100
            self.match(catlParser.T__7)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ResourceRequestContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(catlParser.ResourceRequestContext, self).__init__(parent, invokingState)
            self.parser = parser
            self.res = None # Token
            self.quantity = None # Token

        def VARIABLE(self):
            return self.getToken(catlParser.VARIABLE, 0)

        def RATIONAL(self):
            return self.getToken(catlParser.RATIONAL, 0)

        def INT(self):
            return self.getToken(catlParser.INT, 0)

        def getRuleIndex(self):
            return catlParser.RULE_resourceRequest

        def enterRule(self, listener):
            if hasattr(listener, "enterResourceRequest"):
                listener.enterResourceRequest(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitResourceRequest"):
                listener.exitResourceRequest(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitResourceRequest"):
                return visitor.visitResourceRequest(self)
            else:
                return visitor.visitChildren(self)




    def resourceRequest(self):

        localctx = catlParser.ResourceRequestContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_resourceRequest)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(catlParser.T__0)
            self.state = 103
            localctx.res = self.match(catlParser.VARIABLE)
            self.state = 104
            self.match(catlParser.T__3)
            self.state = 105
            localctx.quantity = self._input.LT(1)
            _la = self._input.LA(1)
            if not(_la==catlParser.RATIONAL or _la==catlParser.INT):
                localctx.quantity = self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 106
            self.match(catlParser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx, ruleIndex, predIndex):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[0] = self.catlProperty_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def catlProperty_sempred(self, localctx, predIndex):
            if predIndex == 0:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 2)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 1)
         




