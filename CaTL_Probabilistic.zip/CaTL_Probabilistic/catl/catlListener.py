# Generated from catl.g4 by ANTLR 4.7.1
from antlr4 import *

'''
 Copyright (C) 2018-2020 Cristian Ioan Vasile <cvasile@lehigh.edu>
 Explainable Robotics Lab (ERL), Autonomous and Intelligent Robotics (AIR) Lab,
 Lehigh University
 Hybrid and Networked Systems (HyNeSs) Group, BU Robotics Lab, Boston University
 See license.txt file for license information.
'''


# This class defines a complete listener for a parse tree produced by catlParser.
class catlListener(ParseTreeListener):

    # Enter a parse tree produced by catlParser#catlPredicate.
    def enterCatlPredicate(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#catlPredicate.
    def exitCatlPredicate(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#formula.
    def enterFormula(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#formula.
    def exitFormula(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#parprop.
    def enterParprop(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#parprop.
    def exitParprop(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#predicate.
    def enterPredicate(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#predicate.
    def exitPredicate(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#capabilities.
    def enterCapabilities(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#capabilities.
    def exitCapabilities(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#capabilityRequest.
    def enterCapabilityRequest(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#capabilityRequest.
    def exitCapabilityRequest(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#resources.
    def enterResources(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#resources.
    def exitResources(self, ctx):
        pass


    # Enter a parse tree produced by catlParser#resourceRequest.
    def enterResourceRequest(self, ctx):
        pass

    # Exit a parse tree produced by catlParser#resourceRequest.
    def exitResourceRequest(self, ctx):
        pass


