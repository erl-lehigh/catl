# Generated from catl.g4 by ANTLR 4.7.1
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys


'''
 Copyright (C) 2018-2020 Cristian Ioan Vasile <cvasile@lehigh.edu>
 Explainable Robotics Lab (ERL), Autonomous and Intelligent Robotics (AIR) Lab,
 Lehigh University
 Hybrid and Networked Systems (HyNeSs) Group, BU Robotics Lab, Boston University
 See license.txt file for license information.
'''


def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2")
        buf.write(u"\26\u009f\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6")
        buf.write(u"\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4")
        buf.write(u"\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t")
        buf.write(u"\22\4\23\t\23\4\24\t\24\4\25\t\25\3\2\3\2\3\3\3\3\3\4")
        buf.write(u"\3\4\3\5\3\5\3\6\3\6\3\7\3\7\3\b\3\b\3\t\3\t\3\n\3\n")
        buf.write(u"\3\n\3\n\3\n\5\nA\n\n\3\13\3\13\3\13\3\13\3\13\5\13H")
        buf.write(u"\n\13\3\f\3\f\3\f\3\r\3\r\3\16\3\16\3\16\5\16R\n\16\3")
        buf.write(u"\17\3\17\3\17\5\17W\n\17\3\20\3\20\3\21\3\21\3\21\3\21")
        buf.write(u"\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3")
        buf.write(u"\21\3\21\3\21\3\21\5\21m\n\21\3\22\5\22p\n\22\3\22\7")
        buf.write(u"\22s\n\22\f\22\16\22v\13\22\3\23\3\23\5\23z\n\23\3\23")
        buf.write(u"\6\23}\n\23\r\23\16\23~\3\23\3\23\3\23\5\23\u0084\n\23")
        buf.write(u"\3\23\7\23\u0087\n\23\f\23\16\23\u008a\13\23\3\24\3\24")
        buf.write(u"\5\24\u008e\n\24\3\24\3\24\7\24\u0092\n\24\f\24\16\24")
        buf.write(u"\u0095\13\24\5\24\u0097\n\24\3\25\6\25\u009a\n\25\r\25")
        buf.write(u"\16\25\u009b\3\25\3\25\2\2\26\3\3\5\4\7\5\t\6\13\7\r")
        buf.write(u"\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17\35\20\37\21")
        buf.write(u"!\22#\23%\24\'\25)\26\3\2\b\4\2##\u0080\u0080\4\2C\\")
        buf.write(u"c|\6\2\62;C\\aac|\3\2\62;\3\2\63;\5\2\13\f\17\17\"\"")
        buf.write(u"\2\u00b1\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2")
        buf.write(u"\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2")
        buf.write(u"\2\2\23\3\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3\2\2")
        buf.write(u"\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2!\3\2\2\2")
        buf.write(u"\2#\3\2\2\2\2%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\3+\3\2")
        buf.write(u"\2\2\5-\3\2\2\2\7/\3\2\2\2\t\61\3\2\2\2\13\63\3\2\2\2")
        buf.write(u"\r\65\3\2\2\2\17\67\3\2\2\2\219\3\2\2\2\23@\3\2\2\2\25")
        buf.write(u"G\3\2\2\2\27I\3\2\2\2\31L\3\2\2\2\33Q\3\2\2\2\35V\3\2")
        buf.write(u"\2\2\37X\3\2\2\2!l\3\2\2\2#o\3\2\2\2%w\3\2\2\2\'\u0096")
        buf.write(u"\3\2\2\2)\u0099\3\2\2\2+,\7*\2\2,\4\3\2\2\2-.\7+\2\2")
        buf.write(u".\6\3\2\2\2/\60\7]\2\2\60\b\3\2\2\2\61\62\7.\2\2\62\n")
        buf.write(u"\3\2\2\2\63\64\7_\2\2\64\f\3\2\2\2\65\66\7V\2\2\66\16")
        buf.write(u"\3\2\2\2\678\7}\2\28\20\3\2\2\29:\7\177\2\2:\22\3\2\2")
        buf.write(u"\2;A\7(\2\2<=\7(\2\2=A\7(\2\2>?\7\61\2\2?A\7^\2\2@;\3")
        buf.write(u"\2\2\2@<\3\2\2\2@>\3\2\2\2A\24\3\2\2\2BH\7~\2\2CD\7~")
        buf.write(u"\2\2DH\7~\2\2EF\7^\2\2FH\7\61\2\2GB\3\2\2\2GC\3\2\2\2")
        buf.write(u"GE\3\2\2\2H\26\3\2\2\2IJ\7?\2\2JK\7@\2\2K\30\3\2\2\2")
        buf.write(u"LM\t\2\2\2M\32\3\2\2\2NR\7H\2\2OP\7>\2\2PR\7@\2\2QN\3")
        buf.write(u"\2\2\2QO\3\2\2\2R\34\3\2\2\2SW\7I\2\2TU\7]\2\2UW\7_\2")
        buf.write(u"\2VS\3\2\2\2VT\3\2\2\2W\36\3\2\2\2XY\7W\2\2Y \3\2\2\2")
        buf.write(u"Z[\7v\2\2[\\\7t\2\2\\]\7w\2\2]m\7g\2\2^_\7V\2\2_`\7t")
        buf.write(u"\2\2`a\7w\2\2am\7g\2\2bc\7h\2\2cd\7c\2\2de\7n\2\2ef\7")
        buf.write(u"u\2\2fm\7g\2\2gh\7H\2\2hi\7c\2\2ij\7n\2\2jk\7u\2\2km")
        buf.write(u"\7g\2\2lZ\3\2\2\2l^\3\2\2\2lb\3\2\2\2lg\3\2\2\2m\"\3")
        buf.write(u"\2\2\2np\t\3\2\2on\3\2\2\2pt\3\2\2\2qs\t\4\2\2rq\3\2")
        buf.write(u"\2\2sv\3\2\2\2tr\3\2\2\2tu\3\2\2\2u$\3\2\2\2vt\3\2\2")
        buf.write(u"\2wy\5\'\24\2xz\7\60\2\2yx\3\2\2\2yz\3\2\2\2z|\3\2\2")
        buf.write(u"\2{}\t\5\2\2|{\3\2\2\2}~\3\2\2\2~|\3\2\2\2~\177\3\2\2")
        buf.write(u"\2\177\u0083\3\2\2\2\u0080\u0084\7G\2\2\u0081\u0082\7")
        buf.write(u"G\2\2\u0082\u0084\7/\2\2\u0083\u0080\3\2\2\2\u0083\u0081")
        buf.write(u"\3\2\2\2\u0083\u0084\3\2\2\2\u0084\u0088\3\2\2\2\u0085")
        buf.write(u"\u0087\t\5\2\2\u0086\u0085\3\2\2\2\u0087\u008a\3\2\2")
        buf.write(u"\2\u0088\u0086\3\2\2\2\u0088\u0089\3\2\2\2\u0089&\3\2")
        buf.write(u"\2\2\u008a\u0088\3\2\2\2\u008b\u0097\7\62\2\2\u008c\u008e")
        buf.write(u"\7/\2\2\u008d\u008c\3\2\2\2\u008d\u008e\3\2\2\2\u008e")
        buf.write(u"\u008f\3\2\2\2\u008f\u0093\t\6\2\2\u0090\u0092\t\5\2")
        buf.write(u"\2\u0091\u0090\3\2\2\2\u0092\u0095\3\2\2\2\u0093\u0091")
        buf.write(u"\3\2\2\2\u0093\u0094\3\2\2\2\u0094\u0097\3\2\2\2\u0095")
        buf.write(u"\u0093\3\2\2\2\u0096\u008b\3\2\2\2\u0096\u008d\3\2\2")
        buf.write(u"\2\u0097(\3\2\2\2\u0098\u009a\t\7\2\2\u0099\u0098\3\2")
        buf.write(u"\2\2\u009a\u009b\3\2\2\2\u009b\u0099\3\2\2\2\u009b\u009c")
        buf.write(u"\3\2\2\2\u009c\u009d\3\2\2\2\u009d\u009e\b\25\2\2\u009e")
        buf.write(u"*\3\2\2\2\23\2@GQVlorty~\u0083\u0088\u008d\u0093\u0096")
        buf.write(u"\u009b\3\b\2\2")
        return buf.getvalue()


class catlLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    T__0 = 1
    T__1 = 2
    T__2 = 3
    T__3 = 4
    T__4 = 5
    T__5 = 6
    T__6 = 7
    T__7 = 8
    AND = 9
    OR = 10
    IMPLIES = 11
    NOT = 12
    EVENT = 13
    ALWAYS = 14
    UNTIL = 15
    BOOLEAN = 16
    VARIABLE = 17
    RATIONAL = 18
    INT = 19
    WS = 20

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ u"DEFAULT_MODE" ]

    literalNames = [ u"<INVALID>",
            u"'('", u"')'", u"'['", u"','", u"']'", u"'T'", u"'{'", u"'}'", 
            u"'=>'", u"'U'" ]

    symbolicNames = [ u"<INVALID>",
            u"AND", u"OR", u"IMPLIES", u"NOT", u"EVENT", u"ALWAYS", u"UNTIL", 
            u"BOOLEAN", u"VARIABLE", u"RATIONAL", u"INT", u"WS" ]

    ruleNames = [ u"T__0", u"T__1", u"T__2", u"T__3", u"T__4", u"T__5", 
                  u"T__6", u"T__7", u"AND", u"OR", u"IMPLIES", u"NOT", u"EVENT", 
                  u"ALWAYS", u"UNTIL", u"BOOLEAN", u"VARIABLE", u"RATIONAL", 
                  u"INT", u"WS" ]

    grammarFileName = u"catl.g4"

    def __init__(self, input=None, output=sys.stdout):
        super(catlLexer, self).__init__(input, output=output)
        self.checkVersion("4.7.1")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


