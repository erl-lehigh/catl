'''
 Copyright (C) 2018-2020 Cristian Ioan Vasile <cvasile@lehigh.edu>
 Explainable Robotics Lab (ERL), Autonomous and Intelligent Robotics (AIR) Lab,
 Lehigh University
 Hybrid and Networked Systems (HyNeSs) Group, BU Robotics Lab, Boston University
 See license.txt file for license information.
'''

import sys
import logging

from lomap import Ts

from route_planning import route_planning
from visualization import show_environment
from check_system_constraints import check_initial_states, check_flow_constraints


def setup_logging(logfile='test_farm.log', loglevel=logging.DEBUG):
    fs, dfs = '%(asctime)s %(levelname)s %(message)s', '%m/%d/%Y %I:%M:%S %p'

    if logfile is not None:
        logging.basicConfig(filename=logfile, level=loglevel,
                            format=fs, datefmt=dfs)

    root = logging.getLogger()
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(loglevel)
    ch.setFormatter(logging.Formatter(fs, dfs))
    root.addHandler(ch)


def case_farm(ts_filename='farm.yaml'):
    '''TODO:
    '''
    setup_logging()

    ts = Ts.load(ts_filename)
    for u, v in ts.g.edges():
        assert ts.g.has_edge(v, u)
    #show_environment(ts)


    for u in ts.g:
        print(u, ts.g.node[u])

    agents = [('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}),
              ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}),
              ('q1', {'Vis', 'UV'}), ('q1', {'Vis', 'UV'}),
              ('q1', {'IR', 'UV'}), ('q1', {'IR', 'UV'}), ('q1', {'IR', 'UV'}),
              ('q6', {'IR', 'UV'}), ('q1', {'IR', 'UV'}),
              ('q1', {'IR', 'MO'}), ('q1', {'IR', 'MO'})]


    initial_locations, capabilities = zip(*agents)
    agent_classes = set(map(frozenset, capabilities))
    initial_locations = set(initial_locations)
    capabilities = set.union(*capabilities)

    logging.debug('Initial locations: %s', str(initial_locations))
    logging.debug('Capabilities: %s', str(capabilities))
    logging.debug('Agent classes: %s', str(agent_classes))

    # make sure all agents' initial states are in the TS
    for state, _ in agents:
        assert state in ts.g, 'State "{}" not in TS!'.format(state)

    specification = ('F[0, 20] T(1, green, {(IR, 2), (Vis, 2)}) '
                     '&& G[20, 40] F[0, 10] T(1, blue, {(UV, 1), (Mo, 2)})'
                     '&& F[5, 25] T(2, yellow, {(UV, 2), (Vis, 2)}) '
                     '&& F[3, 18] T(2, orange, {(Vis, 2)}) '
                     '&& F[20, 30] T(2, orange, {(Vis, 2)}) )'
                     '&& G[1, 4] T(2, green, {(IR, 1), (Vis, 3)})'
                     '&& F[3, 4] T(3, yellow, {(IR, 3), (Vis, 2), (UV, 3), (Mo, 4)})')

    m, replan_data = route_planning(ts, agents, specification)

    time_bound = len(ts.g.nodes(data=True)[0][1]['vars']) - 1


    index = 0
    vars = m.getVars()
    print('number of variables', len(vars))

    exit(0)

    check_initial_states(ts, agents)
    check_flow_constraints(ts, agents, time_bound)


if __name__ == '__main__':
    case_farm()
